const express = require("express");

const app = express();

const api = express();

const cors = require("cors");

const cookieParser = require("cookie-parser");

const swaggerUi = require('swagger-ui-express');
const YAML = require('yamljs');
const swaggerDocument = YAML.load('./swagger.yaml'); 
app.use(cors(
{
    origin: [ "http://localhost:3000" ],
    credentials: true,
}));

app.use(express.json());

app.use(express.urlencoded({ extended: true }));

app.use(cookieParser());


const userRoutes = require("./api/routes/userRoutes");

const errorHandler = require("./api/middlewares/errorHandler");

const authRoutes = require("./api/routes/authRoutes");

const termekRoutes = require("./api/routes/termekRoutes")

const kategoriaRoutes = require("./api/routes/kategoriaRoutes")

const kosartetelekRoutes = require("./api/routes/kosartetelRoutes")
const picupload = require("./api/routes/picupload")
const rendelesRoutes = require("./api/routes/rendelesRoutes")
const ertekelesRoutes = require("./api/routes/ertekelesRoutes")

app.use("/api", api);

api.use("/users", userRoutes);

api.use("/auth", authRoutes);

api.use("/termekek", termekRoutes);

api.use("/kategoriak", kategoriaRoutes);

api.use("/kosartetelek", kosartetelekRoutes)

api.use("/picupload", picupload)

api.use("/rendeles", rendelesRoutes)

api.use("/ertekelesek", ertekelesRoutes)

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

api.use(errorHandler.notFound);

app.use(errorHandler.showError);

app.use(errorHandler.notFound);

module.exports = app;