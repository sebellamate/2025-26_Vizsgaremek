require('dotenv').config();
const db = require('./db'); // a db/index.js
const { DataTypes } = require('sequelize');

const TermekModel = require('./models/Termek');
const Termek = TermekModel(db.sequelize, DataTypes);

async function seedProducts() {
    console.log("Seed indul...");

    // Előző adatok törlése
    await Termek.destroy({ where: {} });

    const productNames = [
        "Apple iPhone 15 Pro Max",
        "Samsung Galaxy S25 Ultra",
        "Google Pixel 8 Pro",
        "Sony Xperia 1 V",
        "Xiaomi 14 Ultra",
        "Apple MacBook Air 13 M3",
        "Dell XPS 13 9310",
        "HP Spectre x360",
        "Lenovo ThinkPad X1 Carbon",
        "Asus ROG Zephyrus G14",
        "Acer Predator Helios 300",
        "Microsoft Surface Laptop 5",
        "Razer Blade 15 Advanced",
        "Apple iPad Pro 12.9\"",
        "Samsung Galaxy Tab S9+",
        "Anker 65W GaN Charger",
        "Belkin 3‑in‑1 Wireless Charger",
        "Ugreen USB‑C Hub 9‑in‑1",
        "Nomad ChargeKey Lightning",
        "Anker PowerCore 24K Power Bank",
        "Baseus 30W Fast Charger",
        "Apple 35W Dual USB‑C Adapter",
        "EcoFlow Rapid Pro Power Bank",
        "Asus 65W Laptop Charger",
        "Acer 45W Laptop Charger",
        "Samsung 45W Fast Charger",
        "Belkin USB‑C Cable 2m",
        "Anker Nano Charger 45W",
        "Logitech MX Master 3 Mouse",
        "Razer Huntsman Mini Keyboard",
        "Dell UltraSharp Monitor 27\"",
        "Samsung 32\" QLED Monitor",
        "Apple AirPods Pro Gen 2",
        "Sony WH‑1000XM5 Headphones",
        "Beats Studio3 Wireless",
        "JBL Charge 5 Bluetooth Speaker",
        "Roku Streaming Stick 4K",
        "Amazon Fire TV Stick 4K",
        "Nintendo Switch OLED",
        "PlayStation 5 Console",
        "Xbox Series X Console"
    ];

    const products = [];

    while (products.length < 500) {
        const name = productNames[Math.floor(Math.random() * productNames.length)];
        const price = Math.floor(Math.random() * (800000 - 5000 + 1)) + 5000;

        products.push({
            nev: name,
            leiras: `${name} – részletes leírás.`,
            ar: price,
            kep_url: "https://via.placeholder.com/150",
            kategoria_id: null
        });
    }

    await Termek.bulkCreate(products);
    console.log("500 termék seedelve!");
    process.exit();
}

seedProducts().catch(err => {
    console.error("Seed hiba:", err);
    process.exit(1);
});
