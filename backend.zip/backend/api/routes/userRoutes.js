const express = require("express");

const router = express.Router();

const userController = require("../controllers/userController");

const authMiddleware = require("../middlewares/authMiddleware");

router.get("/", [ authMiddleware.userIsLoggedIn, authMiddleware.isAdmin ], userController.getUsers);

router.post("/", userController.createUser);

router.get("/:userID/kuponok", 
    [ authMiddleware.userIsLoggedIn ], 
    userController.getCoupons
);

router.post("/:userID/kupon", 
    [ authMiddleware.userIsLoggedIn, authMiddleware.isAdmin ], 
    userController.addKuponToUser
);

router.param("userID", (req, res, next, userID) => 
{
    req.userID = userID;

    next();
});

router.patch("/termek-akcio/:termekID", 
    [ authMiddleware.userIsLoggedIn, authMiddleware.isAdmin ], 
    userController.updateProductDiscount
);
router.param("rendeles_id", (req, res, next, rendeles_id) => 
{
    req.rendeles_id = rendeles_id;

    next();
});
router.patch("/delivery/:rendeles_id", [ authMiddleware.userIsLoggedIn, authMiddleware.isAdmin ], userController.patchDelivery)

router.get("/:userID", userController.getUser);

module.exports = router;