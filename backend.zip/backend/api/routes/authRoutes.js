const express = require("express");
const router = express.Router();
const authController = require("../controllers/authController");
const authMiddleware = require("../middlewares/authMiddleware");

// --- Meglévő útvonalak ---
router.post("/login", authController.login);
router.get("/status", [ authMiddleware.userIsLoggedIn ], authController.status);
router.delete("/logout", authController.logout);

// --- ÚJ: Elfelejtett jelszó útvonalak ---

// ... importok változatlanok ...

// 1. Email küldése (Elfelejtett jelszó folyamat kezdete)
router.post("/forgot-password", authController.forgotPassword);

// 2. Új jelszó beállítása az emailben kapott TOKENNEL (ResetPassword.tsx-hez)
router.post("/reset-password", authController.resetPassword);

// 3. Jelszó módosítása a PROFIL oldalon (Bejelentkezve, régi jelszóval)
router.put("/change-password", [ authMiddleware.userIsLoggedIn ], authController.changePassword);

module.exports = router;

module.exports = router;