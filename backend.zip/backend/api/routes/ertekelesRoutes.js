const express = require("express");
const router = express.Router();
const ertekelesController = require("../controllers/ertekelesController");
const authMiddleware = require("../middlewares/authMiddleware");



router.param("termek_id", (req, res, next, termek_id) => {
    req.termek_id = termek_id;
    next();
});



router.get("/", ertekelesController.getErtekelesek);

router.post("/", [ authMiddleware.userIsLoggedIn], ertekelesController.postErtekeles);

router.get("/termek/:termek_id", ertekelesController.getErtekelesekByTermek);

router.param("id", (req, res, next, id) => {
    req.ertekeles_id = id;
    next();
});

router.get("/:id", ertekelesController.getErtekeles);

router.delete("/:id", ertekelesController.deleteErtekeles);

module.exports = router;