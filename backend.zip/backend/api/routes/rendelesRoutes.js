const express = require("express");

const router = express.Router();

const rendelesController = require("../controllers/rendelesController")



router.post("/", rendelesController.postRendeles);




module.exports = router; 