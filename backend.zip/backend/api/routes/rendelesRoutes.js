const express = require("express");
const router = express.Router();
const rendelesController = require("../controllers/rendelesController");

router.post("/", rendelesController.postRendeles);

router.get("/user/:userId", rendelesController.getUserRendelesek);

module.exports = router;