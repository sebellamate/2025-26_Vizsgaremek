const express = require("express");

const router = express.Router();

const rendelestetelController = require("../controllers/rendelestetelController");

router.post("/rendeles", rendelestetelController.postRendelestetelekandrendeles);


module.exports = router;