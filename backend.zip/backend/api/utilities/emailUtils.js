const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
    host: process.env.EMAIL_HOST || "smtp.gmail.com",
    port: process.env.EMAIL_PORT || 587,
    secure: false, 
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
    },
    tls: {
        rejectUnauthorized: false 
    }
});

const sendResetEmail = async (toEmail, token) => {
    const resetUrl = `http://localhost:3000/reset-password?token=${token}`;

    const mailOptions = {
        from: `"Webshop Support" <${process.env.EMAIL_USER}>`,
        to: toEmail,
        subject: "Jelszó visszaállítási kérelem",
        html: `
            <div style="font-family: sans-serif; border: 1px solid #e1e8ed; padding: 20px; border-radius: 10px; max-width: 500px; margin: auto;">
                <h2 style="color: #059669; text-align: center;">Elfelejtett jelszó</h2>
                <p>Kérted a jelszavad visszaállítását a webshopunkban. Kattints az alábbi gombra az új jelszó megadásához:</p>
                <div style="text-align: center; margin: 30px 0;">
                    <a href="${resetUrl}" style="background-color: #059669; color: white; padding: 12px 25px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">Jelszó megváltoztatása</a>
                </div>
                <p style="color: #6b7280; font-size: 0.9em;">Ez a link 1 óráig érvényes. Ha nem te kérted a visszaállítást, nyugodtan hagyd figyelmen kívül ezt az üzenetet.</p>
                <hr style="border: 0; border-top: 1px solid #e1e8ed; margin: 20px 0;">
                <p style="font-size: 0.8em; color: #9ca3af; text-align: center;">© 2024 Webshop Team</p>
            </div>
        `,
    };

    try {
        const info = await transporter.sendMail(mailOptions);
        console.log("E-mail sikeresen elküldve: %s", info.messageId);
        return info;
    } catch (error) {
        console.error("Hiba az e-mail küldésekor:", error);
        throw error; 
    }
};const sendKuponEmail = async (toEmail, userName, kuponKod, szazalek) => {
    const mailOptions = {
        from: `"Webshop Ajándék" <${process.env.EMAIL_USER}>`,
        to: toEmail,
        subject: "Meglepetésed érkezett! 🎁",
        html: `
            <div style="font-family: sans-serif; border: 1px solid #e1e8ed; padding: 20px; border-radius: 10px; max-width: 500px; margin: auto;">
                <h2 style="color: #059669; text-align: center;">Szia ${userName}!</h2>
                <p>Van egy jó hírünk: kaptál egy egyedi kedvezménykupont, amit a következő vásárlásodnál használhatsz fel.</p>
                
                <div style="background-color: #f3f4f6; border: 2px dashed #059669; padding: 20px; text-align: center; margin: 30px 0; border-radius: 10px;">
                    <span style="font-size: 1.2em; color: #374151;">A kuponkódod:</span><br>
                    <strong style="font-size: 2em; color: #059669; letter-spacing: 2px;">${kuponKod}</strong><br>
                    <span style="font-size: 1.5em; font-weight: bold; color: #059669;">-${szazalek}% kedvezmény</span>
                </div>

                <p style="text-align: center;">Másold ki a fenti kódot és írd be a pénztárnál a kedvezmény érvényesítéséhez!</p>
                
                <hr style="border: 0; border-top: 1px solid #e1e8ed; margin: 20px 0;">
                <p style="font-size: 0.8em; color: #9ca3af; text-align: center;">© 2024 Webshop Team</p>
            </div>
        `,
    };

    try {
        const info = await transporter.sendMail(mailOptions);
        console.log("Kupon e-mail elküldve: %s", info.messageId);
        return info;
    } catch (error) {
        console.error("Hiba a kupon e-mail küldésekor:", error);
    }
};

const sendOrderConfirmationEmail = async (toEmail, orderDetails) => {
    const { orderId, totalAmount, address } = orderDetails;

    const mailOptions = {
        from: `"Webshop Rendelés" <${process.env.EMAIL_USER}>`,
        to: toEmail,
        subject: `Rendelés visszaigazolás - #${orderId}`,
        html: `
            <div style="font-family: sans-serif; border: 1px solid #e1e8ed; padding: 20px; border-radius: 10px; max-width: 500px; margin: auto;">
                <h2 style="color: #059669; text-align: center;">Köszönjük a rendelésed!</h2>
                <p>Sikeresen felvettük a <strong>#${orderId}</strong> számú rendelésedet.</p>
                
                <div style="background-color: #f9fafb; padding: 15px; border-radius: 8px; margin: 20px 0;">
                    <h3 style="margin-top: 0; color: #374151; font-size: 1.1em;">Összegzés:</h3>
                    <p style="margin: 5px 0;"><strong>Végösszeg:</strong> ${totalAmount.toLocaleString('hu-HU')} Ft</p>
                    <p style="margin: 5px 0;"><strong>Szállítási cím:</strong> ${address}</p>
                </div>

                <p style="text-align: center; color: #4b5563;">A rendelésed feldolgozását megkezdtük. Hamarosan küldjük a további információkat a szállításról!</p>
                
                <hr style="border: 0; border-top: 1px solid #e1e8ed; margin: 20px 0;">
                <p style="font-size: 0.8em; color: #9ca3af; text-align: center;">© 2024 Webshop Team</p>
            </div>
        `,
    };

    try {
        const info = await transporter.sendMail(mailOptions);
        console.log("Rendelés visszaigazolás elküldve: %s", info.messageId);
        return info;
    } catch (error) {
        console.error("Hiba a rendelési e-mail küldésekor:", error);
    }
};
const sendShippingEmail = async (toEmail, userName, orderId) => {
    const mailOptions = {
        from: `"Webshop" <${process.env.EMAIL_USER}>`,
        to: toEmail,
        subject: `Rendelésed kiszállítva! ✅ - #${orderId}`,
        html: `
            <div style="font-family: sans-serif; border: 1px solid #e1e8ed; padding: 20px; border-radius: 10px; max-width: 500px; margin: auto;">
                <h2 style="color: #059669; text-align: center;">Szia ${userName}!</h2>
                <p>Örömmel értesítünk, hogy a <strong>#${orderId}</strong> számú rendelésed állapota megváltozott.</p>
                
                <div style="background-color: #f0fdf4; border-left: 4px solid #059669; padding: 15px; margin: 20px 0;">
                    <p style="margin: 0; color: #166534;"><strong>A csomagod státusza:</strong> Kiszállítva</p>
                </div>

                <p style="text-align: center; color: #4b5563;">Reméljük, elégedett vagy a termékekkel! Ha bármilyen kérdésed van, keress minket bizalommal.</p>
                
                <hr style="border: 0; border-top: 1px solid #e1e8ed; margin: 20px 0;">
                <p style="font-size: 0.8em; color: #9ca3af; text-align: center;">Köszönjük a vásárlást!<br>© 2024 Webshop Team</p>
            </div>
        `,
    };

    try {
        const info = await transporter.sendMail(mailOptions);
        console.log("Kiszállítási (Kiszállítva) e-mail elküldve: %s", info.messageId);
        return info;
    } catch (error) {
        console.error("Hiba a kiszállítási e-mail küldésekor:", error);
    }
};


module.exports = { 
    sendResetEmail, 
    sendKuponEmail, 
    sendOrderConfirmationEmail, 
    sendShippingEmail 
};