const nodemailer = require("nodemailer");

// Transporter konfiguráció - Gmailre optimalizálva, port és host nélkül
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS, 
    },
    tls: {
        // Kritikus beállítás iskolai/vállalati tűzfalak esetén
        rejectUnauthorized: false 
    }
});

// Kapcsolat ellenőrzése indításkor
transporter.verify((error) => {
    if (error) {
        console.error("SMTP hiba (valószínűleg a suli blokkolja):", error.message);
    } else {
        console.log("E-mail küldő szerver (Nodemailer) készen áll a munkára!");
    }
});

/**
 * Általános segédfüggvény az e-mailek kiküldéséhez
 */
const sendMailHelper = async (to, subject, html) => {
    const mailOptions = {
        from: `"Webshop Team" <${process.env.EMAIL_USER}>`,
        to: to,
        subject: subject,
        html: html
    };
    return await transporter.sendMail(mailOptions);
};

// --- 1. JELSZÓ VISSZAÁLLÍTÁS ---
const sendResetEmail = async (toEmail, token) => {
    const resetUrl = `${process.env.FRONTEND_URL || 'http://localhost:3000'}/reset-password?token=${token}`;
    const html = `
        <div style="font-family: sans-serif; border: 1px solid #e1e8ed; padding: 20px; border-radius: 10px; max-width: 500px; margin: auto;">
            <h2 style="color: #059669; text-align: center;">Jelszó visszaállítás</h2>
            <p>Kérted a jelszavad módosítását. Kattints az alábbi gombra:</p>
            <div style="text-align: center; margin: 30px 0;">
                <a href="${resetUrl}" style="background-color: #059669; color: white; padding: 12px 25px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">Új jelszó megadása</a>
            </div>
            <p style="color: #6b7280; font-size: 0.8em;">Ha nem te kérted, hagyd figyelmen kívül ezt a levelet.</p>
        </div>
    `;
    return sendMailHelper(toEmail, "Jelszó visszaállítási kérelem", html);
};

// --- 2. KUPON ÉRTESÍTŐ ---
const sendKuponEmail = async (toEmail, userName, kuponKod, szazalek) => {
    const html = `
        <div style="font-family: sans-serif; border: 1px solid #e1e8ed; padding: 20px; border-radius: 10px; max-width: 500px; margin: auto;">
            <h2 style="color: #059669; text-align: center;">Szia ${userName}! 🎁</h2>
            <p>Kaptál egy kedvezménykupont a következő vásárlásodhoz:</p>
            <div style="background-color: #f3f4f6; border: 2px dashed #059669; padding: 20px; text-align: center; margin: 20px 0; border-radius: 10px;">
                <strong style="font-size: 1.8em; color: #059669;">${kuponKod}</strong><br>
                <span style="font-size: 1.2em; font-weight: bold;">-${szazalek}% kedvezmény</span>
            </div>
        </div>
    `;
    return sendMailHelper(toEmail, "Meglepetésed érkezett! 🎁", html);
};

// --- 3. RENDELÉS MEGERŐSÍTÉS (HTML sablonnal) ---
const sendOrderSubmittedEmail = async (toEmail, rendeles_id) => {
    const html = `
      <div style="font-family: sans-serif; background-color: #f5f5f5; padding: 20px;">
        <div style="max-width: 600px; margin: auto; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 10px rgba(0,0,0,0.1);">
          <div style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 30px; text-align: center;">
            <h1 style="margin:0;">✓ Rendelés Megerősítve</h1>
          </div>
          <div style="padding: 30px;">
            <p>Kedves Vásárlónk!</p>
            <div style="background: #f0fdf4; border-left: 4px solid #10b981; padding: 15px; margin-bottom: 20px;">
              <strong>Rendelés száma: #${rendeles_id}</strong>
            </div>
            <p>Köszönjük a bizalmadat! A rendelésedet rögzítettük és munkatársaink hamarosan megkezdik a feldolgozását.</p>
            <div style="text-align: center; margin-top: 30px;">
                <a href="${process.env.FRONTEND_URL || 'http://localhost:3000'}/profile" style="background: #059669; color: white; padding: 12px 25px; text-decoration: none; border-radius: 8px; font-weight: bold;">Rendeléseim nyomon követése</a>
            </div>
          </div>
          <div style="background-color: #f9fafb; padding: 15px; text-align: center; border-top: 1px solid #eee;">
            <p style="font-size: 12px; color: #9ca3af;">© 2026 Webshop Team</p>
          </div>
        </div>
      </div>`;
    return sendMailHelper(toEmail, "✓ Rendelés Megerősítve - Webshop", html);
};

// --- 4. SZÁLLÍTÁSI ÉRTESÍTŐ ---
const sendShippingEmail = async (toEmail, rendeles_id) => {
    const html = `
      <div style="font-family: sans-serif; background-color: #f5f5f5; padding: 20px;">
        <div style="max-width: 600px; margin: auto; background: white; border-radius: 12px; overflow: hidden;">
          <div style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: white; padding: 30px; text-align: center;">
            <h1 style="margin:0;">Csomagod úton van! 📦</h1>
          </div>
          <div style="padding: 30px;">
            <p>Örömmel értesítünk, hogy a(z) <strong>#${rendeles_id}</strong> számú rendelésedet átadtuk a futárszolgálatnak.</p>
            <div style="background-color: #fffbeb; border-left: 4px solid #f59e0b; padding: 15px; margin: 20px 0;">
                <p style="margin:0; color: #92400e;">Státusz: <strong>Szállítás alatt</strong></p>
            </div>
            <p>A csomag várhatóan 1-2 munkanapon belül megérkezik.</p>
          </div>
          <div style="background-color: #f9fafb; padding: 15px; text-align: center;">
            <p style="font-size: 12px; color: #9ca3af;">Köszönjük, hogy nálunk vásároltál!</p>
          </div>
        </div>
      </div>`;
    return sendMailHelper(toEmail, "📦 Rendelésed Szállítás Alatt - Webshop", html);
};

module.exports = { 
    sendResetEmail, 
    sendKuponEmail, 
    sendOrderSubmittedEmail, 
    sendShippingEmail 
};