class RendelestetelService {
    constructor(db){
        this.rendelestetelRepository = require("../repositories")(db).rendelestetelRepository
    }
    async postRendelestetelek(data) {
        if (!data || !Array.isArray(data.tetelek) || data.tetelek.length === 0) {
            throw new Error("Nincs egyetlen rendeléstétel sem");
        }

        if (!data.rendelesId) {
            throw new Error("Hiányzik a rendelés azonosító");
        }

        const elokeszitettTetelek = data.tetelek.map(tetel => ({
            rendeles_id: data.rendeles_id,
            termek_id: tetel.termek_id,
            mennyiseg: tetel.mennyiseg,
            egyseg_ar: tetel.egyseg_ar,
        }));

        return await this.rendelestetelRepository.postRendelestetelek(
            elokeszitettTetelek
        );
    }
}
module.exports = RendelestetelService