const { BadRequestError, NotFoundError } = require("../errors");
const { sendOrderSubmittedEmail } = require("../utilities/emailUtils");

class RendelesTetelService {
    constructor(db) {
        this.db = db;
        // A repository-k betöltése a minta szerint
        const repositories = require("../repositories")(db);
        this.rendelesRepository = repositories.rendelesRepository;
        this.userRepository = repositories.userRepository;
    }

    /**
     * Új rendelés létrehozása a hozzá tartozó tételekkel együtt
     */
    async createRendelesWithTetelek({ vevo_id, osszeg, tetelek }) {
        // Alapvető validációk
        if (!vevo_id) throw new BadRequestError("Hiányzó felhasználó azonosító.");
        if (!osszeg || osszeg <= 0) throw new BadRequestError("A rendelés összege érvénytelen.");
        if (!tetelek || !Array.isArray(tetelek) || tetelek.length === 0) {
            throw new BadRequestError("A rendelésnek legalább egy tételt tartalmaznia kell.");
        }

        // Felhasználó ellenőrzése
        const user = await this.userRepository.getUserById(vevo_id);
        if (!user) throw new NotFoundError("A vásárló nem található.");

        // Tranzakció indítása (mivel több táblát érint a mentés)
        const t = await this.db.sequelize.transaction();

        try {
            // 1. Rendelés létrehozása a repository-n keresztül
            const rendeles = await this.rendelesRepository.createRendeles({
                vevo_id,
                osszeg,
                statusz: 'uj'
            }, { transaction: t });

            // 2. Tételek előkészítése és mentése
            const tetelekAdatai = tetelek.map(tetel => {
                if (!tetel.termek_id || !tetel.mennyiseg || !tetel.egyseg_ar) {
                    throw new BadRequestError("Hiányzó adatok a rendelés tételben.");
                }
                return {
                    rendeles_id: rendeles.rendeles_id,
                    termek_id: tetel.termek_id,
                    mennyiseg: tetel.mennyiseg,
                    egyseg_ar: tetel.egyseg_ar
                };
            });

            const mentettTetelek = await this.rendelesRepository.createRendelesTetelek(tetelekAdatai, { transaction: t });

            // Ha minden sikerült, véglegesítjük
            await t.commit();

            // 3. E-mail küldés a megadott emailUtils segítségével
            try {
                // A rendelés megerősítő e-mail küldése
                await sendOrderSubmittedEmail(user.email, rendeles.rendeles_id);
            } catch (emailError) {
                // Az e-mail hiba nem hiúsítja meg a vásárlást, csak logoljuk
                console.error("A rendelés mentve, de a megerősítő e-mail küldése sikertelen:", emailError.message);
            }

            return {
                rendeles,
                tetelek: mentettTetelek
            };

        } catch (error) {
            // Hiba esetén visszavonjuk a tranzakciót
            await t.rollback();
            // Ha már BadRequestError, továbbdobjuk, egyébként becsomagoljuk
            if (error instanceof BadRequestError) throw error;
            throw new Error("Hiba történt a rendelés mentése során: " + error.message);
        }
    }
}

module.exports = RendelesTetelService;