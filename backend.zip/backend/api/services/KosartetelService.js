class KosartetelService{
    constructor(db){
        this.kosartetelRepository = require("../repositories")(db).kosartetelRepository;
    }
    async postTetel(tetelData){
        return await this.kosartetelRepository.postTetel(tetelData);
    }
    async getTetel(id){
        return await this.kosartetelRepository.getTetel(id);
    }
    async getTetelek(id){
        return await this.kosartetelRepository.getTetelek(id);
    }
    async PlusOne(id){
        return await this.kosartetelRepository.PlusOne(id);
    }
    async MinusOne(id){
        return await this.kosartetelRepository.MinusOne(id);
    }
    async deleteTetel(id){
        return await this.kosartetelRepository.deleteTetel(id);
    }
}
module.exports = KosartetelService;