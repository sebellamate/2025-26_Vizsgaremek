const { BadRequestError, NotFoundError } = require("../errors");

class TermekService {
    constructor(db) {
        this.termekRepository = require("../repositories")(db).termekRepository;
    }

    async getTermekek() {
        // Egyszerű lekérés, a hiba a repóban lesz kezelve (DbError)
        return await this.termekRepository.getTermekek();
    }

    async postTermek(termekData) {
        if (!termekData || Object.keys(termekData).length === 0) {
            throw new BadRequestError("Hiányzó termék adatok.");
        }
        return await this.termekRepository.postTermek(termekData);
    }

    async getTermek(termek_id) {
        if (!termek_id) throw new BadRequestError("Hiányzó termék azonosító.");
        
        const termek = await this.termekRepository.getTermek(termek_id);
        
        if (!termek) {
            throw new NotFoundError("A termék nem található.", { data: termek_id });
        }
        return termek;
    }

    async deleteTermek(termek_id) {
        if (!termek_id) throw new BadRequestError("Hiányzó termék azonosító a törléshez.");
        
        // Először ellenőrizzük, létezik-e, mielőtt törölnénk
        await this.getTermek(termek_id); 
        
        return await this.termekRepository.deleteTermek(termek_id);
    }

    async editTermek(termek_id, termekData) {
        if (!termek_id) throw new BadRequestError("Hiányzó termék azonosító a módosításhoz.");
        if (!termekData || Object.keys(termekData).length === 0) {
            throw new BadRequestError("Nincsenek módosítandó adatok megadva.");
        }

        // Ellenőrizzük a létezést
        await this.getTermek(termek_id);

        return await this.termekRepository.editTermek(termek_id, termekData);
    }

    async getTermekekBykosar_id(kosar_id) {
        if (!kosar_id) throw new BadRequestError("Hiányzó kosár azonosító.");
        return await this.termekRepository.getTermekekBykosar_id(kosar_id);
    }
    
    async getTermekekBy_ids(ids) {
        if (!ids || !Array.isArray(ids)) {
            throw new BadRequestError("Érvénytelen vagy hiányzó azonosító lista.");
        }
        return await this.termekRepository.getTermekekBy_ids(ids);
    }

    async keresTermek(keres) {
        if (keres === undefined || keres === null) {
            throw new BadRequestError("Hiányzó keresési feltétel.");
        }
        return await this.termekRepository.keresTermek(keres);
    }

    async getTermekekByKategoria(kategoriaId) {
        if (!kategoriaId) throw new BadRequestError("Hiányzó kategória azonosító.");
        return await this.termekRepository.getTermekekByKategoria(kategoriaId);
    }
}

module.exports = TermekService;