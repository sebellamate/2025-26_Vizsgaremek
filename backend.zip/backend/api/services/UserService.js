const { BadRequestError, NotFoundError } = require("../errors");

class UserService
{
    constructor(db)
    {
        this.userRepository = require("../repositories")(db).userRepository;
    }

    async getUsers()
    {
        return await this.userRepository.getUsers();
    }

    async getUser(userID)
    {
        if(!userID) throw new BadRequestError("Missing user identification from payload");

        const user = await this.userRepository.getUser(userID);

        if(!user) throw new NotFoundError("Can not found user with this user identification", 
        {
            data: userID
        });

        return user;
    }

    async createUser(userData) {
    if (!userData) throw new BadRequestError("Hiányzó adatok");
    if (!userData.name) throw new BadRequestError("A felhasználónév megadása kötelező");
    if (!userData.email) throw new BadRequestError("Az email cím megadása kötelező");
    if (!userData.password) throw new BadRequestError("A jelszó megadása kötelező");

    // 2. Egyediség ellenőrzése a Service-ben
    // Itt meghívjuk a Repository-t (ezt a metódust meg kell írnod a repóban)
    const existingUser = await this.userRepository.getUserByEmailOrName(userData.email, userData.name);

    if (existingUser) {
        if (existingUser.name === userData.name) {
            throw new BadRequestError("Ez a felhasználónév már foglalt.");
        }
        if (existingUser.email === userData.email) {
            throw new BadRequestError("Ez az email cím már regisztrálva van.");
        }
    }

    // 3. Mentés
    try {
        return await this.userRepository.createUser(userData);
    } catch (error) {
        throw new DbError("Hiba az adatbázis mentés során", { details: error });
    }
}
}

module.exports = UserService;