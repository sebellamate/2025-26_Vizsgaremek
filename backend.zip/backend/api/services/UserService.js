const { BadRequestError, NotFoundError } = require("../errors");
const crypto = require("crypto"); 
const bcrypt = require("bcrypt"); 
const { sendResetEmail, sendKuponEmail, sendShippingEmail} = require("../utilities/emailUtils");

class UserService {
    constructor(db) {
        // Feltételezzük, hogy a repository index fájlja helyesen adja vissza a repókat
        const repositories = require("../repositories")(db);
        this.userRepository = repositories.userRepository;
        this.termekRepository = repositories.termekRepository;
    }

    async patchDelivery(rendeles_id) {
        if (!rendeles_id) throw new BadRequestError("Missing order identification from payload");

        const updatedOrder = await this.userRepository.patchDelivery(rendeles_id);
        try {
            const user = await this.userRepository.getUserById(updatedOrder.user_id);
            
            if (user) {
                await sendShippingEmail(user.email, user.name, rendeles_id);
            }
        } catch (emailError) {
            console.error("A státusz frissült, de az e-mail küldés sikertelen:", emailError);
        }

        return updatedOrder;
    }
    async getUsers() {
        return await this.userRepository.getUsers();
    }

    async getUser(userID) {
        if (!userID) throw new BadRequestError("Missing user identification from payload");
        const user = await this.userRepository.getUser(userID);
        if (!user) throw new NotFoundError("Can not found user with this user identification", { data: userID });
        return user;
    }

    async getUserCoupons(userID) {
        if (!userID) throw new BadRequestError("Hiányzó felhasználó azonosító.");
        
        // Ellenőrizzük, létezik-e a user
        const user = await this.userRepository.getUserById(userID);
        if (!user) throw new NotFoundError("Felhasználó nem található.");

        return await this.userRepository.getUserCoupons(userID);
    }

    async updateProductDiscount(termekID, akcio) {
        if (!termekID) throw new BadRequestError("Hiányzó termék azonosító.");
        
        if (akcio === undefined || akcio === null) {
            throw new BadRequestError("Az akció mértékének megadása kötelező.");
        }

        const discountValue = parseInt(akcio);
        if (isNaN(discountValue) || discountValue < 0 || discountValue > 100) {
            throw new BadRequestError("Az akciónak 0 és 100 közötti számnak kell lennie.");
        }

        const termek = await this.termekRepository.getTermek(termekID);
        if (!termek) {
            throw new NotFoundError("A keresett termék nem található.", { data: termekID });
        }

        // Itt a userRepository-ban lévő metódust hívjuk, mert ott írtuk meg az updateProductDiscount-ot
        return await this.userRepository.updateProductDiscount(termekID, discountValue);
    }

    async addKuponToUser(userID, kod, szazalek) {
        if (!userID) throw new BadRequestError("Hiányzó felhasználó azonosító.");
        if (!kod || kod.trim() === "") throw new BadRequestError("A kupon kód megadása kötelező.");
        
        if (szazalek === undefined || szazalek === null) {
            throw new BadRequestError("A kedvezmény mértékének megadása kötelező.");
        }

        const discountValue = parseInt(szazalek);
        if (isNaN(discountValue) || discountValue < 1 || discountValue > 100) {
            throw new BadRequestError("A kedvezménynek 1 és 100 közötti számnak kell lennie.");
        }

        // 1. Felhasználó lekérése az adatbázisból (kell az email és a név az üzenethez)
        const user = await this.userRepository.getUserById(userID);
        if (!user) {
            throw new NotFoundError("A megadott felhasználó nem található.", { data: userID });
        }

        // 2. Kupon mentése az adatbázisba
        const newKupon = await this.userRepository.createKupon({
            user_id: userID,
            kod: kod.toUpperCase(),
            szazalek: discountValue,
            ervenyes: true
        });

        // 3. E-mail küldése (már megvannak a user adatai az 1. lépésből)
        try {
            // Nem kötelező megvárni (await), de érdemes, ha látni akarod a sikert
            await sendKuponEmail(user.email, user.name, newKupon.kod, newKupon.szazalek);
        } catch (emailError) {
            // Ha az e-mail nem megy el, a kupon már az adatbázisban van.
            // Itt eldöntheted, hogy csak logolod a hibát, vagy errort dobsz.
            console.error("A kupon elkészült, de az e-mail küldés sikertelen volt:", emailError);
        }

        return newKupon;
    }

    async requestPasswordReset(email) {
        if (!email) throw new BadRequestError("Az email cím megadása kötelező");

        const user = await this.userRepository.getUserByEmail(email);

        // Biztonsági okokból true-t adunk vissza akkor is, ha nincs ilyen email
        if (!user) return true;

        const token = crypto.randomBytes(32).toString("hex");
        const expires = new Date(Date.now() + 3600000); 

        await this.userRepository.updateUserResetToken(user.ID, token, expires);
        await sendResetEmail(user.email, token);

        return true;
    }

    async resetPassword(token, newPassword) {
        if (!token) throw new BadRequestError("Hiányzó visszaállító token");
        if (!newPassword) throw new BadRequestError("Az új jelszó megadása kötelező");

        const user = await this.userRepository.getUserByResetToken(token);

        if (!user) {
            throw new BadRequestError("A visszaállító link érvénytelen vagy lejárt.");
        }

        await this.userRepository.updateUserPassword(user.ID, newPassword);

        return true;
    }

    async changePassword(userID, currentPassword, newPassword) {
        if (!userID) throw new BadRequestError("Hiányzó felhasználói azonosító.");

        const user = await this.userRepository.getUser(userID);
        
        if (!user) {
            throw new NotFoundError("Felhasználó nem található a rendszerben.");
        }

        const isMatch = await bcrypt.compare(currentPassword, user.password);
        
        if (!isMatch) {
            throw new BadRequestError("A jelenlegi jelszó hibás!");
        }

        return await this.userRepository.updateUserPassword(user.ID, newPassword);
    }

    async createUser(userData) {
        if (!userData) throw new BadRequestError("Hiányzó adatok");
        if (!userData.name) throw new BadRequestError("A felhasználónév megadása kötelező");
        if (!userData.email) throw new BadRequestError("Az email cím megadása kötelező");
        if (!userData.password) throw new BadRequestError("A jelszó megadása kötelező");

        const existingUser = await this.userRepository.getUserByEmailOrName(userData.email, userData.name);

        if (existingUser) {
            if (existingUser.name === userData.name) throw new BadRequestError("Ez a felhasználónév már foglalt.");
            if (existingUser.email === userData.email) throw new BadRequestError("Ez az email cím már regisztrálva van.");
        }

        return await this.userRepository.createUser(userData);
    }
}

module.exports = UserService;