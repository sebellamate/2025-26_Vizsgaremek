const { BadRequestError, NotFoundError } = require("../errors");
const crypto = require("crypto"); 
const bcrypt = require("bcrypt"); 
const { sendResetEmail, sendKuponEmail } = require("../utilities/emailUtils");

class UserService {
    constructor(db) {
        // A repository-k betöltése
        const repositories = require("../repositories")(db);
        this.userRepository = repositories.userRepository;
        this.termekRepository = repositories.termekRepository;
    }

    // --- Felhasználó lekérése ---
    async getUsers() {
        return await this.userRepository.getUsers();
    }

    async getUser(userID) {
        if (!userID) throw new BadRequestError("Hiányzó felhasználó azonosító.");
        const user = await this.userRepository.getUser(userID);
        if (!user) throw new NotFoundError("A felhasználó nem található.", { data: userID });
        return user;
    }

    // --- Kuponok kezelése ---
    async getUserCoupons(userID) {
        if (!userID) throw new BadRequestError("Hiányzó felhasználó azonosító.");
        const user = await this.userRepository.getUserById(userID);
        if (!user) throw new NotFoundError("A felhasználó nem található.");
        return await this.userRepository.getUserCoupons(userID);
    }

    async addKuponToUser(userID, kod, szazalek) {
        if (!userID) throw new BadRequestError("Hiányzó felhasználó azonosító.");
        if (!kod || kod.trim() === "") throw new BadRequestError("A kupon kód megadása kötelező.");
        
        const discountValue = parseInt(szazalek);
        if (isNaN(discountValue) || discountValue < 1 || discountValue > 100) {
            throw new BadRequestError("A kedvezménynek 1 és 100 közötti számnak kell lennie.");
        }

        const user = await this.userRepository.getUserById(userID);
        if (!user) throw new NotFoundError("A megadott felhasználó nem található.", { data: userID });

        // Kupon mentése az adatbázisba
        const newKupon = await this.userRepository.createKupon({
            user_id: userID,
            kod: kod.toUpperCase(),
            szazalek: discountValue,
            ervenyes: true
        });

        // E-mail küldés (ha a suli blokkolja, a konzolban hiba lesz, de a kupon megmarad)
        try {
            await sendKuponEmail(user.email, user.name, newKupon.kod, newKupon.szazalek);
        } catch (emailError) {
            console.error("A kupon mentve, de az e-mail küldés sikertelen:", emailError.message);
        }

        return newKupon;
    }

    // --- Termék akciók ---
    async updateProductDiscount(termekID, akcio) {
        if (!termekID) throw new BadRequestError("Hiányzó termék azonosító.");
        const discountValue = parseInt(akcio);
        if (isNaN(discountValue) || discountValue < 0 || discountValue > 100) {
            throw new BadRequestError("Az akciónak 0 és 100 közötti számnak kell lennie.");
        }

        const termek = await this.termekRepository.getTermek(termekID);
        if (!termek) throw new NotFoundError("A termék nem található.", { data: termekID });

        return await this.userRepository.updateProductDiscount(termekID, discountValue);
    }

    // --- Jelszó visszaállítás (Elfelejtett jelszó) ---
    async requestPasswordReset(email) {
        if (!email) throw new BadRequestError("Az email cím megadása kötelező.");
        const user = await this.userRepository.getUserByEmail(email);
        
        // Biztonsági okokból true-t adunk vissza akkor is, ha nincs ilyen email
        if (!user) return true;

        const token = crypto.randomBytes(32).toString("hex");
        const expires = new Date(Date.now() + 3600000); // 1 óra érvényesség

        await this.userRepository.updateUserResetToken(user.ID, token, expires);
        
        try {
            await sendResetEmail(user.email, token);
        } catch (error) {
            console.error("Hiba a reset e-mail küldésekor:", error.message);
        }
        
        return true;
    }

    async resetPassword(token, newPassword) {
        if (!token) throw new BadRequestError("Hiányzó visszaállító token.");
        if (!newPassword) throw new BadRequestError("Az új jelszó megadása kötelező.");

        const user = await this.userRepository.getUserByResetToken(token);
        if (!user) throw new BadRequestError("A visszaállító link érvénytelen vagy lejárt.");

        await this.userRepository.updateUserPassword(user.ID, newPassword);
        return true;
    }

    // --- Jelszó módosítás (Profilból) ---
    async changePassword(userID, currentPassword, newPassword) {
        if (!userID) throw new BadRequestError("Hiányzó felhasználói azonosító.");
        const user = await this.userRepository.getUser(userID);
        if (!user) throw new NotFoundError("Felhasználó nem található.");

        const isMatch = await bcrypt.compare(currentPassword, user.password);
        if (!isMatch) throw new BadRequestError("A jelenlegi jelszó hibás!");

        return await this.userRepository.updateUserPassword(user.ID, newPassword);
    }

    // --- Regisztráció ---
    async createUser(userData) {
        if (!userData || !userData.email || !userData.name || !userData.password) {
            throw new BadRequestError("Hiányzó adatok a regisztrációhoz.");
        }

        const existingUser = await this.userRepository.getUserByEmailOrName(userData.email, userData.name);
        if (existingUser) {
            if (existingUser.name === userData.name) throw new BadRequestError("Ez a felhasználónév már foglalt.");
            if (existingUser.email === userData.email) throw new BadRequestError("Ez az email cím már foglalt.");
        }

        return await this.userRepository.createUser(userData);
    }
}

module.exports = UserService;