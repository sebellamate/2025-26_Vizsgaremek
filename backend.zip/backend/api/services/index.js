const UserService = require("./UserService")
const TermekService = require("./TermekService")
const KategoriaService = require("./KategoriaService")
const KosartetelService = require("./KosartetelService")
const RendelesService = require("./RendelesService")
const ErtekelesService = require("./ErtekelesService")

module.exports = (db) =>
{
    const userService = new UserService(db);
    const termekService = new TermekService(db);
    const kategoriaService = new KategoriaService(db);
    const kosartetelService = new KosartetelService(db);
    const rendelesService = new RendelesService(db);
    const ertekelesService = new ErtekelesService(db)

    return { userService, termekService, kategoriaService, kosartetelService,  rendelesService, ertekelesService };
}