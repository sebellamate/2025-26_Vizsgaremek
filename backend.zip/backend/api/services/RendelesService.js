const { sendOrderConfirmationEmail } = require("../utilities/emailUtils");

class RendelesService {
    constructor(db) {
        this.sequelize = db.sequelize;
        this.db = db;
        this.rendelesRepository = require("../repositories")(db).rendelesRepository;
    }

    async getUserRendelesek(userId) {
        return await this.rendelesRepository.getRendelesekByUserId(userId);
    }

    async postRendeles(data) {
        // 1. Alapvető ellenőrzés a tételekre
        if (!data.tetelek || !Array.isArray(data.tetelek) || data.tetelek.length === 0) {
            throw new Error("Nincs egyetlen rendeléstétel sem");
        }

        let ujRendeles;

        // Tranzakció indítása: ha bármi elszáll, semmi nem mentődik el az adatbázisba
        await this.sequelize.transaction(async (t) => {
            
            // 2. A fő rendelés létrehozása
            // Fontos: a repository-nak vissza KELL adnia a létrehozott objektumot!
            ujRendeles = await this.rendelesRepository.createRendeles({
                user_id: Number(data.user_id),
                osszeg: Number(data.osszeg),
                cim: data.cim,
                rendeles_datuma: new Date(),
                statusz: 'fizetve'
            }, t);

            if (!ujRendeles || !ujRendeles.rendeles_id) {
                throw new Error("Sikertelen rendelés létrehozás: nincs rendeles_id");
            }

            // 3. Kupon érvénytelenítése (ha van)
            // Itt védjük ki a "none" string vagy null miatti SQL hibát
            const validKuponId = (data.kupon_id !== "none" && data.kupon_id !== null && data.kupon_id !== undefined) 
                ? Number(data.kupon_id) 
                : null;

            if (validKuponId && !isNaN(validKuponId)) {
                await this.rendelesRepository.invalidateKupon(
                    validKuponId, 
                    data.user_id, 
                    t
                );
            }

            // 4. Rendelési tételek előkészítése és mentése
            const elokeszitettTetelek = data.tetelek.map(tetel => {
                if (!tetel.termek_id || !tetel.mennyiseg) {
                    throw new Error("Hibás tételadatok (hiányzó termék ID vagy mennyiség)");
                }
                return {
                    rendeles_id: ujRendeles.rendeles_id,
                    termek_id: Number(tetel.termek_id),
                    mennyiseg: Number(tetel.mennyiseg),
                    egyseg_ar: Number(tetel.egyseg_ar),
                };
            });

            await this.rendelesRepository.createRendelesTetelek(elokeszitettTetelek, t);

            // 5. Kosár ürítése a sikeres mentés után
            await this.rendelesRepository.emptyBasket(data.user_id, t);
        });

        // 6. Email küldés a tranzakción kívül (hogy ne blokkolja az adatbázist)
        try {
            const user = await this.db.User.findByPk(data.user_id);
            if (user && user.email) {
                await sendOrderConfirmationEmail(user.email, {
                    orderId: ujRendeles.rendeles_id,
                    totalAmount: data.osszeg,
                    address: data.cim,
                    items: data.tetelek
                });
            }
        } catch (emailError) {
            // Az email hiba nem vonja vissza a rendelést, csak logoljuk
            console.error("Nem sikerült kiküldeni a visszaigazoló e-mailt:", emailError);
        }

        return ujRendeles;
    }
}

module.exports = RendelesService;