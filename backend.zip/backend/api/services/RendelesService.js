const { sendOrderConfirmationEmail } = require("../utilities/emailUtils");

class RendelesService {
    constructor(db) {
        this.sequelize = db.sequelize;
        this.db = db;
        this.rendelesRepository = require("../repositories")(db).rendelesRepository
    }

    async getUserRendelesek(userId) {
        return await this.rendelesRepository.getRendelesekByUserId(userId);
    }

    async postRendeles(data) {
        if (!data.tetelek || !Array.isArray(data.tetelek) || data.tetelek.length === 0) {
            throw new Error("Nincs egyetlen rendeléstétel sem");
        }

        let ujRendeles;

        await this.sequelize.transaction(async (t) => {
            ujRendeles = await this.rendelesRepository.createRendeles({
                user_id: data.user_id,
                osszeg: data.osszeg,
                cim: data.cim,
                rendeles_datuma: new Date(),
                statusz: 'fizetve'
            }, t);

            const elokeszitettTetelek = data.tetelek.map(tetel => ({
                rendeles_id: ujRendeles.rendeles_id,
                termek_id: tetel.termek_id,
                mennyiseg: tetel.mennyiseg,
                egyseg_ar: tetel.egyseg_ar,
            }));

            await this.rendelesRepository.createRendelesTetelek(elokeszitettTetelek, t);
            await this.rendelesRepository.emptyBasket(data.user_id, t);
        });

        try {
            const user = await this.db.User.findByPk(data.user_id);
            
            if (user && user.email) {
                sendOrderConfirmationEmail(user.email, {
                    orderId: ujRendeles.rendeles_id,
                    totalAmount: data.osszeg,
                    address: data.cim,
                    items: data.tetelek
                });
            }
        } catch (emailError) {
            console.error("Nem sikerült kiküldeni a visszaigazoló e-mailt:", emailError);
        }

        return ujRendeles;
    }
}

module.exports = RendelesService;