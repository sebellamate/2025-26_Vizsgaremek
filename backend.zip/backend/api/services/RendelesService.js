const { sendOrderConfirmationEmail } = require("../utilities/emailUtils");

class RendelesService {
    constructor(db) {
        this.sequelize = db.sequelize;
        this.db = db; // Eltároljuk a db-t a felhasználó lekéréséhez
        const repos = require("../repositories")(db);
        this.rendelesRepository = repos.rendelesRepository;
    }

    async postRendeles(data) {
        if (!data.tetelek || !Array.isArray(data.tetelek) || data.tetelek.length === 0) {
            throw new Error("Nincs egyetlen rendeléstétel sem");
        }

        let ujRendeles;

        // 1. Adatbázis műveletek (Tranzakció)
        await this.sequelize.transaction(async (t) => {
            ujRendeles = await this.rendelesRepository.createRendeles({
                user_id: data.user_id,
                osszeg: data.osszeg,
                cim: data.cim,
                rendeles_datuma: new Date(),
                statusz: 'fizetve'
            }, t);

            const elokeszitettTetelek = data.tetelek.map(tetel => ({
                rendeles_id: ujRendeles.rendeles_id,
                termek_id: tetel.termek_id,
                mennyiseg: tetel.mennyiseg,
                egyseg_ar: tetel.egyseg_ar,
            }));

            await this.rendelesRepository.createRendelesTetelek(elokeszitettTetelek, t);
            await this.rendelesRepository.emptyBasket(data.user_id, t);
        });

        // 2. E-mail küldés a sikeres tranzakció után (Async, nem várjuk meg a választ)
        try {
            // Felhasználó e-mail címének lekérése
            // Feltételezve, hogy a User modell elérhető így:
            const user = await this.db.User.findByPk(data.user_id);
            
            if (user && user.email) {
                sendOrderConfirmationEmail(user.email, {
                    orderId: ujRendeles.rendeles_id,
                    totalAmount: data.osszeg,
                    address: data.cim,
                    items: data.tetelek
                });
            }
        } catch (emailError) {
            // Csak logoljuk, nem akasztjuk meg a folyamatot, ha az e-mail nem megy el
            console.error("Nem sikerült kiküldeni a visszaigazoló e-mailt:", emailError);
        }

        return ujRendeles;
    }
}

module.exports = RendelesService;