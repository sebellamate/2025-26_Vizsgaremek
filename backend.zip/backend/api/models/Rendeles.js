const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
    class Rendeles extends Model {};

    Rendeles.init({
        rendeles_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true,
        }, user_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
        }, rendeles_datuma: {
            type: DataTypes.DATE,
            allowNull: false,
            defaultValue: DataTypes.NOW
        }, statusz: {
            type: DataTypes.ENUM('fizetve', 'szallitva', 'torolve'),
            allowNull: false,
            defaultValue: 'fizetve'
        }, osszeg: {
            type: DataTypes.DECIMAL(10, 2),
            allowNull: false,
        },cim: {
            type: DataTypes.STRING,
            allowNull: false
        }
    }, {sequelize, modelName: "Rendeles", freezeTableName: true, timestamps: false});

    return Rendeles;
}