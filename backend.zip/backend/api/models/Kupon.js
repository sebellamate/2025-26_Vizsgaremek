const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
    class Kupon extends Model {};

    Kupon.init({
        kupon_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true,
        },
        user_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        kod: {
            type: DataTypes.STRING(20),
            allowNull: false,
            unique: "idx_kupon_kod",
        },
        szazalek: {
            type: DataTypes.INTEGER,
            allowNull: false,
            validate: {
                min: 1,
                max: 100
            }
        },
        ervenyes: {
            type: DataTypes.BOOLEAN,
            defaultValue: true,
        }
    }, {
        sequelize, 
        modelName: "Kupon", 
        tableName: "kuponok", 
        freezeTableName: true,
        timestamps: false 
    });

    return Kupon;
}