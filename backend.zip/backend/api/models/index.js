const { DataTypes } = require("sequelize");

module.exports = (sequelize) => {
    const User = require("./User")(sequelize, DataTypes);
    const Kategoria = require("./Kategoria")(sequelize, DataTypes);
    const Termek = require("./Termek")(sequelize, DataTypes);
    const Rendeles = require("./Rendeles")(sequelize, DataTypes);
    const RendelesTetel = require("./RendelesTetel")(sequelize, DataTypes);
    const KosarTetel = require("./KosarTetel")(sequelize, DataTypes);
    const Kupon = require("./Kupon")(sequelize, DataTypes);

    // Kategória - Termék kapcsolat
    Termek.belongsTo(Kategoria, {
        foreignKey: "kategoria_id",
    });

    // Rendelés - Felhasználó kapcsolat
    Rendeles.belongsTo(User, {
        foreignKey: "vevo_id", // Rendeles.js: vevo_id
        as: "Vevo",
    });

    User.hasMany(Rendeles, {
        foreignKey: "vevo_id",
        as: "Rendeles",
    });

    // --- MODOSITOTT RENDELÉS KAPCSOLATOK ---

    // Rendelés -> Rendelés Tételek (hogy le lehessen kérni a tételeket a rendeléssel együtt)
    Rendeles.hasMany(RendelesTetel, {
        foreignKey: "rendeles_id", // RendelesTetel.js: rendeles_id
        as: "Tetelek",
        onDelete: "CASCADE",
    });

    RendelesTetel.belongsTo(Rendeles, {
        foreignKey: "rendeles_id",
    });

    // Rendelés Tetel -> Termék (hogy lássuk, melyik termék az adott tételben)
    RendelesTetel.belongsTo(Termek, {
        foreignKey: "termek_id", // RendelesTetel.js: termek_id
        as: "Termek"
    });

    // Termék -> Rendelés Tételek (visszafelé irány)
    Termek.hasMany(RendelesTetel, {
        foreignKey: "termek_id",
    });

    // --- EREDETI TÖBBI KAPCSOLAT (VÁLTOZATLAN) ---

    // Felhasználó - Kupon kapcsolat
    User.hasMany(Kupon, {
        foreignKey: "user_id",
        as: "Kuponok",
        onDelete: "CASCADE",
    });

    Kupon.belongsTo(User, {
        foreignKey: "user_id",
        as: "Tulajdonos",
    });

    // KOSÁR TÉTELEK KAPCSOLATAI
    User.hasMany(KosarTetel, {
        foreignKey: "user_id",
        as: "KosarTetelek",
        onDelete: "CASCADE",
    });

    KosarTetel.belongsTo(User, {
        foreignKey: "user_id",
        as: "Vevo",
    });

    KosarTetel.belongsTo(Termek, {
        foreignKey: "termek_id",
        as: "Termek",
    });

    return {
        User,
        Kategoria,
        Termek,
        Rendeles,
        RendelesTetel,
        KosarTetel,
        Kupon,
    };
};