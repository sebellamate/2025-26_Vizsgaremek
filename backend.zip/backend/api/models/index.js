const { DataTypes } = require("sequelize");

module.exports = (sequelize) => {
    const User = require("./User")(sequelize, DataTypes);
    const Kategoria = require("./Kategoria")(sequelize, DataTypes);
    const Termek = require("./Termek")(sequelize, DataTypes);
    const Rendeles = require("./Rendeles")(sequelize, DataTypes);
    const RendelesTetel = require("./RendelesTetel")(sequelize, DataTypes);
    const KosarTetel = require("./KosarTetel")(sequelize, DataTypes);
    const Kupon = require("./Kupon")(sequelize, DataTypes);
    const Ertekeles = require("./Ertekeles")(sequelize, DataTypes);

    // Kategória - Termék kapcsolat
    Termek.belongsTo(Kategoria, {
        foreignKey: "kategoria_id",
    });

    // --- JAVÍTOTT RÉSZ: Rendelés - Felhasználó kapcsolat ---
    Rendeles.belongsTo(User, {
        foreignKey: "user_id", // vevo_id-ról user_id-ra módosítva
        as: "Vevo",
    });

    User.hasMany(Rendeles, {
        foreignKey: "user_id", // vevo_id-ról user_id-ra módosítva
        as: "Rendelesek",
    });
    // ------------------------------------------------------

    // Felhasználó - Kupon kapcsolat
    User.hasMany(Kupon, {
        foreignKey: "user_id",
        as: "Kuponok",
        onDelete: "CASCADE",
    });

    Kupon.belongsTo(User, {
        foreignKey: "user_id",
        as: "Tulajdonos",
    });

    // Rendelés Tételek kapcsolatai
    RendelesTetel.belongsTo(Rendeles, {
        foreignKey: "rendeles_id",
    });

    RendelesTetel.belongsTo(Termek, {
        foreignKey: "termek_id",
    });

    User.hasMany(KosarTetel, {
        foreignKey: "user_id",
        as: "KosarTetelek",
        onDelete: "CASCADE",
    });

    KosarTetel.belongsTo(User, {
        foreignKey: "user_id",
        as: "Vevo",
    });

    KosarTetel.belongsTo(Termek, {
        foreignKey: "termek_id",
        as: "Termek",
    });
    User.hasMany(Ertekeles, {
        foreignKey: "user_id",
        as: "Ertekelesei",
        onDelete: "CASCADE",
    });

    Ertekeles.belongsTo(User, {
        foreignKey: "user_id",
        as: "Iro",
    });

    Termek.hasMany(Ertekeles, {
        foreignKey: "termek_id",
        as: "Ertekelesek",
        onDelete: "CASCADE",
    });

    Ertekeles.belongsTo(Termek, {
        foreignKey: "termek_id",
        as: "Termek",
    });

    return {
        User,
        Kategoria,
        Termek,
        Rendeles,
        RendelesTetel,
        KosarTetel,
        Kupon,
        Ertekeles
    };
};