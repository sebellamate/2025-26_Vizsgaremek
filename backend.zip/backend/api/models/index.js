const { DataTypes } = require("sequelize");

module.exports = (sequelize) => {
    const User = require("./User")(sequelize, DataTypes);
    const Kategoria = require("./Kategoria")(sequelize, DataTypes);
    const Termek = require("./Termek")(sequelize, DataTypes);
    const Rendeles = require("./Rendeles")(sequelize, DataTypes);
    const RendelesTetel = require("./RendelesTetel")(sequelize, DataTypes);
    const KosarTetel = require("./KosarTetel")(sequelize, DataTypes);
    const Kupon = require("./Kupon")(sequelize, DataTypes);

    // Kategória - Termék kapcsolat
    Termek.belongsTo(Kategoria, {
        foreignKey: "kategoria_id",
    });

    // Rendelés - Felhasználó kapcsolat
    Rendeles.belongsTo(User, {
        foreignKey: "vevo_id",
        as: "Vevo",
    });

    User.hasMany(Rendeles, {
        foreignKey: "vevo_id",
        as: "Rendeles",
    });

    // Felhasználó - Kupon kapcsolat
    User.hasMany(Kupon, {
        foreignKey: "user_id",
        as: "Kuponok",
        onDelete: "CASCADE",
    });

    Kupon.belongsTo(User, {
        foreignKey: "user_id",
        as: "Tulajdonos",
    });

    // Rendelés Tételek kapcsolatai
    RendelesTetel.belongsTo(Rendeles, {
        foreignKey: "rendeles_id",
    });

    RendelesTetel.belongsTo(Termek, {
        foreignKey: "termek_id",
    });

    // KOSÁR TÉTELEK KAPCSOLATAI (user_id-val)
    User.hasMany(KosarTetel, {
        foreignKey: "user_id", // JAVÍTVA: kosar_id-ról user_id-ra
        as: "KosarTetelek",
        onDelete: "CASCADE",
    });

    KosarTetel.belongsTo(User, {
        foreignKey: "user_id", // JAVÍTVA: kosar_id-ról user_id-ra
        as: "Vevo",
    });

    KosarTetel.belongsTo(Termek, {
        foreignKey: "termek_id",
        as: "Termek",
    });

    return {
        User,
        Kategoria,
        Termek,
        Rendeles,
        RendelesTetel,
        KosarTetel,
        Kupon,
    };
};