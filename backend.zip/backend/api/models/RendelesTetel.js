const {Model} = require("sequelize");

module.exports = (sequelize, DataTypes) => {
    class RendelesTetel extends Model {};
    RendelesTetel.init({
        id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true,
        }, rendeles_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
        }, termek_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
        }, mennyiseg: {
            type: DataTypes.INTEGER,
            allowNull: false,
            validate: { min: 0 }
        }, egyseg_ar: {
            type: DataTypes.DECIMAL(10, 2),
            allowNull: false,
        } 
    }, {sequelize, modelName: "rendelestetel", freezeTableName: true, timestamps: false});
    return RendelesTetel;
}