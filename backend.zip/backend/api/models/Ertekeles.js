const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
    class Ertekeles extends Model {};

    Ertekeles.init({
        ertekeles_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true,
        },
        user_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        termek_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        pontszam: {
            type: DataTypes.INTEGER,
            allowNull: false,
            validate: {
                min: 1,
                max: 5
            }
        },
        velemeny: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        datum: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        }
    }, {
        sequelize, 
        modelName: "Ertekeles", 
        freezeTableName: true, 
        timestamps: false
    });

    return Ertekeles;
}