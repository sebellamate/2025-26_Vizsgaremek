const { Model, DataTypes } = require("sequelize");
const authUtils = require("../utilities/authUtils");

module.exports = (sequelize) => {
    class User extends Model {};

    User.init(
        {
            ID: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true, allowNull: false },

            name: {
                type: DataTypes.STRING,
                allowNull: false,
                unique: { name: "username", msg: "Ez a felhasználónév már foglalt." },
                validate: {
                    notEmpty: { msg: "A felhasználónév nem lehet üres." },
                    len: { args: [5, 50], msg: "A felhasználónév minimum 5 karakter hosszú legyen." }
                }
            },

            email: {
                type: DataTypes.STRING,
                allowNull: false,
                unique: { name: "email", msg: "Ez az email cím már foglalt." },
                validate: { isEmail: { args: true, msg: "Érvénytelen email formátum." } }
            },

            password: {
                type: DataTypes.STRING,
                allowNull: false,
                validate: {
                    isStrong(value) {
                        if (!value.match(/^(?=.*[A-Z])(?=.*\d).{8,}$/)) {
                            throw new Error(
                                "A jelszónak legalább 8 karakter hosszúnak kell lennie, tartalmaznia kell nagybetűt és számot."
                            );
                        }
                    }
                }
            },
            reset_token: {
                type: DataTypes.STRING,
                allowNull: true
            },
            reset_expires: {
                type: DataTypes.DATE,
                allowNull: true
            },

            isAdmin: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false }
        },
        {
            sequelize,
            modelName: "User",
            createdAt: "registeredAt",
            updatedAt: false,
            scopes: {
                public: { attributes: ["name", "email", "registeredAt", "isAdmin"] },
                admin: { where: { isAdmin: true } }
            }
        }
    );

    const hashUserPassword = (user) => {
        if (user.changed('password')) {
            user.password = authUtils.hashPassword(user.password);
        }
    };

    User.beforeCreate(hashUserPassword);
    User.beforeUpdate(hashUserPassword);

    

    return User;
};
