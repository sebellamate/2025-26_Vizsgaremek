const { DbError } = require("../errors");

class ErtekelesRepository {
    constructor(db) {
        this.Ertekeles = db.Ertekeles;
        this.User = db.User; 
        this.sequelize = db.sequelize;
    }

    async getErtekelesek() {
        try {
            return await this.Ertekeles.findAll({
                include: [
                    {
                        model: this.User,
                        as: "Iro", 
                        attributes: ['name'] 
                    }
                ]
            });
        } catch (error) {
            throw new DbError("Hiba az értékelések lekérésekor", { details: error.message });
        }
    }

    
    async getErtekelesekByTermek(termek_id) {
        try {
            return await this.Ertekeles.findAll({
                where: { termek_id },
                attributes: ['ertekeles_id', 'pontszam', 'velemeny', 'datum', 'termek_id'], 
                include: [
                    {
                        model: this.User,
                        as: "Iro",
                        attributes: ['name']
                    }
                ],
                order: [['datum', 'DESC']]
            });
        } catch (error) {
            throw new DbError("Hiba a termék értékeléseinek lekérésekor", { 
                details: error.message, 
                data: termek_id 
            });
        }
    }

    
    async getErtekeles(ertekeles_id) {
        try {
            return await this.Ertekeles.findOne({
                where: { ertekeles_id }
            });
        } catch (error) {
            throw new DbError("Hiba az értékelés lekérésekor", { 
                details: error.message, 
                data: ertekeles_id 
            });
        }
    }

    
    async postErtekeles(ertekelesData) {
        try {
            return await this.Ertekeles.create(ertekelesData);
        } catch (error) {
            throw new DbError("Hiba az értékelés létrehozásakor", {
                details: error.message,
                data: ertekelesData,
            });
        }
    }

    
    async deleteErtekeles(ertekeles_id) {
        try {
            return await this.Ertekeles.destroy({
                where: { ertekeles_id }
            });
        } catch (error) {
            throw new DbError("Hiba az értékelés törlésekor", { 
                details: error.message, 
                data: ertekeles_id 
            });
        }
    }
}

module.exports = ErtekelesRepository;