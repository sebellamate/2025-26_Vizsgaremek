const UserRepository = require("./UserRepository");
const TermekRepository = require("./TermekRepository");
const KategoriaRepository = require("./KategoriaRepository")
const KosartetelRepository = require("./KosartetelRepository")
const RendelesRepository = require("./RendelesRepository")
const ErtekelesRepository = require("./ErtekelesRepository")
module.exports = (db) =>
{
    const userRepository = new UserRepository(db);
    const termekRepository = new TermekRepository(db);
    const kategoriaRepository= new KategoriaRepository(db);
    const kosartetelRepository = new KosartetelRepository(db);
    const rendelesRepository = new RendelesRepository(db)
    const ertekelesRepository = new ErtekelesRepository(db)

    return { userRepository, termekRepository, kategoriaRepository, kosartetelRepository, rendelesRepository, ertekelesRepository};
}