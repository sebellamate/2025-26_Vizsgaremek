class KosartetelRepository {
    constructor(db) {
        this.Kosartetel = db.KosarTetel;
        this.sequelize = db.sequelize;
    }

    async postTetel(tetelData) {
        return await this.Kosartetel.create({
            ...tetelData,
            mennyiseg: 1
        });
    }

    async getTetel(id) {
        return await this.Kosartetel.findOne({
            where: { id }
        });
    }

    
    async getTetelek(user_id) {
        return await this.Kosartetel.findAll({
            where: { user_id }
        });
    }

    async PlusOne(id) {
        const t = await this.Kosartetel.findByPk(id);
        if (!t) return null;
        t.mennyiseg += 1;
        await t.save();
        return t;
    }

    async MinusOne(id) {
        const t = await this.Kosartetel.findByPk(id);
        if (!t || t.mennyiseg <= 1) return t; // Ne menjen 1 alá
        t.mennyiseg -= 1;
        await t.save();
        return t;
    }

    async deleteTetel(id) {
        return await this.Kosartetel.destroy({
            where: { id }
        });
    }
}

module.exports = KosartetelRepository;