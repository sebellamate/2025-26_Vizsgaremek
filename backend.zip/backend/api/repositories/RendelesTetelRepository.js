const { DbError } = require("../errors");

class RendelesTetelRepository {
    constructor(db) {
        this.Rendeles = db.Rendeles;
        this.RendelesTetel = db.RendelesTetel;
        this.sequelize = db.sequelize;
    }

    /**
     * Új rendelés rekord létrehozása
     * @param {Object} data - A rendelés adatai (vevo_id, osszeg, statusz)
     * @param {Object} options - Sequelize opciók (pl. transaction)
     */
    async createRendeles(data, options = {}) {
        try {
            return await this.Rendeles.create(data, options);
        } catch (error) {
            throw new DbError("Hiba a rendelés létrehozásakor", { 
                details: error.message, 
                data 
            });
        }
    }

    /**
     * Rendelés tételek tömeges mentése
     * @param {Array} tetelek - A mentendő tételek tömbje
     * @param {Object} options - Sequelize opciók (pl. transaction)
     */
    async createRendelesTetelek(tetelek, options = {}) {
        try {
            return await this.RendelesTetel.bulkCreate(tetelek, options);
        } catch (error) {
            throw new DbError("Hiba a rendelés tételek mentésekor", { 
                details: error.message, 
                data: tetelek 
            });
        }
    }

    /**
     * Egy konkrét rendelés lekérése a hozzá tartozó összes tétellel és termékkel
     */
    async getRendelesWithDetails(rendelesID) {
        try {
            return await this.Rendeles.findByPk(rendelesID, {
                include: [
                    {
                        model: this.RendelesTetel,
                        as: "Tetelek", // Az index.js-ben megadott alias
                        include: ["Termek"] // A tételekhez kapcsolódó termék adatok
                    }
                ]
            });
        } catch (error) {
            throw new DbError("Hiba a rendelés részletes lekérésekor", { 
                details: error.message, 
                data: rendelesID 
            });
        }
    }

    /**
     * Felhasználó összes rendelésének lekérése
     */
    async getRendelesekByVevo(vevoID) {
        try {
            return await this.Rendeles.findAll({
                where: { vevo_id: vevoID },
                order: [['rendeles_datuma', 'DESC']],
                include: [{ model: this.RendelesTetel, as: "Tetelek" }]
            });
        } catch (error) {
            throw new DbError("Hiba a felhasználó rendeléseinek lekérésekor", { 
                details: error.message, 
                data: vevoID 
            });
        }
    }
}

module.exports = RendelesTetelRepository;