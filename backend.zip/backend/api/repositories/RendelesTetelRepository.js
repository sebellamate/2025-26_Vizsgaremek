class RendelestetelRepository{
    constructor(db){
        this.RendelesTetel = db.RendelesTetel;
        this.sequelize = db.sequelize;
    }
    async postRendelestetelek(data){
        return await this.RendelesTetel.create(data);
    }
}
module.exports = RendelestetelRepository