const db = require("../db/index")
const { rendelestetelService } = require("../services/index")(db); 

exports.postRendelestetelek = async (req,res,next) => {
    const { vevo_id, nev, fizetesi_mod, szallitasi_cim } = req.body;

    try{
        res.status(200).json(await rendelestetelService.postRendelestetelek(vevo_id, nev, fizetesi_mod, szallitasi_cim))
    }
    catch (error) {
        next(error)
    }
    
}