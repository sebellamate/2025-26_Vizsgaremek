const { DbError } = require("../errors");

class KategoriaRepository {
    constructor(db) {
        this.Kategoria = db.Kategoria;
    }

    async getKategoriak() {
        try {
            return await this.Kategoria.findAll();
        } catch (error) {
            throw new DbError("Hiba a kategóriák lekérésekor", { details: error.message });
        }
    }
}

module.exports = KategoriaRepository;