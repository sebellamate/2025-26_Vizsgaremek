class RendelesRepository {
    constructor(db) {
        this.KosarTetel = db.KosarTetel; 
        
        this.Rendeles = db.Rendeles;
        
        this.RendelesTetel = db.RendelesTetel;
        this.sequelize = db.sequelize;
    }


    async createRendeles(data, transaction) {
        return await this.Rendeles.create({
            user_id: data.user_id,          
            osszeg: data.osszeg,          
            cim: data.cim,                
            statusz: 'fizetve',            
            rendeles_datuma: new Date()    
        }, { transaction });
    }

    async createRendelesTetelek(dataArray, transaction) {
        return await this.RendelesTetel.bulkCreate(dataArray, { transaction });
    }

    async emptyBasket(userId, transaction) {
        return await this.KosarTetel.destroy({
            where: { user_id: userId },
            transaction
        });
    }
}
module.exports = RendelesRepository;