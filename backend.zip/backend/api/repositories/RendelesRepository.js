class RendelesRepository {
    constructor(db) {
        this.db = db; 
        this.KosarTetel = db.KosarTetel; 
        this.Rendeles = db.Rendeles;
        this.RendelesTetel = db.RendelesTetel;
        this.Termek = db.Termek; 
        this.sequelize = db.sequelize;
    }

    async getRendelesekByUserId(userId) {
        return await this.Rendeles.findAll({
            where: { user_id: userId },
            include: [{
                model: this.RendelesTetel,
                as: 'Tetelek',
                include: [{
                    model: this.Termek, 
                    as: 'Termek' 
                }]
            }],
            order: [['rendeles_datuma', 'DESC']]
        });
    }

    async createRendeles(data, transaction) {
        return await this.Rendeles.create({
            user_id: data.user_id,          
            osszeg: data.osszeg,          
            cim: data.cim,                
            statusz: 'fizetve',            
            rendeles_datuma: new Date()    
        }, { transaction });
    }

    async createRendelesTetelek(dataArray, transaction) {
        return await this.RendelesTetel.bulkCreate(dataArray, { transaction });
    }

    async emptyBasket(userId, transaction) {
        return await this.KosarTetel.destroy({
            where: { user_id: userId },
            transaction
        });
    }
}

module.exports = RendelesRepository;