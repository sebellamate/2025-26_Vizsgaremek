const db = require("../db");

const { userService } = require("../services")(db);

exports.getUsers = async (req, res, next) => {
    try {
        res.status(200).json(await userService.getUsers());
    } catch(error) {
        next(error);
    }
}

exports.getUser = async (req, res, next) => {
    const userID = req.userID;
    try {
        res.status(200).json(await userService.getUser(userID));
    } catch(error) {
        next(error);
    }
}

exports.createUser = async (req, res, next) => {
    const { username, email, password } = req.body || {};
    try {
        res.status(201).json(await userService.createUser({ name: username, email, password }));
    } catch(error) {
        next(error);
    }
}
exports.updateProductDiscount = async (req, res, next) => {
    const { termekID } = req.params;
    const { akcio } = req.body || {};

    try {
        const result = await userService.updateProductDiscount(termekID, akcio);
        res.status(200).json(result);
    } catch(error) {
        next(error);
    }
}
exports.addKuponToUser = async (req, res, next) => {
    const { userID } = req.params;
    const { kod, szazalek } = req.body || {};

    try {
        const result = await userService.addKuponToUser(userID, kod, szazalek);
        
        res.status(201).json({
            success: true,
            message: "Kupon sikeresen hozzáadva a felhasználóhoz.",
            data: result
        });
    } catch (error) {
        next(error);
    }
};

exports.getCoupons = async (req, res, next) => {
    try {
        const userID = req.userID; 

        
        const coupons = await userService.getUserCoupons(userID);
        
        return res.status(200).json(coupons);
    } catch (error) {
        next(error);
    }
}

