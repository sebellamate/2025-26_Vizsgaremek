const db = require("../db");
const { ertekelesService } = require("../services")(db);

exports.getErtekelesek = async (req, res, next) => {
    try {
        const ertekelesek = await ertekelesService.getErtekelesek();
        res.status(200).json(ertekelesek);
    } catch (error) {
        next(error);
    }
};

exports.postErtekeles = async (req, res, next) => {
    const { user_id, termek_id, pontszam, velemeny } = req.body || {};
    try {
        const ujErtekeles = await ertekelesService.postErtekeles({
            user_id,
            termek_id,
            pontszam,
            velemeny
        });
        res.status(201).json(ujErtekeles); 
    } catch (error) {
        next(error);
    }
};

exports.getErtekelesekByTermek = async (req, res, next) => {
    const { termek_id } = req.params;
    try {
        const ertekelesek = await ertekelesService.getErtekelesekByTermek(termek_id);
        res.status(200).json(ertekelesek);
    } catch (error) {
        next(error);
    }
};

exports.getErtekeles = async (req, res, next) => {
    const ertekeles_id = req.params.id || req.ertekeles_id;
    try {
        const ertekeles = await ertekelesService.getErtekeles(ertekeles_id);
        res.status(200).json(ertekeles);
    } catch (error) {
        next(error);
    }
};

exports.deleteErtekeles = async (req, res, next) => {
    const ertekeles_id = req.params.id || req.ertekeles_id;
    try {
        const result = await ertekelesService.deleteErtekeles(ertekeles_id);
        res.status(200).json({ message: "Értékelés sikeresen törölve", result });
    } catch (error) {
        next(error);
    }
};