const db = require("../db/index");
const { rendelesService } = require("../services")(db);
exports.postRendeles = async (req, res, next) => {
    const { user_id, osszeg, cim, tetelek } = req.body;
    
    try {
        const eredmeny = await rendelesService.postRendeles({
            user_id,
            osszeg,
            cim,
            tetelek
        });
        
        res.status(201).json(eredmeny);
    } catch (error) {
        next(error);
    }
};