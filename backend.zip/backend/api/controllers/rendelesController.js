const db = require("../db/index");
const { rendelesService } = require("../services")(db);

exports.postRendeles = async (req, res, next) => {
    const { user_id, osszeg, cim, tetelek } = req.body;
    
    try {
        const eredmeny = await rendelesService.postRendeles({
            user_id,
            osszeg,
            cim,
            tetelek
        });
        
        res.status(201).json(eredmeny);
    } catch (error) {
        next(error);
    }
};

exports.getUserRendelesek = async (req, res, next) => {
    try {
        const rendelesek = await rendelesService.getUserRendelesek(req.params.userId);
        res.status(200).json(rendelesek);
    } catch (error) {
        next(error);
    }
};