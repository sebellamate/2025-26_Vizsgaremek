const bcrypt = require("bcrypt");

const db = require("../db");

const { userService } = require("../services")(db);

const authUtils = require("../utilities/authUtils");


exports.forgotPassword = async (req, res) => {
    try {
        const { email } = req.body;
        await userService.requestPasswordReset(email);
        
        res.status(200).json({ 
            message: "Ha az e-mail cím létezik, a visszaállító linket elküldtük." 
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Hiba történt a művelet során." });
    }
};

exports.resetPassword = async (req, res) => {
    try {
        const { token, newPassword } = req.body;
        await userService.resetPassword(token, newPassword);
        res.status(200).json({ message: "Sikeres jelszócsere!" });
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
};
exports.changePassword = async (req, res) => {
    try {
        const { currentPassword, newPassword } = req.body;
        
        const userID = Number(req.user.userID); 

        if (!userID || isNaN(userID)) {
            console.log("HIBA: Nincs érvényes userID a tokenben!", req.user);
            return res.status(401).json({ message: "Nem sikerült azonosítani a felhasználót." });
        }

        await userService.changePassword(userID, currentPassword, newPassword);
        
        res.status(200).json({ message: "Jelszó sikeresen megváltoztatva!" });
    } catch (error) {
        console.error("ChangePassword Error:", error);
        res.status(400).json({ message: error.message || "Hiba történt." });
    }
};


exports.login = async (req, res, next) => {
    const { userID, password } = req.body;

    try {
        let user;
        try {
            user = await userService.getUser(userID);
        } catch (error) {
            return res.status(401).json({ message: "Hibás felhasználónév vagy jelszó!" });
        }

        if (bcrypt.compareSync(password, user.password)) {
            const token = authUtils.generateUserToken(user);
            authUtils.setCookie(res, "user_token", token);

            return res.status(200).json(token);
        } else {
            return res.status(401).json({ message: "Hibás felhasználónév vagy jelszó!" });
        }
    } catch (error) {
        next(error);
    }
}

exports.status = (req, res, next) =>
{
    res.status(200).json(req.user);
}

exports.logout = (req, res, next) =>
{
    res.clearCookie("user_token");

    res.sendStatus(200);
}