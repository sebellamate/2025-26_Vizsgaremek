const db = require("../db/index")
const { rendelestetelService } = require("../services/index")(db); 
exports.postRendelestetelek = async (req,res,next) => {
    const { rendeles_id, tetelek } = req.body;

    
    res.status(200).json(await rendelestetelService.postRendelestetelek({
            rendeles_id,
            tetelek
        }))
}