const db = require("../db");
const { rendelestetelService } = require("../services")(db);

exports.postRendelestetelekandrendeles = async (req, res, next) => {
    const vevo_id = req.userID; // Az auth middleware-ből jön
    const { osszeg, tetelek } = req.body || {};

    try {
        const result = await rendelestetelService.createRendelesWithTetelek({
            vevo_id,
            osszeg,
            tetelek
        });

        res.status(201).json({
            success: true,
            message: "Rendelés és a hozzá tartozó tételek sikeresen rögzítve.",
            data: result
        });
    } catch (error) {
        next(error);
    }
};