const express = require("express");
const multer = require("multer");
const path = require("path");
const router = express.Router();

// Multer storage beállítása
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    // Mentés a frontend/public/kepek mappába
    cb(null, path.join(__dirname, "../../../frontend/public/kepek"));
  },
  filename: function (req, file, cb) {
    // Eredeti fájlnevet megtartjuk
    cb(null, file.originalname);
  }
});

const upload = multer({ storage: storage });

// Upload endpoint
router.post("/", upload.single("file"), (req, res) => {
  res.json({ message: "Fájl elmentve!", filename: req.file.originalname });
});

module.exports = router;
