const isDev = process.env.NODE_ENV !== 'production';
const level = process.env.LOG_LEVEL || 'info';

const logger = {
  // Always shows up, even in production
  error: (msg, err) => console.error(`[ERROR] ${msg}`, err),

  // Only shows up if we aren't in strict "error-only" mode
  info: (msg) => {
    if (level !== 'error') console.log(`[INFO] ${msg}`);
  },

  // Only shows up in development
  debug: (msg) => {
    if (isDev || level === 'debug') console.log(`[DEBUG] ${msg}`);
  }
};

module.exports = logger;