require("dotenv").config({ quiet: true });

const app = require("./app");

const PORT = process.env.PORT ?? 8000;

app.use((err, req, res, next) => {
  // Even if LOG_LEVEL=error, console.error usually forces output to the terminal
  console.error("!!! 500 ERROR DETECTED !!!");
  console.error("Message:", err.message);
  console.error("Stack Trace:", err.stack);

  res.status(500).json({
    error: "Internal Server Error",
    // Only show the stack trace in development for security
    details: process.env.NODE_ENV === 'development' ? err.stack : undefined
  });
});

app.listen(PORT, () => 
{
    console.log(`http://localhost:${PORT}`);
});
