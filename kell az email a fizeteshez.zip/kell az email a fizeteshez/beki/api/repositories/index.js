const UserRepository = require("./UserRepository");
const TermekRepository = require("./TermekRepository");
const KategoriaRepository = require("./KategoriaRepository");
const KosartetelRepository = require("./KosartetelRepository");
const CartRepository = require("./CartRepository");
const RendelestetelRepository = require("./RendelesTetelRepository");
const RendelesRepository = require("./RendelesRepository");
module.exports = (db) => {
  const userRepository = new UserRepository(db);
  const termekRepository = new TermekRepository(db);
  const kategoriaRepository = new KategoriaRepository(db);
  const kosartetelRepository = new KosartetelRepository(db);
  const cartRepository = new CartRepository(db);
  const rendelestetelRepository = new RendelestetelRepository(db);
  const rendelesRepository = new RendelesRepository(db);

  return {
    userRepository,
    termekRepository,
    kategoriaRepository,
    kosartetelRepository,
    cartRepository,
    rendelestetelRepository,
    rendelesRepository,
  };
};
