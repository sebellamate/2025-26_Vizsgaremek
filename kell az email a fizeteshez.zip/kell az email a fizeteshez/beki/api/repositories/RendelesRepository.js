class RendelesRepository{
    constructor(db){
        this.Rendeles = db.Rendeles;
        this.sequelize = db.sequelize;
    }
    async createRendeles(data){
        return await this.Rendeles.create(data);
    }
    async updateRendeles(rendeles_id, data){
        return await this.Rendeles.update(data, {
            where: { rendeles_id: rendeles_id }
        });
    }
}
module.exports = RendelesRepository