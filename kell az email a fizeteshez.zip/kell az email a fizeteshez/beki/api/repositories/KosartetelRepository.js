class KosartetelRepository
{
    constructor(db)
    {
        this.Kosartetel = db.KosarTetel;

        this.sequelize = db.sequelize;
    }
    async postTetel(tetelData) {
    return await this.Kosartetel.create({
        ...tetelData,
        mennyiseg: 1
    });
    }


    async getTetel(id){
        return await this.Kosartetel.findOne({
            where: {id}
        })
    }
    async getTetelek(kosar_id){
        return await this.Kosartetel.findAll({
            where: {kosar_id}
        })
    }
    async PlusOne(id) {
        const t = await this.Kosartetel.findByPk(id);

        if (!t) return null;

        t.mennyiseg += 1;
        await t.save(); 
  
        return t; 
    }

    async MinusOne(id) {
        const t = await this.Kosartetel.findByPk(id);
        
        t.mennyiseg -= 1;

        await t.save();

    
        return t;
    }

    async deleteTetel(id) {
        return await this.Kosartetel.destroy({
            where: {id}
        })
    }

    async deleteKosarTetelByKosarId(kosar_id) {
        try {
            const deletedCount = await this.Kosartetel.destroy({
                where: { kosar_id }
            });
            console.log(`Törölt ${deletedCount} kosártétel a kosár ID alapján: ${kosar_id}`);
            return deletedCount;
        } catch (error) {
            console.error(`Hiba történt a kosártétel törlése során a kosár ID alapján: ${kosar_id}`, error);
            throw new Error(`Nem sikerült törölni a kosártételt a kosár ID alapján: ${kosar_id}`);
        }
    }

}



module.exports = KosartetelRepository;