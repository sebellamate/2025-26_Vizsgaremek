const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
    host: process.env.EMAIL_HOST || "smtp.gmail.com",
    port: process.env.EMAIL_PORT || 587,
    secure: false, 
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
    },
    tls: {
        rejectUnauthorized: false // Localhostos tanúsítványhibák elkerülése
    }
});

const sendResetEmail = async (toEmail, token) => {
    // Frissítve a te portodra (3000)
    const resetUrl = `http://localhost:3000/reset-password?token=${token}`;

    const mailOptions = {
        // A 'from' legyen az e-mail címed, hogy a Gmail ne blokkolja
        from: `"Webshop Support" <${process.env.EMAIL_USER}>`,
        to: toEmail,
        subject: "Jelszó visszaállítási kérelem",
        html: `
            <div style="font-family: sans-serif; border: 1px solid #e1e8ed; padding: 20px; border-radius: 10px; max-width: 500px; margin: auto;">
                <h2 style="color: #059669; text-align: center;">Elfelejtett jelszó</h2>
                <p>Kérted a jelszavad visszaállítását a webshopunkban. Kattints az alábbi gombra az új jelszó megadásához:</p>
                <div style="text-align: center; margin: 30px 0;">
                    <a href="${resetUrl}" style="background-color: #059669; color: white; padding: 12px 25px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">Jelszó megváltoztatása</a>
                </div>
                <p style="color: #6b7280; font-size: 0.9em;">Ez a link 1 óráig érvényes. Ha nem te kérted a visszaállítást, nyugodtan hagyd figyelmen kívül ezt az üzenetet.</p>
                <hr style="border: 0; border-top: 1px solid #e1e8ed; margin: 20px 0;">
                <p style="font-size: 0.8em; color: #9ca3af; text-align: center;">© 2024 Webshop Team</p>
            </div>
        `,
    };

    try {
        const info = await transporter.sendMail(mailOptions);
        console.log("E-mail sikeresen elküldve: %s", info.messageId);
        return info;
    } catch (error) {
        console.error("Hiba az e-mail küldésekor:", error);
        throw error; 
    }
};const sendKuponEmail = async (toEmail, userName, kuponKod, szazalek) => {
    const mailOptions = {
        from: `"Webshop Ajándék" <${process.env.EMAIL_USER}>`,
        to: toEmail,
        subject: "Meglepetésed érkezett! 🎁",
        html: `
            <div style="font-family: sans-serif; border: 1px solid #e1e8ed; padding: 20px; border-radius: 10px; max-width: 500px; margin: auto;">
                <h2 style="color: #059669; text-align: center;">Szia ${userName}!</h2>
                <p>Van egy jó hírünk: kaptál egy egyedi kedvezménykupont, amit a következő vásárlásodnál használhatsz fel.</p>
                
                <div style="background-color: #f3f4f6; border: 2px dashed #059669; padding: 20px; text-align: center; margin: 30px 0; border-radius: 10px;">
                    <span style="font-size: 1.2em; color: #374151;">A kuponkódod:</span><br>
                    <strong style="font-size: 2em; color: #059669; letter-spacing: 2px;">${kuponKod}</strong><br>
                    <span style="font-size: 1.5em; font-weight: bold; color: #059669;">-${szazalek}% kedvezmény</span>
                </div>

                <p style="text-align: center;">Másold ki a fenti kódot és írd be a pénztárnál a kedvezmény érvényesítéséhez!</p>
                
                <hr style="border: 0; border-top: 1px solid #e1e8ed; margin: 20px 0;">
                <p style="font-size: 0.8em; color: #9ca3af; text-align: center;">© 2024 Webshop Team</p>
            </div>
        `,
    };

    try {
        const info = await transporter.sendMail(mailOptions);
        console.log("Kupon e-mail elküldve: %s", info.messageId);
        return info;
    } catch (error) {
        console.error("Hiba a kupon e-mail küldésekor:", error);
    }
};

module.exports = { sendResetEmail, sendKuponEmail };