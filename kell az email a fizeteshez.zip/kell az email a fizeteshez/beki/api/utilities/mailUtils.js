const nodemailer = require('nodemailer');

// Configure nodemailer transporter with environment variables
const transporter = nodemailer.createTransport({
  host: '127.0.0.1',
  port: 1025,
  secure: false, // true for 465, false for other ports
  auth: undefined,
});

// Verify connection on initialization
transporter.verify((error, success) => {
  if (error) {
    console.error('Mail transporter error:', error);
  } else {
    console.log('Mail transporter ready:', success);
  }
});

/**
 * Send an email
 * @param {string} to - Recipient email address
 * @param {string} subject - Email subject
 * @param {string} html - HTML content of the email
 * @param {string} text - Plain text version (optional)
 */
const sendEmail = async (to, subject, html, text = '') => {
  try {
    const mailOptions = {
      from: process.env.MAIL_FROM || 'noreply@kenybiznisz.hu',
      to,
      subject,
      html,
      text: text || html.replace(/<[^>]*>/g, ''), // Strip HTML tags if text not provided
    };

    const info = await transporter.sendMail(mailOptions);
    console.log('Email sent:', info.messageId);
    return info;
  } catch (error) {
    console.error('Failed to send email:', error);
    throw error;
  }
};

module.exports = {
  transporter,
  sendEmail,
};
