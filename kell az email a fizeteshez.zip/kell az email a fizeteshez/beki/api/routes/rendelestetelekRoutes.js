const express = require("express");

const router = express.Router();

const rendelestetelController = require("../controllers/rendelestetelController");

router.post("/", rendelestetelController.postRendelestetelek);


module.exports = router;