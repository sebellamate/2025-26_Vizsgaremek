const express = require("express");

const router = express.Router();

const termekController = require("../controllers/termekController");

router.get("/",  termekController.getTermekek);
router.post("/", termekController.postTermek);
router.get("/kategoria/:kategoria_id", termekController.getTermekekByKategoria);
router.param("termek_id", (req, res, next, termek_id) => 
{
    req.termek_id = termek_id;
    next();
});


router.param("kosar_id", (req,res,next,kosar_id) =>{
    req.kosar_id = kosar_id;
    next();
})
router.param('kosar_ids', (req, res, next, kosar_ids) => {
  req.kosar_ids = kosar_ids.split(',').map(id => parseInt(id));
  next();
});
router.get("/kosar/:kosar_id", termekController.getTermekekBykosar_id)

router.get("/:termek_id", termekController.getTermek);

router.delete("/:termek_id", termekController.deleteTermek);

router.get('/multi/:kosar_ids', termekController.getTermekekBy_ids);

router.put("/:termek_id", termekController.editTermek);

router.param("keres", (req,res,next,keres) =>{
    req.keres = keres;
    next();
})
router.get("/kerestermek/:keres", termekController.keresTermek)
module.exports = router;