const express = require("express")
const multer = require("multer")
const path = require("path")
const fs = require("fs")

const router = express.Router()

// ✅ FRONTEND PUBLIC/KEPEK MAPPA ELÉRÉSE
const uploadDir = path.join(__dirname, "../../../frontend/public/kepek")

// ha nem létezik, létrehozzuk
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true })
}

// multer config
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir)
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname)
    const filename = Date.now() + ext
    cb(null, filename)
  },
})

const upload = multer({ storage })

router.post("/", upload.single("file"), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ message: "Nincs fájl feltöltve!" })
  }

  res.json({
    filename: req.file.filename,
    path: `/kepek/${req.file.filename}`, // frontendhez jó útvonal
  })
})

module.exports = router
