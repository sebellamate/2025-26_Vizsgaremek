class RendelestetelService {
  constructor(db) {
    this.rendelestetelRepository =
      require("../repositories")(db).rendelestetelRepository;
    this.rendelesRepository = require("../repositories")(db).rendelesRepository;
    this.cartRepository = require("../repositories")(db).cartRepository;
    this.kosartetelRepository =
      require("../repositories")(db).kosartetelRepository;
    this.termekRepository = require("../repositories")(db).termekRepository;
  }
  async postRendelestetelek(vevo_id, nev, fizetesi_mod, szallitasi_cim) {
    if (vevo_id === undefined || vevo_id === null) {
      throw new Error("Nincs vevő azonosító megadva");
    }

    if (!nev || !fizetesi_mod || !szallitasi_cim) {
      throw new Error("Hiányzó szükséges adatok: nev, fizetesi_mod, szallitasi_cim");
    }

    const kosar = await this.cartRepository.getCart(vevo_id);
    if (!kosar) {
      throw new Error(
        `Nem található kosár a megadott vevőazonosítóval: ${vevo_id}`,
      );
    }
    const tetelek = await this.kosartetelRepository.getTetelek(kosar.ID);

    if (!tetelek || tetelek.length === 0) {
      throw new Error(
        `A kosár üres, nincs mit megrendelni. Vevo_id: ${vevo_id}, Kosar_id: ${kosar.ID}`,
      );
    }

    const termekIdk = tetelek.map((t) => t.termek_id);
    const termekekDetails =
      await this.termekRepository.getTermekekBy_ids(termekIdk);

    const rendeles = {
      vevo_id: vevo_id,
      osszeg: termekekDetails.reduce((acc, t) => acc + t.ar, 0),
      nev: nev,
      fizetesi_mod: fizetesi_mod,
      szallitasi_cim: szallitasi_cim,
    };

    const createdRendeles =
      await this.rendelesRepository.createRendeles(rendeles);

    const elokeszitettTetelek = termekekDetails.map((termek) => {
      return {
        rendeles_id: createdRendeles.rendeles_id,
        termek_id: termek.termek_id,
        mennyiseg: 1,
        egyseg_ar: termek.ar || 0,
      };
    });

    const result = await this.rendelestetelRepository.postRendelestetelek(
      await elokeszitettTetelek,
    );

    if (!result || result.length === 0) {
      throw new Error("Rendeléstétel létrehozása nem sikerült");
    } else {
      await this.kosartetelRepository.deleteKosarTetelByKosarId(kosar.ID);
      try {
        await this.sendOrderSubmittedEmail(vevo_id, createdRendeles.rendeles_id);
        console.log("Siker: Email elküldve a várólistára.");
      } catch (error) {
        console.error("EMAIL HIBA: A rendelés kész, de az email nem ment el. Hiba:", error.message);
        // Itt nem dobunk hibát tovább, így a frontend SIKERT fog kapni!
      }
      this.sumulateOrderProcessingTime(createdRendeles.rendeles_id);
    }

    return result;
  }

  async sendOrderSubmittedEmail(vevo_id, rendeles_id) {
    console.log(
      `Email küldése: Rendelés ${rendeles_id} leadva a vevő ${vevo_id} részére.`,
    );
    const { sendEmail } = require("../utilities/mailUtils");

    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
      </head>
      <body style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 0; background-color: #f5f5f5;">
        <!-- Main Container -->
        <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f5;">
          <tr>
            <td align="center" style="padding: 40px 20px;">
              
              <!-- Email Card -->
              <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); overflow: hidden;">
                
                <!-- Header Section -->
                <tr>
                  <td style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); padding: 40px 30px; text-align: center;">
                    <div style="font-size: 32px; font-weight: bold; color: #ffffff; margin-bottom: 10px;">✓</div>
                    <h1 style="margin: 0; font-size: 28px; color: #ffffff; font-weight: 600;">Rendelés Megerősítve!</h1>
                    <p style="margin: 10px 0 0 0; font-size: 16px; color: rgba(255,255,255,0.9);">Köszönjük megrendelésedért</p>
                  </td>
                </tr>

                <!-- Content Section -->
                <tr>
                  <td style="padding: 40px 30px;">
                    
                    <!-- Greeting -->
                    <p style="margin: 0 0 30px 0; font-size: 16px; color: #333333; line-height: 1.6;">
                      Kedves Vásárlónk!
                    </p>

                    <!-- Order Confirmation -->
                    <div style="background-color: #f0fdf4; border-left: 4px solid #10b981; padding: 20px; margin-bottom: 30px; border-radius: 6px;">
                      <p style="margin: 0; font-size: 14px; color: #065f46; font-weight: 600;">
                        <strong>Rendelés sorszáma:</strong> #${rendeles_id}
                      </p>
                      <p style="margin: 8px 0 0 0; font-size: 13px; color: #047857;">
                        Rendelésed sikeresen leadtuk. Az alábbi részleteket rögzítettük.
                      </p>
                    </div>

                    <!-- Order Details -->
                    <div style="margin-bottom: 30px;">
                      <h3 style="margin: 0 0 15px 0; font-size: 16px; color: #1f2937; font-weight: 600;">Rendelés Részletei</h3>
                      
                      <table width="100%" cellpadding="0" cellspacing="0">
                        <tr>
                          <td style="padding: 12px 0; border-bottom: 1px solid #e5e7eb; font-size: 14px;">
                            <span style="color: #6b7280; font-weight: 500;">Rendelés száma:</span>
                          </td>
                          <td style="padding: 12px 0; border-bottom: 1px solid #e5e7eb; text-align: right; font-size: 14px; color: #111827; font-weight: 600;">
                            #${rendeles_id}
                          </td>
                        </tr>
                        <tr>
                          <td style="padding: 12px 0; border-bottom: 1px solid #e5e7eb; font-size: 14px;">
                            <span style="color: #6b7280; font-weight: 500;">Rendelés dátuma:</span>
                          </td>
                          <td style="padding: 12px 0; border-bottom: 1px solid #e5e7eb; text-align: right; font-size: 14px; color: #111827; font-weight: 600;">
                            ${new Date().toLocaleDateString('hu-HU', { year: 'numeric', month: '2-digit', day: '2-digit' })}
                          </td>
                        </tr>
                        <tr>
                          <td style="padding: 12px 0; border-bottom: 1px solid #e5e7eb; font-size: 14px;">
                            <span style="color: #6b7280; font-weight: 500;">Státusz:</span>
                          </td>
                          <td style="padding: 12px 0; border-bottom: 1px solid #e5e7eb; text-align: right; font-size: 14px; color: #111827; font-weight: 600;">
                            <span style="background-color: #dbeafe; color: #1e40af; padding: 4px 12px; border-radius: 20px; font-size: 12px;">Feldolgozás alatt</span>
                          </td>
                        </tr>
                      </table>
                    </div>

                    <!-- What's Next -->
                    <div style="background-color: #eff6ff; border-left: 4px solid #3b82f6; padding: 20px; border-radius: 6px; margin-bottom: 30px;">
                      <h4 style="margin: 0 0 10px 0; font-size: 14px; color: #1e40af; font-weight: 600;">Mi történik ezután?</h4>
                      <ol style="margin: 0; padding-left: 20px; color: #1e40af; font-size: 13px; line-height: 1.8;">
                        <li style="margin-bottom: 6px;">Rendelésed ellenőrzésére és feldolgozására kerül sor</li>
                        <li style="margin-bottom: 6px;">Szállítási előkészítés megkezdődik</li>
                        <li>Hamarosan küldünk egy email a szállítási információkkal</li>
                      </ol>
                    </div>

                    <!-- CTA Button -->
                    <div style="text-align: center; margin-bottom: 30px;">
                      <a href="http://localhost:3000/profile" style="display: inline-block; background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: #ffffff; text-decoration: none; padding: 14px 32px; border-radius: 8px; font-weight: 600; font-size: 14px; box-shadow: 0 2px 8px rgba(16,185,129,0.3);">
                        Rendeléseim megtekintése
                      </a>
                    </div>

                    <!-- Closing -->
                    <p style="margin: 0; font-size: 14px; color: #6b7280; line-height: 1.6;">
                      Ha bármilyen kérdésed van, fordulj hozzánk bizalommal!<br>
                      <strong style="color: #111827;">Webshop Csapata</strong>
                    </p>
                  </td>
                </tr>

                <!-- Footer -->
                <tr>
                  <td style="background-color: #f9fafb; padding: 20px 30px; border-top: 1px solid #e5e7eb; text-align: center;">
                    <p style="margin: 0; font-size: 12px; color: #9ca3af;">
                      © 2026 Webshop. Minden jog fenntartva.<br>
                      Ezt az emailt biztonsági okokból automatikusan generáltuk.
                    </p>
                  </td>
                </tr>

              </table>
            </td>
          </tr>
        </table>
      </body>
      </html>
    `;

    await sendEmail(
      "fmate.fmate@gmail.com",
      "✓ Rendelés Megerősítve - Webshop",
      htmlContent,
    );
  }

  sumulateOrderProcessingTime(rendeles_id) {
    const { sendEmail } = require("../utilities/mailUtils");
    return setTimeout(async () => {
      try {
        await this.rendelesRepository.updateRendeles(rendeles_id, {
          statusz: 'szallitva'
        });

        console.log(`Rendelés ${rendeles_id} státusza frissítve: szallitva`);

        const htmlContent = `
          <!DOCTYPE html>
          <html>
          <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
          </head>
          <body style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 0; background-color: #f5f5f5;">
            <!-- Main Container -->
            <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f5;">
              <tr>
                <td align="center" style="padding: 40px 20px;">
                  
                  <!-- Email Card -->
                  <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); overflow: hidden;">
                    
                    <!-- Header Section -->
                    <tr>
                      <td style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); padding: 40px 30px; text-align: center;">
                        <div style="font-size: 32px; font-weight: bold; color: #ffffff; margin-bottom: 10px;">📦</div>
                        <h1 style="margin: 0; font-size: 28px; color: #ffffff; font-weight: 600;">Rendelésed Feldolgozása Befejezödött!</h1>
                        <p style="margin: 10px 0 0 0; font-size: 16px; color: rgba(255,255,255,0.9);">Most már szállítás alatt van</p>
                      </td>
                    </tr>

                    <!-- Content Section -->
                    <tr>
                      <td style="padding: 40px 30px;">
                        
                        <!-- Processing Complete -->
                        <div style="background-color: #fffbeb; border-left: 4px solid #f59e0b; padding: 20px; margin-bottom: 30px; border-radius: 6px;">
                          <p style="margin: 0; font-size: 14px; color: #92400e; font-weight: 600;">
                            <strong>Rendelés sorszáma:</strong> #${rendeles_id}
                          </p>
                          <p style="margin: 8px 0 0 0; font-size: 13px; color: #b45309;">
                            Rendelésed feldolgozása sikeresen megtörtént és szállítás alatt van!
                          </p>
                        </div>

                        <!-- Status Timeline -->
                        <div style="margin-bottom: 30px;">
                          <h3 style="margin: 0 0 20px 0; font-size: 16px; color: #1f2937; font-weight: 600;">Rendelés Állapota</h3>
                          
                          <!-- Timeline -->
                          <div style="position: relative; margin-left: 10px;">
                            <!-- Step 1 -->
                            <div style="display: flex; margin-bottom: 20px;">
                              <div style="width: 30px; height: 30px; background-color: #10b981; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #ffffff; font-weight: bold; margin-right: 15px; flex-shrink: 0;">✓</div>
                              <div style="padding-top: 5px;">
                                <p style="margin: 0; font-size: 14px; font-weight: 600; color: #1f2937;">Rendelés Leadva</p>
                                <p style="margin: 4px 0 0 0; font-size: 12px; color: #6b7280;">Rendelésed sikeresen leadtuk</p>
                              </div>
                            </div>

                            <!-- Step 2 -->
                            <div style="display: flex; margin-bottom: 20px;">
                              <div style="width: 30px; height: 30px; background-color: #f59e0b; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #ffffff; font-weight: bold; margin-right: 15px; flex-shrink: 0;">✓</div>
                              <div style="padding-top: 5px;">
                                <p style="margin: 0; font-size: 14px; font-weight: 600; color: #1f2937;">Feldolgozás Befejezödött</p>
                                <p style="margin: 4px 0 0 0; font-size: 12px; color: #6b7280;">Rendelésed előkészítése kész</p>
                              </div>
                            </div>

                            <!-- Step 3 -->
                            <div style="display: flex;">
                              <div style="width: 30px; height: 30px; background-color: #3b82f6; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #ffffff; font-weight: bold; margin-right: 15px; flex-shrink: 0;">→</div>
                              <div style="padding-top: 5px;">
                                <p style="margin: 0; font-size: 14px; font-weight: 600; color: #1f2937;">Szállítás Alatt</p>
                                <p style="margin: 4px 0 0 0; font-size: 12px; color: #6b7280;">Rendelésed már úton van hozzád</p>
                              </div>
                            </div>
                          </div>
                        </div>

                        <!-- Shipping Info -->
                        <div style="background-color: #f0f9ff; border: 2px dashed #0ea5e9; padding: 20px; border-radius: 8px; margin-bottom: 30px;">
                          <h4 style="margin: 0 0 15px 0; font-size: 14px; color: #0369a1; font-weight: 600;">📍 Szállítási Információ</h4>
                          <p style="margin: 0; font-size: 13px; color: #0c4a6e; line-height: 1.6;">
                            A csomagod hamarosan megérkezik. A szállítási módot az Ön fizetési módja szerint állítottuk be.
                          </p>
                          <p style="margin: 12px 0 0 0; font-size: 13px; color: #0c4a6e;">
                            <strong>Nyomon követés:</strong> Hamarosan küldünk egy tracking linket, ha elérhető lesz!
                          </p>
                        </div>

                        <!-- CTA Buttons -->
                        <div style="text-align: center; margin-bottom: 30px;">
                          <a href="http://localhost:3000/profile" style="display: inline-block; background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: #ffffff; text-decoration: none; padding: 14px 32px; border-radius: 8px; font-weight: 600; font-size: 14px; box-shadow: 0 2px 8px rgba(245,158,11,0.3); margin-right: 10px;">
                            Rendeléseim
                          </a>
                          <a href="http://localhost:3000/" style="display: inline-block; background-color: #e5e7eb; color: #1f2937; text-decoration: none; padding: 14px 32px; border-radius: 8px; font-weight: 600; font-size: 14px;">
                            Vissza az oldalra
                          </a>
                        </div>

                        <!-- Closing -->
                        <p style="margin: 0; font-size: 14px; color: #6b7280; line-height: 1.6; text-align: center;">
                          Köszönjük a vásárlást! Bármilyen kérdésed van, keress meg minket.<br>
                          <strong style="color: #111827;">Webshop Csapata</strong>
                        </p>
                      </td>
                    </tr>

                    <!-- Footer -->
                    <tr>
                      <td style="background-color: #f9fafb; padding: 20px 30px; border-top: 1px solid #e5e7eb; text-align: center;">
                        <p style="margin: 0; font-size: 12px; color: #9ca3af;">
                          © 2026 Webshop. Minden jog fenntartva.<br>
                          Ezt az emailt biztonsági okokból automatikusan generáltuk.
                        </p>
                      </td>
                    </tr>

                  </table>
                </td>
              </tr>
            </table>
          </body>
          </html>
        `;

        await sendEmail(
          "user@example.com",
          "📦 Rendelésed Szállítás Alatt - Webshop",
          htmlContent,
        );
      } catch (error) {
        console.error('Failed to send processing email:', error);
      }
    }, 7000);
  }
}

module.exports = RendelestetelService;
