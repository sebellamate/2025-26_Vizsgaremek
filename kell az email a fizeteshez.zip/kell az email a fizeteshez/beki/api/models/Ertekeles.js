const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
    class Ertekeles extends Model {};

    Ertekeles.init({
            ertekeles_id: {
                type: DataTypes.INTEGER,
                allowNull: false,
                primaryKey: true,
                autoIncrement: true,
            }, 
            user_id: {
                type: DataTypes.INTEGER,
                allowNull: false,
            },
            created_date: {
                type: DataTypes.DATE,
                defaultValue: DataTypes.NOW,
                allowNull: false,
            },
            score: {
                type: DataTypes.INTEGER,
                allowNull: false,
            },
            comment: {
                type: DataTypes.STRING(500),
                allowNull: true,
                charset: 'utf8mb4', // TODO: fix adat tipus, hogy lehessen ekezet
                collate: 'utf8mb4_unicode_ci'
            }
        }, {sequelize, modelName: "ertekeles", freezeTableName: true, timestamps: false});
    return Ertekeles;
}