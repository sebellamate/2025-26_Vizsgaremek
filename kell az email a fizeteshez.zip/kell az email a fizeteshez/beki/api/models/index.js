const { DataTypes } = require("sequelize");

module.exports = (sequelize) => {
    const User = require("./User")(sequelize, DataTypes);
    const Kategoria = require("./Kategoria")(sequelize, DataTypes);
    const Termek = require("./Termek")(sequelize, DataTypes);
    const Rendeles = require("./Rendeles")(sequelize, DataTypes);
    const RendelesTetel = require("./RendelesTetel")(sequelize, DataTypes);
    const KosarTetel = require("./KosarTetel")(sequelize, DataTypes);
    const Ertekeles = require("./Ertekeles")(sequelize, DataTypes);
    

    Termek.belongsTo(Kategoria, {
        foreignKey: "kategoria_id",
    });

    Rendeles.belongsTo(User, {
        foreignKey: "vevo_id",
        as: "Vevo",
    });

    User.hasMany(Rendeles, {
        foreignKey: "vevo_id",
        as: "Rendeles",
    });

    RendelesTetel.belongsTo(Rendeles, {
        foreignKey: "rendeles_id",
    });
    RendelesTetel.belongsTo(Termek, {
        foreignKey: "termek_id",
    });

    KosarTetel.belongsTo(Termek, {
        foreignKey: "termek_id",
        as: "Termek",
    });

    Ertekeles.belongsTo(User, {
        foreignKey: "user_id",
        as: "User",
    });

    return {
        User,
        Kategoria,
        Termek,
        Rendeles,
        RendelesTetel,
        KosarTetel,
        Ertekeles,
    };
};
