import { useForm } from "react-hook-form"
import z from "zod"
import { zodResolver } from "@hookform/resolvers/zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import axios from "axios"
import { useMutation, useQueryClient } from "@tanstack/react-query"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useState } from "react"

// A sémában maradhat a 'name', ez csak a frontend belső elnevezése
const formSchema = z.object({
  name: z
    .string()
    .min(5, { message: "A felhasználónév legalább 5 karakter legyen!" })
    .nonempty({ message: "A mező kitöltése kötelező!" }),

  email: z
    .string()
    .email({ message: "Érvényes email címet adj meg!" })
    .nonempty({ message: "A mező kitöltése kötelező!" }),

  password: z
    .string()
    .min(8, { message: "A jelszónak legalább 8 karakter hosszúnak kell lennie!" })
    .regex(/[A-Z]/, { message: "Tartalmaznia kell legalább egy nagybetűt!" })
    .regex(/[0-9]/, { message: "Tartalmaznia kell legalább egy számot!" })
    .nonempty({ message: "A mező kitöltése kötelező!" }),
});

type FormSchema = z.infer<typeof formSchema>

const postUsers = async (values: FormSchema) => {
  // ITT A LÉNYEG: A kontrollered 'username' kulcsot vár a req.body-ban!
  const payload = {
    username: values.name, // A form 'name' értékét 'username' kulccsal küldjük
    email: values.email,
    password: values.password
  };
  
  const response = await axios.post("http://localhost:5000/api/users", payload);
  return response.data;
}

// ... importok változatlanok

export function RegistrationDialog() {
  const [open, setOpen] = useState(false);
  const queryClient = useQueryClient();

  const form = useForm<FormSchema>({
    mode: "onChange",
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      password: "",
    },
  });

  const { mutate: registration, isPending } = useMutation({
    mutationFn: (user: FormSchema) => postUsers(user),
    onSuccess() {
      queryClient.invalidateQueries({ queryKey: ["users"] });
      setOpen(false);
      form.reset();
    },
    onError(error: any) {
      const genericMessage = error.response?.data?.message;
      if (genericMessage) {
        form.setError("root", { message: genericMessage });
      }
    }
  });

  function onSubmit(values: FormSchema) {
    registration(values);
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {/* Sötétebb zöld gomb, árnyékkal és hover effekttel */}
        <Button className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-2 px-8 rounded-full shadow-lg shadow-emerald-900/40 transform transition-all duration-200 hover:scale-105 active:scale-95 tracking-wide uppercase text-sm border border-emerald-800/50">
          Regisztráció
        </Button>
      </DialogTrigger>
      
      {/* max-w-md a jobb olvashatóságért, bg-slate-50 a finom háttérért */}
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto border-emerald-900/20 bg-slate-50">
        <DialogHeader>
          <DialogTitle className="text-emerald-950 text-2xl font-bold tracking-tight">
            Fiók létrehozása
          </DialogTitle>
          <p className="text-emerald-800/60 text-sm">Csatlakozzon hozzánk még ma!</p>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5 pt-4">
            
            {/* Root hibaüzenet stílusa */}
            {form.formState.errors.root && (
              <div className="bg-red-50 border border-red-200 p-3 rounded-lg flex items-center gap-2">
                <div className="h-1.5 w-1.5 rounded-full bg-red-500" />
                <p className="text-red-600 text-xs font-semibold tracking-wider">
                  {form.formState.errors.root.message}
                </p>
              </div>
            )}

            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-emerald-950 font-semibold ml-1">Felhasználónév</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Példa János" 
                      {...field} 
                      className="bg-white border-emerald-100 focus-visible:ring-emerald-600 focus-visible:border-emerald-600 rounded-xl transition-all"
                    />
                  </FormControl>
                  <FormMessage className="text-rose-500 font-medium italic text-xs" />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-emerald-950 font-semibold ml-1">Email cím</FormLabel>
                  <FormControl>
                    <Input 
                      type="email" 
                      placeholder="pelda@email.com" 
                      {...field} 
                      className="bg-white border-emerald-100 focus-visible:ring-emerald-600 focus-visible:border-emerald-600 rounded-xl transition-all"
                    />
                  </FormControl>
                  <FormMessage className="text-rose-500 font-medium italic text-xs" />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-emerald-950 font-semibold ml-1">Jelszó</FormLabel>
                  <FormControl>
                    <Input 
                      type="password" 
                      placeholder="••••••••" 
                      {...field} 
                      className="bg-white border-emerald-100 focus-visible:ring-emerald-600 focus-visible:border-emerald-600 rounded-xl transition-all"
                    />
                  </FormControl>
                  <FormMessage className="text-rose-500 font-medium italic text-xs" />
                </FormItem>
              )}
            />

            <div className="flex flex-col gap-3 pt-4">
              <Button 
                type="submit" 
                disabled={isPending}
                className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-6 rounded-xl shadow-md transition-all active:scale-[0.98]"
              >
                {isPending ? "Regisztrálás..." : "Fiók létrehozása"}
              </Button>
              
              <Button 
                type="button" 
                variant="ghost" 
                onClick={() => setOpen(false)}
                className="text-emerald-800 hover:text-emerald-950 hover:bg-emerald-100/50 font-medium"
              >
                Mégse
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}