import { useQuery } from '@tanstack/react-query'
import axios from 'axios'

type Cart = {
    ID: number,
    user_id: number,
    createdAt: string,
    updatedAt: string,
    created_at: string,
    updated_at: string
}
const getCart = async (id: number) => {
  const response = await axios.get<Cart>(`http://localhost:5000/api/kosarak/${id}`)
  return response.data
}

export function useCart(id: number) {
  return useQuery({
    queryKey: ['cart', id], 
    queryFn: () => getCart(id),
    enabled: !!id, 
  })
}