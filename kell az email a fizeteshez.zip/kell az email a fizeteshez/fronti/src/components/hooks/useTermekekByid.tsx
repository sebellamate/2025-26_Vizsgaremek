import { useQuery } from '@tanstack/react-query'
import axios from 'axios'

const getTermekek = async (ids: number[]) => {
  if (!ids || ids.length === 0) return []

  const idsParam = ids.join(',')
  const response = await axios.get(`http://localhost:5000/api/termekek/multi/${idsParam}`, {
    withCredentials: true,
  })

  return response.data
}

export function useTermekekBy_ids(ids: number[]) {
  return useQuery({
    queryKey: ['termekek', ids],
    queryFn: () => getTermekek(ids),
    enabled: ids && ids.length > 0,
    retry: false,
  })
}

