import { useQuery } from "@tanstack/react-query";
import axios from "axios";

export function useTermekekByKategoria(kategoriaId: number | null) {
  return useQuery({
    // A queryKey biztosítja, hogy ha változik az ID, frissüljön az adat
    queryKey: ["termekek", "kategoria", kategoriaId],
    queryFn: async () => {
      // Ha nincs kategória (null), akkor a sima összes termék listát kérjük le
      const url = kategoriaId 
        ? `http://localhost:5000/api/termekek/kategoria/${kategoriaId}`
        : "http://localhost:5000/api/termekek";
        
      const response = await axios.get(url);
      return response.data;
    },
    // Opcionális: ne fusson le feleslegesen, ha nincs értelme, 
    // de nálad a null jelenti az "összeset", így maradhat true
    enabled: true, 
  });
}