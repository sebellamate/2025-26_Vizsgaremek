import { useQuery } from '@tanstack/react-query'
import axios from 'axios'


const getStatus = async () => {
  try {
    const response = await axios.get('http://localhost:5000/api/auth/status', {
      withCredentials: true,
    })
    console.log(response.data)
    return response.data
  } catch (error: any) {
    // If 401 Unauthorized, user is not logged in - return null instead of error
    if (error.response?.status === 401) {
      return null
    }
    throw error
  }
}

export function useAuthStatus() {
  return useQuery({
    queryKey: ['status'],
    queryFn: getStatus,
    retry: false,
  })
}
