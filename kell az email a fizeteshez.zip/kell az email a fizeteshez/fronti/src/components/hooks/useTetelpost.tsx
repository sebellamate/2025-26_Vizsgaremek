import { useMutation, useQueryClient } from '@tanstack/react-query'
import axios from 'axios'

type Tetel = {
  kosar_id: number
  termek_id: number
}

const postTetel = async (tetel: Tetel) => {
  const response = await axios.post("http://localhost:5000/api/kosartetelek", tetel)
  return response.data
}

export function useTetelPost() {
  const queryClient = useQueryClient()

  const mutation = useMutation({
    mutationFn: (tetel: Tetel) => postTetel(tetel),
    onSuccess: (_, tetel) => {
      queryClient.invalidateQueries({
        queryKey: ['termekek', tetel.kosar_id],
      })
    },
  })

  return {
    createTetel: mutation.mutate,
    createTetelAsync: mutation.mutateAsync,
    ...mutation,
  }
}
