import { useQuery } from '@tanstack/react-query'
import axios from 'axios'

type Kategoria = {
    kategoria_id: number,
    nev: string,
}

const getKategoriak = async () => {
  return await axios.get<Kategoria[]>("http://localhost:5000/api/kategoriak")
}

export function useKategoriak() {
  return useQuery({
    queryKey: ['kategoriak'],
    queryFn: getKategoriak,
  })
}