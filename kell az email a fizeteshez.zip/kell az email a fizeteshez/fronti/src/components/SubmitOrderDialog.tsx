import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "./ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useAuthStatus } from "./hooks/useAuthStatus";
import { useState, useMemo } from "react";
import { useTermekekBy_ids } from "./hooks/useTermekekByid";
import { useItemsByid } from "./hooks/useItemsByid";
import { useQueryClient, useMutation } from "@tanstack/react-query";
import axios from "axios";
import {
  ShoppingCart,
  CreditCard,
  ShoppingBag,
} from "lucide-react";
import { useCart } from "./hooks/useCart";

type KosarTetel = {
  id: number;
  kosar_id: number;
  termek_id: number;
  mennyiseg: number;
};

type Termek = {
  termek_id: number;
  nev: string;
  leiras: string;
  ar: number;
  kep_url?: string;
  kategoria_id: number;
};

// API hívások
const submitOrderApiCall = (vevo_id: number, orderData: any) => {
  const requestBody = {
    vevo_id: vevo_id,
    nev: orderData.nev,
    fizetesi_mod: orderData.fizetesi_mod,
    szallitasi_cim: orderData.szallitasi_cim,
  };
  return axios.post("http://localhost:5000/api/rendelestetelek", requestBody, {
    withCredentials: true,
  });
};

export function SubmitOrderDialog() {
  const [open, setOpen] = useState(false);
  const [nev, setNev] = useState("");
  const [fizetesiMod, setFizetesiMod] = useState("");
  const [szallitasiCim, setSzallitasiCim] = useState("");
  const queryClient = useQueryClient();

  const { data: user, isLoading: userLoading } = useAuthStatus();
  const { data: kosartetelek, isLoading: kosartetelekLoading } = useItemsByid(
    user?.userID,
  );
  const { data: kosar, isLoading: kosarLoading } = useCart(user?.userID);

  const termekIdk = useMemo(() => {
    if (!kosartetelek) return [];
    return kosartetelek.map((t: KosarTetel) => t.termek_id);
  }, [kosartetelek]);

  const { data: termekek, isLoading: termekLoading } =
    useTermekekBy_ids(termekIdk);

  // Mutációk közös invalidálással
  const invalidate = () =>
    queryClient.invalidateQueries({ queryKey: ["kosar", user?.userID] });

  const { mutate: submitOrder, isPending } = useMutation({
    mutationFn: () => {
      if (!user) {
        throw new Error("User is not authenticated");
      }
      return submitOrderApiCall(user.userID, {
        nev,
        fizetesi_mod: fizetesiMod,
        szallitasi_cim: szallitasiCim,
      });
    },
    onSuccess: () => {
      setNev("");
      setFizetesiMod("");
      setSzallitasiCim("");
      setOpen(false);
      invalidate();
    },
  });

  // Kosár összesítő számítása
  const vegosszeg = useMemo(() => {
    if (!termekek || !kosartetelek) return 0;
    return termekek.reduce((acc: number, t: Termek) => {
      const tetel = kosartetelek.find(
        (kt: KosarTetel) => kt.termek_id === t.termek_id,
      );
      return acc + t.ar * (tetel?.mennyiseg || 0);
    }, 0);
  }, [termekek, kosartetelek]);

  const isLoading =
    userLoading || kosartetelekLoading || termekLoading || kosarLoading;
  const isEmpty = !termekek || termekek.length === 0;
  const isFormComplete = nev.trim() && fizetesiMod && szallitasiCim.trim();

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-6 px-10 rounded-2xl shadow-lg shadow-emerald-200 w-full sm:w-auto flex gap-2 text-base transform transition-transform active:scale-95">
          <CreditCard className="w-5 h-5" />
          Rendelés leadása
        </Button>
      </DialogTrigger>

      <DialogContent className="max-w-2xl max-h-[85vh] overflow-hidden flex flex-col p-0 border-emerald-100 shadow-2xl">
        <DialogHeader className="p-6 bg-emerald-50/50 border-b border-emerald-100">
          <DialogTitle className="flex items-center gap-2 text-emerald-900 text-xl">
            <ShoppingBag className="w-6 h-6 text-emerald-700" />
            Rendelés áttekintése
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto p-6">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-20 gap-4">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-700" />
              <p className="text-emerald-800 font-medium">Frissítés...</p>
            </div>
          ) : isEmpty ? (
            <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
              <div className="bg-gray-50 p-6 rounded-full">
                <ShoppingCart className="w-12 h-12 text-gray-300" />
              </div>
              <p className="text-gray-500 font-medium italic">
                A kosarad jelenleg üres.
              </p>
              <Button
                variant="outline"
                onClick={() => setOpen(false)}
                className="text-emerald-700 border-emerald-200"
              >
                Vásárlás megkezdése
              </Button>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Termékek listája */}
              <div className="space-y-3">
                <h3 className="font-bold text-emerald-900 text-sm uppercase tracking-wide">
                  Megrendelt termékek
                </h3>
                {termekek.map((t: Termek) => {
                  const kosarTetel = kosartetelek?.find(
                    (kt: KosarTetel) => kt.termek_id === t.termek_id,
                  );
                  if (!kosarTetel) return null;

                  return (
                    <Card
                      key={t.termek_id}
                      className="border-emerald-50 shadow-sm hover:shadow-md transition-shadow"
                    >
                      <CardContent className="p-4 flex items-center justify-between gap-4">
                        <div className="flex-1 min-w-0">
                          <h4 className="font-bold text-emerald-900 truncate">
                            {t.nev}
                          </h4>
                          <p className="text-xs text-gray-500 line-clamp-1 mb-1">
                            {t.leiras}
                          </p>
                          <p className="text-emerald-700 font-bold">
                            {t.ar.toLocaleString()} Ft
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>

              {/* Szállítási információ form */}
              <div className="border-t pt-6 space-y-4">
                <h3 className="font-bold text-emerald-900 text-sm uppercase tracking-wide">
                  Szállítási információ
                </h3>

                {/* Név */}
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-emerald-900">
                    Teljes név *
                  </label>
                  <input
                    type="text"
                    value={nev}
                    onChange={(e) => setNev(e.target.value)}
                    placeholder="Pl. Márton Péter"
                    className="w-full px-4 py-2 border border-emerald-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-transparent bg-white"
                  />
                </div>

                {/* Fizetési mód */}
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-emerald-900">
                    Fizetési mód *
                  </label>
                  <select
                    value={fizetesiMod}
                    onChange={(e) => setFizetesiMod(e.target.value)}
                    className="w-full px-4 py-2 border border-emerald-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-transparent bg-white"
                  >
                    <option value="">-- Válassz fizetési módot --</option>
                    <option value="bankkartya">Bankkártya</option>
                    <option value="szamla">Számla</option>
                    <option value="keszpenz">Készpénz az átvételnél</option>
                    <option value="bankatiranyt">Banki átutalás</option>
                  </select>
                </div>

                {/* Szállítási cím */}
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-emerald-900">
                    Szállítási cím *
                  </label>
                  <textarea
                    value={szallitasiCim}
                    onChange={(e) => setSzallitasiCim(e.target.value)}
                    placeholder="Pl. 1011 Budapest, Fő utca 1. 1. emelet"
                    rows={3}
                    className="w-full px-4 py-2 border border-emerald-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-transparent bg-white resize-none"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {!isEmpty && !isLoading && (
          <DialogFooter className="p-6 bg-emerald-50/30 border-t border-emerald-100 flex flex-col sm:flex-row items-center gap-4">
            <div className="flex flex-col items-center sm:items-start flex-1">
              <span className="text-xs text-emerald-600 font-bold uppercase tracking-wider">
                Fizetendő összesen
              </span>
              <span className="text-2xl font-black text-emerald-900">
                {vegosszeg.toLocaleString()} Ft
              </span>
            </div>
            <Button
              onClick={() => submitOrder()}
              disabled={!isFormComplete || isPending}
              className="bg-emerald-600 hover:bg-emerald-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white font-bold py-6 px-10 rounded-2xl shadow-lg shadow-emerald-200 w-full sm:w-auto flex gap-2 text-base transform transition-transform active:scale-95"
            >
              <CreditCard className="w-5 h-5" />
              {isPending ? "Feldolgozás..." : "Megrendel"}
            </Button>
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  );
}
