import { useForm } from "react-hook-form"
import z from "zod"
import { zodResolver } from "@hookform/resolvers/zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import axios from "axios"
import { useMutation, useQueryClient } from "@tanstack/react-query"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useState, useEffect } from "react"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { useTermek } from "./hooks/useTermek"
import { useKategoriak } from "./hooks/useKategoriak"

type TermekEditDialogProps = {
  termek_id: number
}

const formSchema = z.object({
  nev: z.string().nonempty({ message: "A mező kitöltése kötelező!" }),
  leiras: z.string().nonempty({ message: "A mező kitöltése kötelező!" }),
  ar: z.string().nonempty({ message: "A mező kitöltése kötelező!" }),
  kep_url: z.string().nonempty({ message: "A mező kitöltése kötelező!" }),
  kategoria_id: z.string().nonempty({ message: "A mező kitöltése kötelező!" }),
})

type FormSchema = z.infer<typeof formSchema>

const putTermek = ({ id, data }: { id: number; data: FormSchema }) => {
  return axios.put(`http://localhost:5000/api/termekek/${id}`, data)
}

export function ProductEditDialog({ termek_id }: TermekEditDialogProps) {
  const [open, setOpen] = useState(false)
  const queryClient = useQueryClient()
  const { data: termek, isLoading } = useTermek(termek_id)
  const { data: kategoriak } = useKategoriak()
  

  const form = useForm<FormSchema>({
    mode: "onChange",
    resolver: zodResolver(formSchema),
    defaultValues: {
      nev: "",
      leiras: "",
      ar: "",
      kep_url: "",
      kategoria_id: "",
    },
  })
  useEffect(() => {
    if (termek) {
      form.reset({
        nev: termek.nev,
        leiras: termek.leiras,
        ar: termek.ar.toString(),
        kep_url: termek.kep_url,
        kategoria_id: termek.kategoria_id.toString(),
      })
    }
  }, [termek])

  const { mutate: update, isPending } = useMutation({
    mutationFn: (data: FormSchema) => putTermek({ id: termek_id, data }),
    onSuccess() {
      queryClient.invalidateQueries({ queryKey: ["termek", termek_id] })
      queryClient.invalidateQueries({ queryKey: ['termekek'] })
      setOpen(false)
    },
  })

  function onSubmit(values: FormSchema) {
    update(values)
  }

  if (isLoading) return <p>Betöltés...</p>

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>Módosítás</Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Termék módosítása</DialogTitle>
          <DialogDescription>Töltsd ki az alábbi mezőket a termék módosításához</DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="nev"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Név</FormLabel>
                  <FormControl>
                    <Input placeholder="Add meg a termék nevét" {...field} />
                  </FormControl>
                  <FormDescription>Itt állíthatod be a termék nevét.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="leiras"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Leírás</FormLabel>
                  <FormControl>
                    <Input placeholder="Add meg a termék leírását" {...field} />
                  </FormControl>
                  <FormDescription>Itt állíthatod be a termék leírását.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="ar"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Ár</FormLabel>
                  <FormControl>
                    <Input placeholder="Add meg az árat" {...field} />
                  </FormControl>
                  <FormDescription>Itt állíthatod be a termék árát.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="kep_url"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Kép URL</FormLabel>
                  <FormControl>
                    <Input placeholder="Add meg a kép URL-jét" {...field} />
                  </FormControl>
                  <FormDescription>Itt állíthatod be a termék képét.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
                    control={form.control}
                    name="kategoria_id"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Válassz kategóriát</FormLabel>
                        <FormControl>
                          <Select
                            value={field.value}
                            onValueChange={field.onChange}
                            disabled={!kategoriak}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Kategória kiválasztása" />
                            </SelectTrigger>
                            <SelectContent>
                              {kategoriak?.data.map((k) => (
                                <SelectItem
                                  key={k.kategoria_id}
                                  value={k.kategoria_id.toString()}
                                >
                                  {k.nev}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
            <div className="flex gap-2 justify-end">
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                Mégse
              </Button>
              <Button type="submit" disabled={!form.formState.isValid || isPending}>
                {isPending ? "Mentés..." : "Mentés"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}
