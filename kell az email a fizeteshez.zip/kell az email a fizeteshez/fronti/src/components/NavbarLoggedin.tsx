"use client"

import { Link } from "@tanstack/react-router"
import axios from "axios"
import { Button } from "./ui/button"
import { KosarDialog } from "./KosarDialog"
import { useNavigate } from "@tanstack/react-router"
import SearchEngine from "./searchengine"
import { useQueryClient } from "@tanstack/react-query"

export function NavbarLoggedIn() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const handleLogout = async () => {
    try {
      await axios.delete("http://localhost:5000/api/auth/logout", {
        withCredentials: true,
      });
      queryClient.invalidateQueries({ queryKey: ["status"] })
      window.location.href = "/";
    } catch (error) {
      console.error("Hiba a kijelentkezés során:", error);
    }
  };

  return (
    <header className="border-b bg-background sticky top-0 z-50">
      <div className="container mx-auto flex h-16 items-center justify-between px-4 gap-6">
        
        {/* BAL OLDAL: Logo és Kereső */}
        <div className="flex items-center gap-8 flex-1">
          <Link to="/" className="text-2xl font-black tracking-tighter text-emerald-950 shrink-0">
            webshop
          </Link>

          <div className="w-full max-w-md hidden md:block">
            <SearchEngine />
          </div>
        </div>

        {/* JOBB OLDAL: Egy közös "kapszulában" minden */}
        <div className="flex items-center">
          <div className="flex items-center gap-1 bg-emerald-50/50 p-1.5 rounded-full border border-emerald-100/50 shadow-sm">
            
            {/* Kosár szekció */}
            <KosarDialog />
            
            <div className="h-6 w-[1px] bg-emerald-200/50 mx-1" />

            {/* Profil gomb */}
            <Button 
              variant="ghost"
              className="rounded-full hover:bg-emerald-100 text-emerald-900 font-medium px-4 h-9"
              onClick={() => navigate({ to: "/profile" })}
            >
              Profil
            </Button>

            <div className="h-6 w-[1px] bg-emerald-200/50 mx-1" />

            {/* Logout gomb - Hoverre piros háttér + fehér szöveg */}
            <Button 
              variant="ghost" 
              onClick={handleLogout}
              className="rounded-full text-red-600 font-semibold px-4 h-9 transition-all duration-200 hover:bg-red-600 hover:text-white"
            >
              Logout
            </Button>
          </div>
        </div>

      </div>

      {/* Mobil kereső sáv */}
      <div className="md:hidden px-4 pb-3">
        <SearchEngine />
      </div>
    </header>
  );
}