"use client"

import { Link } from "@tanstack/react-router"
import { RegistrationDialog } from "./Registrationdialog"
import { LoginDialog } from "./Logindialog"
import SearchEngine from "./searchengine"

export function Navbar() {
  // Ide jön majd az auth state (pl. user === null)
  const isLoggedIn = false; 

  return (
    <header className="border-b bg-background sticky top-0 z-50">
      <div className="container mx-auto flex h-16 items-center justify-between px-4 gap-6">
        
        {/* BAL OLDAL: Logo és Kereső sáv */}
        <div className="flex items-center gap-6 flex-1">
          <Link to="/" className="text-2xl font-black tracking-tighter text-emerald-950 shrink-0">
            webshop
          </Link>

          {/* A kereső sávod, ami most már szépen kitölti a helyet */}
          <div className="w-full max-w-md hidden md:block">
            <SearchEngine />
          </div>
        </div>

        {/* JOBB OLDAL: Ha nincs bejelentkezve, egy közös divben a gombok */}
        <div className="flex items-center gap-4">
          {!isLoggedIn ? (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-2xl bg-emerald-50/50 border border-emerald-100/50">
              {/* Ide jönnek a te előre megdizájnolt komponenseid */}
              <LoginDialog />
              <div className="h-6 w-[1px] bg-emerald-200 mx-1" /> {/* Elválasztó vonal a két gomb között */}
              <RegistrationDialog />
            </div>
          ) : (
            <div className="flex items-center gap-4">
               {/* Bejelentkezett állapot helye */}
               <span className="text-sm font-medium">Szia, Felhasználó!</span>
            </div>
          )}
        </div>

      </div>

      {/* MOBIL KERESŐ: Csak kicsi képernyőn jelenik meg a navbar alatt, ha szükséges */}
      <div className="md:hidden px-4 pb-3">
        <SearchEngine />
      </div>
    </header>
  )
}