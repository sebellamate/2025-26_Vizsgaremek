import { Button } from "@/components/ui/button"
import { useMutation, useQueryClient } from "@tanstack/react-query"
import axios from "axios"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useState } from "react"

type ProductDeleteDialogProps = {
  termek_id: number
}

const deleteProduct = (id: number) => {
  return axios.delete(`http://localhost:5000/api/termekek/${id}`)
}

export function DeleteproductDialog({ termek_id }: ProductDeleteDialogProps) {
  const [open, setOpen] = useState(false)
  const queryClient = useQueryClient()

  const { mutate: terminate, isPending } = useMutation({
    mutationFn: () => deleteProduct(termek_id),
    onSuccess() {
      queryClient.invalidateQueries({ queryKey: ["termekek"] })
      setOpen(false)
    },
  })

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="destructive">Törlés</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>termék törlése</DialogTitle>
          <DialogDescription>
            Biztos törölni szeretnéd ezt a terméket? Ez a művelet nem vonható vissza.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Mégse
          </Button>
          <Button variant="destructive" onClick={() => terminate()} disabled={isPending}>
            {isPending ? "Törlés..." : "Törlés"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}