import React from 'react';

export default function Loader() {
  return (
    <div className="loader-overlay">
      <div className="flex flex-col items-center">
        {/* Betöltés Szöveg */}
        <p className="text-2xl font-bold text-slate-700 mb-8 tracking-wider">
          Betöltés...
        </p>
        
        {/* Animált Pontok */}
        <div className="flex space-x-2">
          {/* A CSS osztályok hívják meg a bouncing animációt, késleltetéssel */}
          <div className="loader-dot" />
          <div className className="loader-dot dot-2" />
          <div className="loader-dot dot-3" />
        </div>
      </div>
    </div>
  );
}