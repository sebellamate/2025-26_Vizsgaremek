import { createFileRoute, useNavigate } from "@tanstack/react-router"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardAction,
} from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useTermekekBy_ids } from "@/components/hooks/useTermekekByid"

type Termek = {
  termek_id: number
  nev: string
  leiras: string
  ar: string
  kep_url: string
  kategoria_id: number
}

export const Route = createFileRoute("/search/$id/")({
  component: SearchResultsRoute,
})

function SearchResultsRoute() {
  const navigate = useNavigate()
  const { id } = Route.useParams()

  const ids = id.split(",").map(Number)

  const {
    data: termekek,
    isLoading,
    error,
  } = useTermekekBy_ids(ids)

  if (isLoading) return <p>Betöltés...</p>
  if (error) return <p>Hiba történt a keresési találatok lekérése közben.</p>
  if (!termekek || termekek.length === 0)
    return <p>Nincs találat.</p>

  return (
    <>
      <Card className="mb-4">
        <CardHeader>
          <CardTitle>Keresési találatok</CardTitle>
          <CardAction>
            <Button
              onClick={() =>
                navigate({
                  to: "/products",
                })
              }
            >
              Vissza
            </Button>
          </CardAction>
        </CardHeader>
      </Card>

      {termekek.map((termek: Termek) => (
        <Card key={termek.termek_id} className="mb-4">
          <CardContent>
            <p><strong>Név:</strong> {termek.nev}</p>
            <p><strong>Ár:</strong> {termek.ar} Ft</p>
            <p><strong>Leírás:</strong> {termek.leiras}</p>

            <Button
              className="mt-2"
              onClick={() =>
                navigate({
                  to: "/products/$id",
                  params: { id: String(termek.termek_id) },
                })
              }
            >
              Megtekintés
            </Button>
          </CardContent>
        </Card>
      ))}
    </>
  )
}
