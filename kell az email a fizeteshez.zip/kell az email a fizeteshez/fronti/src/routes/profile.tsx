import { LoginDialog } from '@/components/Logindialog'
import { useState } from 'react'
import { createFileRoute, useNavigate } from '@tanstack/react-router'
import { useAuthStatus } from '@/components/hooks/useAuthStatus'
import { useUserData } from '@/components/hooks/useUserData' // ÚJ HOOK
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { User, ShieldCheck, Package, LogOut, Ticket, Mail, Lock, Settings2 } from 'lucide-react'
import axios from 'axios'
import { useQueryClient } from '@tanstack/react-query'

export const Route = createFileRoute('/profile')({
  component: RouteComponent,
})

function RouteComponent() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  
  // 1. Alap auth státusz (userID-hoz)
  const { data: authUser, isLoading: authLoading } = useAuthStatus()
  
  // 2. Részletes adatok lekérése a backendről (Emailhez)
  const { data: fullUser, isLoading: detailsLoading } = useUserData(authUser?.userID || null)
  
  const [activeTab, setActiveTab] = useState<'profil' | 'kuponok' | 'rendelesek'>('profil')

  const handleLogout = async () => {
    try {
      await axios.delete("http://localhost:5000/api/auth/logout", {
        withCredentials: true,
      });
      queryClient.invalidateQueries({ queryKey: ["status"] })
      navigate({ to: "/" });
    } catch (error) {
      console.error("Hiba a kijelentkezés során:", error);
    }
  };

  if (authLoading || detailsLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-emerald-50/20">
        <div className="flex flex-col items-center gap-2">
          <div className="h-12 w-12 animate-spin rounded-full border-4 border-emerald-600 border-t-transparent"></div>
          <p className="text-emerald-700 font-medium animate-pulse">Profil szinkronizálása...</p>
        </div>
      </div>
    )
  }
  
  // Összefésüljük a két adatforrást
  const user = fullUser || authUser;

  if (!user) {
    return (
      <div className="container mx-auto p-20 text-center flex flex-col items-center justify-center min-h-[60vh]">
        <div className="bg-emerald-50 p-6 rounded-full mb-6">
          <User className="w-16 h-16 text-emerald-200" />
        </div>
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Bejelentkezés szükséges</h2>
        <p className="mb-6 text-gray-500 max-w-xs mx-auto">A profilod és kedvezményeid eléréséhez kérjük, lépj be a fiókodba.</p>
        <LoginDialog />
      </div>
    )
  }

  return (
    <div className="container mx-auto py-10 px-4 max-w-5xl">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        
        {/* OLDALSÁV - NAVIGÁCIÓ */}
        <aside className="md:col-span-1 space-y-4">
          <Card className="border-emerald-100 shadow-md overflow-hidden bg-white">
            <div className="bg-emerald-600 h-2 w-full" />
            <CardHeader className="text-center pb-4">
              <div className="mx-auto bg-emerald-50 w-20 h-20 rounded-full flex items-center justify-center mb-3 border-2 border-emerald-100 shadow-inner">
                <User className="w-10 h-10 text-emerald-600" />
              </div>
              <CardTitle className="text-xl font-bold text-gray-800 truncate px-2">
                {user.username}
              </CardTitle>
              {user.isAdmin && (
                <Badge className="mt-1 bg-emerald-600 hover:bg-emerald-700 shadow-sm px-3">
                  <ShieldCheck className="w-3 h-3 mr-1" /> Admin
                </Badge>
              )}
            </CardHeader>
            <CardContent className="p-2 space-y-1">
              {[
                { id: 'profil', label: 'Profil adatok', icon: User },
                { id: 'kuponok', label: 'Kuponjaim', icon: Ticket },
                { id: 'rendelesek', label: 'Rendeléseim', icon: Package },
              ].map((tab) => (
                <Button 
                  key={tab.id}
                  variant="ghost" 
                  className={`w-full justify-start transition-all duration-200 ${
                    activeTab === tab.id 
                    ? 'bg-emerald-50 text-emerald-700 font-bold shadow-sm' 
                    : 'text-gray-500 hover:text-emerald-600 hover:bg-emerald-50/50'
                  }`}
                  onClick={() => setActiveTab(tab.id as any)}
                >
                  <tab.icon className={`w-4 h-4 mr-3 ${activeTab === tab.id ? 'text-emerald-600' : ''}`} />
                  {tab.label}
                </Button>
              ))}
            </CardContent>
          </Card>

          <Button 
            variant="outline" 
            className="w-full text-red-500 border-red-100 hover:bg-red-50 hover:text-red-600 transition-all shadow-sm"
            onClick={handleLogout}
          >
            <LogOut className="w-4 h-4 mr-2" /> Kijelentkezés
          </Button>
        </aside>

        {/* TARTALOM */}
        <main className="md:col-span-3 min-h-[500px]">
          {activeTab === 'profil' && (
            <Card className="border-emerald-100 shadow-md animate-in fade-in slide-in-from-right-4 duration-500 bg-white">
              <CardHeader className="border-b border-gray-50 pb-6">
                <div className="flex items-center gap-2 text-emerald-800 mb-1">
                  <Settings2 className="w-5 h-5" />
                  <CardTitle>Fiók beállítások</CardTitle>
                </div>
                <CardDescription>Itt találod a személyes adataidat és jelszókezelési beállításaidat.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-8 pt-6">
                
                {/* Adatok rácsa */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase text-gray-400 ml-1">Felhasználónév</label>
                    <div className="p-4 border border-gray-100 rounded-2xl bg-gray-50/30 flex items-center gap-3">
                      <User className="w-4 h-4 text-emerald-500" />
                      <p className="font-semibold text-gray-700">{user.name}</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase text-gray-400 ml-1">Email cím</label>
                    <div className="p-4 border border-gray-100 rounded-2xl bg-gray-50/30 flex items-center gap-3">
                      <Mail className="w-4 h-4 text-emerald-500" />
                      <p className="font-semibold text-gray-700">{user.email || "Nincs megadva"}</p>
                    </div>
                  </div>

                  <div className="sm:col-span-2 space-y-2">
                    <label className="text-xs font-bold uppercase text-gray-400 ml-1">Biztonság</label>
                    <div className="p-4 border border-gray-100 rounded-2xl bg-gray-50/30 flex justify-between items-center group">
                      <div className="flex items-center gap-3">
                        <Lock className="w-4 h-4 text-emerald-500" />
                        <div>
                          <p className="text-sm font-semibold text-gray-700">Jelszó</p>
                          <p className="text-xs text-gray-400 tracking-[0.3em]">••••••••••••</p>
                        </div>
                      </div>
                      <Button variant="outline" size="sm" className="border-emerald-200 text-emerald-700 hover:bg-emerald-600 hover:text-white transition-all">
                        Módosítás
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Admin Szekció */}
                {user.isAdmin && (
                  <div className="p-6 bg-emerald-600 rounded-2xl shadow-lg shadow-emerald-100 flex flex-col sm:flex-row items-center justify-between gap-4 text-white">
                    <div className="flex items-center gap-4 text-center sm:text-left">
                      <div className="p-3 bg-white/20 rounded-xl backdrop-blur-sm">
                        <ShieldCheck className="w-8 h-8 text-white" />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg leading-tight">Adminisztrációs Panel</h3>
                        <p className="text-emerald-50 text-sm opacity-90">Termékek, kategóriák és felhasználók kezelése.</p>
                      </div>
                    </div>
                    <Button 
                      className="bg-white text-emerald-700 hover:bg-emerald-50 font-bold px-8 shadow-sm transition-transform active:scale-95" 
                      onClick={() => navigate({ to: "/Adminpage" })}
                    >
                      Kezelés indítása
                    </Button>
                  </div>
                )}

                {/* Profil szerkesztése gomb */}
                <div className="flex justify-end border-t pt-6">
                  <Button className="bg-emerald-600 hover:bg-emerald-700 px-8 shadow-md">
                    Adatok frissítése
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Kuponok és Rendelések placeholder kártyák (ugyanaz mint korábban) */}
          {activeTab === 'kuponok' && (
            <Card className="border-emerald-100 shadow-md border-dashed animate-in zoom-in-95 duration-500 flex flex-col items-center justify-center py-24 text-center bg-white">
                <div className="bg-emerald-50 p-6 rounded-full mb-4">
                  <Ticket className="w-12 h-12 text-emerald-600 opacity-80" />
                </div>
                <CardTitle className="text-gray-700 text-xl">Kuponjaid</CardTitle>
                <CardDescription className="max-w-[280px] mt-2 text-gray-400">
                  Jelenleg nincsenek beváltható kuponjaid. Nézz vissza később az ünnepi ajánlatokért!
                </CardDescription>
            </Card>
          )}

          {activeTab === 'rendelesek' && (
            <Card className="border-emerald-100 shadow-md animate-in fade-in duration-500 bg-white">
              <CardHeader>
                <CardTitle className="text-emerald-900">Rendelési előzmények</CardTitle>
              </CardHeader>
              <CardContent className="flex flex-col items-center justify-center py-24 opacity-60">
                <div className="relative mb-6">
                   <Package className="w-16 h-16 text-gray-300" />
                   <div className="absolute -bottom-1 -right-1 bg-white rounded-full p-1 text-emerald-500"><Settings2 className="w-5 h-5" /></div>
                </div>
                <p className="text-gray-400 font-medium italic">Még egyetlen rendelésed sem érkezett be.</p>
                <Button variant="link" onClick={() => navigate({to: '/'})} className="text-emerald-600 mt-2">Irány a termékekhez →</Button>
              </CardContent>
            </Card>
          )}
        </main>

      </div>
    </div>
  )
}