const db = require("../db")

const { kategoriaService } = require("../services")(db)

exports.getKategoriak = async (req,res,next) => {
    try{
        res.status(200).json(await kategoriaService.getKategoriak());
    }
    catch (error) {
        next(error)
    }
    
}
exports.postKategoria = async (req,res,next) => {
    try{
        const {nev} = req.body || {};
        res.status(201).json(await kategoriaService.postKategoria({nev}))
    }catch(error){
        next(error)
    }
}