const { BadRequestError } = require("../errors");
class KategoriaService{
    constructor(db){
        this.kategoriaRepository = require("../repositories")(db).kategoriaRepository;
    }
    async getKategoriak(){
        return await this.kategoriaRepository.getKategoriak();
    }
    async postKategoria(kategoria){
        if(!kategoria){
            throw new BadRequestError("Hiányzó termék adatok.");
        }
        return await this.kategoriaRepository.postKategoria(kategoria);
    }
}
module.exports = KategoriaService;