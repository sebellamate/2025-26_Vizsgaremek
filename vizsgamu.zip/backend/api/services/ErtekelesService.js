const { ValidationError, NotFoundError } = require("../errors");

class ErtekelesService {
    constructor(db) {
        this.ertekelesRepository = require("../repositories")(db).ertekelesRepository;
    }

    async getErtekelesek() {
        return await this.ertekelesRepository.getErtekelesek();
    }

    async postErtekeles(ertekelesData) {
        if (!ertekelesData || Object.keys(ertekelesData).length === 0) {
            throw new ValidationError("Hiányzó értékelés adatok.");
        }

        if (!ertekelesData.user_id || !ertekelesData.termek_id) {
            throw new ValidationError("A felhasználó és a termék azonosítója kötelező az értékeléshez.");
        }

        const pont = parseInt(ertekelesData.pontszam);
        if (isNaN(pont) || pont < 1 || pont > 5) {
            throw new ValidationError("Az értékelésnek 1 és 5 közötti egész számnak kell lennie.");
        }

        return await this.ertekelesRepository.postErtekeles(ertekelesData);
    }

    async getErtekelesekByTermek(termek_id) {
        if (!termek_id) {
            throw new ValidationError("Hiányzó termék azonosító a vélemények lekéréséhez.");
        }
        return await this.ertekelesRepository.getErtekelesekByTermek(termek_id);
    }

    async getErtekeles(ertekeles_id) {
        if (!ertekeles_id) {
            throw new ValidationError("Hiányzó értékelés azonosító.");
        }

        const ertekeles = await this.ertekelesRepository.getErtekeles(ertekeles_id);

        if (!ertekeles) {
            throw new NotFoundError("Az értékelés nem található.", { data: ertekeles_id });
        }
        return ertekeles;
    }

    async deleteErtekeles(ertekeles_id) {
        if (!ertekeles_id) {
            throw new ValidationError("Hiányzó azonosító az értékelés törléséhez.");
        }

        await this.getErtekeles(ertekeles_id);

        return await this.ertekelesRepository.deleteErtekeles(ertekeles_id);
    }
}

module.exports = ErtekelesService;