const { sendOrderConfirmationEmail } = require("../utilities/emailUtils");

class RendelesService {
    constructor(db) {
        this.sequelize = db.sequelize;
        this.db = db;
        this.rendelesRepository = require("../repositories")(db).rendelesRepository;
    }

    async getUserRendelesek(userId) {
        return await this.rendelesRepository.getRendelesekByUserId(userId);
    }

    async postRendeles(data) {
        if (!data.tetelek || !Array.isArray(data.tetelek) || data.tetelek.length === 0) {
            throw new Error("Nincs egyetlen rendeléstétel sem");
        }

        let ujRendeles;

        await this.sequelize.transaction(async (t) => {
            
            ujRendeles = await this.rendelesRepository.createRendeles({
                user_id: Number(data.user_id),
                osszeg: Number(data.osszeg),
                cim: data.cim,
                rendeles_datuma: new Date(),
                statusz: 'fizetve'
            }, t);

            if (!ujRendeles || !ujRendeles.rendeles_id) {
                throw new Error("Sikertelen rendelés létrehozás: nincs rendeles_id");
            }

            const validKuponId = (data.kupon_id !== "none" && data.kupon_id !== null && data.kupon_id !== undefined) 
                ? Number(data.kupon_id) 
                : null;

            if (validKuponId && !isNaN(validKuponId)) {
                await this.rendelesRepository.invalidateKupon(
                    validKuponId, 
                    data.user_id, 
                    t
                );
            }

            const elokeszitettTetelek = data.tetelek.map(tetel => {
                if (!tetel.termek_id || !tetel.mennyiseg) {
                    throw new Error("Hibás tételadatok (hiányzó termék ID vagy mennyiség)");
                }
                return {
                    rendeles_id: ujRendeles.rendeles_id,
                    termek_id: Number(tetel.termek_id),
                    mennyiseg: Number(tetel.mennyiseg),
                    egyseg_ar: Number(tetel.egyseg_ar),
                };
            });

            await this.rendelesRepository.createRendelesTetelek(elokeszitettTetelek, t);

            await this.rendelesRepository.emptyBasket(data.user_id, t);
        });

        try {
            const user = await this.db.User.findByPk(data.user_id);
            if (user && user.email) {
                await sendOrderConfirmationEmail(user.email, {
                    orderId: ujRendeles.rendeles_id,
                    totalAmount: data.osszeg,
                    address: data.cim,
                    items: data.tetelek
                });
            }
        } catch (emailError) {
            console.error("Nem sikerült kiküldeni a visszaigazoló e-mailt:", emailError);
        }

        return ujRendeles;
    }
}

module.exports = RendelesService;