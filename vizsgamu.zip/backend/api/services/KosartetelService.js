const { ValidationError, NotFoundError } = require("../errors");

class KosartetelService {
    constructor(db) {
        this.kosartetelRepository = require("../repositories")(db).kosartetelRepository;
    }

    async postTetel(tetelData) {
        if (!tetelData || Object.keys(tetelData).length === 0) {
            throw new ValidationError("Hiányzó kosár tétel adatok.");
        }

        if (!tetelData.user_id || !tetelData.termek_id) {
            throw new ValidationError("A felhasználó és a termék azonosítója kötelező a tétel létrehozásához.");
        }

        if (tetelData.mennyiseg !== undefined) {
            const mennyiseg = parseInt(tetelData.mennyiseg);
            if (isNaN(mennyiseg) || mennyiseg < 1) {
                throw new ValidationError("A mennyiségnek legalább 1-nek kell lennie.");
            }
        }

        return await this.kosartetelRepository.postTetel(tetelData);
    }

    async getTetel(id) {
        if (!id) {
            throw new ValidationError("Hiányzó tétel azonosító.");
        }

        const tetel = await this.kosartetelRepository.getTetel(id);

        if (!tetel) {
            throw new NotFoundError("A keresett kosár tétel nem található.", { data: id });
        }

        return tetel;
    }

    async getTetelek(id) {
        if (!id) {
            throw new ValidationError("Hiányzó azonosító a tételek lekéréséhez.");
        }
        
        return await this.kosartetelRepository.getTetelek(id);
    }

    async PlusOne(id) {
        if (!id) {
            throw new ValidationError("Hiányzó azonosító a mennyiség növeléséhez.");
        }

        await this.getTetel(id);

        return await this.kosartetelRepository.PlusOne(id);
    }

    async MinusOne(id) {
        if (!id) {
            throw new ValidationError("Hiányzó azonosító a mennyiség csökkentéséhez.");
        }

        const tetel = await this.getTetel(id);

        if (tetel.mennyiseg <= 1) {
            throw new ValidationError("A mennyiség nem csökkenthető 1 alá.");
        }

        return await this.kosartetelRepository.MinusOne(id);
    }

    async deleteTetel(id) {
        if (!id) {
            throw new ValidationError("Hiányzó azonosító a tétel törléséhez.");
        }

        await this.getTetel(id);

        return await this.kosartetelRepository.deleteTetel(id);
    }
}

module.exports = KosartetelService;