const { DbError } = require("../errors");

class KosartetelRepository {
    constructor(db) {
        this.Kosartetel = db.KosarTetel;
        this.sequelize = db.sequelize;
    }

    async postTetel(tetelData) {
        try {
            return await this.Kosartetel.create({
                ...tetelData,
                mennyiseg: 1
            });
        } catch (error) {
            throw new DbError("Hiba a kosár tétel létrehozásakor", { details: error.message, data: tetelData });
        }
    }

    async getTetel(id) {
        try {
            return await this.Kosartetel.findOne({
                where: { id }
            });
        } catch (error) {
            throw new DbError("Hiba a kosár tétel lekérésekor", { details: error.message, data: id });
        }
    }

    async getTetelek(user_id) {
        try {
            return await this.Kosartetel.findAll({
                where: { user_id }
            });
        } catch (error) {
            throw new DbError("Hiba a felhasználó kosár tételeinek lekérésekor", { details: error.message, data: user_id });
        }
    }

    async PlusOne(id) {
        try {
            const t = await this.Kosartetel.findByPk(id);
            if (!t) return null;
            t.mennyiseg += 1;
            await t.save();
            return t;
        } catch (error) {
            throw new DbError("Hiba a mennyiség növelésekor", { details: error.message, data: id });
        }
    }

    async MinusOne(id) {
        try {
            const t = await this.Kosartetel.findByPk(id);
            if (!t || t.mennyiseg <= 1) return t;
            t.mennyiseg -= 1;
            await t.save();
            return t;
        } catch (error) {
            throw new DbError("Hiba a mennyiség csökkentésekor", { details: error.message, data: id });
        }
    }

    async deleteTetel(id) {
        try {
            return await this.Kosartetel.destroy({
                where: { id }
            });
        } catch (error) {
            throw new DbError("Hiba a kosár tétel törlésekor", { details: error.message, data: id });
        }
    }
}

module.exports = KosartetelRepository;