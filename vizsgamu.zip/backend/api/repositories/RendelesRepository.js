const { DbError } = require("../errors");

class RendelesRepository {
    constructor(db) {
        this.db = db; 
        this.KosarTetel = db.KosarTetel; 
        this.Rendeles = db.Rendeles;
        this.RendelesTetel = db.RendelesTetel;
        this.Termek = db.Termek; 
        this.Kupon = db.Kupon;
        this.sequelize = db.sequelize;
    }

    async getRendelesekByUserId(userId) {
        try {
            return await this.Rendeles.findAll({
                where: { user_id: userId },
                include: [{
                    model: this.RendelesTetel,
                    as: 'Tetelek',
                    include: [{
                        model: this.Termek, 
                        as: 'Termek' 
                    }]
                }],
                order: [['rendeles_datuma', 'DESC']]
            });
        } catch (error) {
            throw new DbError("Hiba a rendelések lekérésekor", { details: error.message, data: userId });
        }
    }

    async createRendeles(data, transaction) {
        try {
            return await this.Rendeles.create({
                user_id: data.user_id,          
                osszeg: data.osszeg,          
                cim: data.cim,                
                statusz: 'fizetve',            
                rendeles_datuma: new Date()    
            }, { transaction });
        } catch (error) {
            throw new DbError("Hiba a rendelés létrehozásakor", { details: error.message, data });
        }
    }

    async invalidateKupon(kuponId, userId, transaction) {
        try {
            return await this.Kupon.update(
                { ervenyes: false }, 
                { 
                    where: { 
                        kupon_id: kuponId,
                        user_id: userId 
                    }, 
                    transaction 
                }
            );
        } catch (error) {
            throw new DbError("Hiba a kupon érvénytelenítésekor", { details: error.message, data: { kuponId, userId } });
        }
    }

    async createRendelesTetelek(dataArray, transaction) {
        try {
            return await this.RendelesTetel.bulkCreate(dataArray, { transaction });
        } catch (error) {
            throw new DbError("Hiba a rendelés tételek létrehozásakor", { details: error.message, data: dataArray });
        }
    }

    async emptyBasket(userId, transaction) {
        try {
            return await this.KosarTetel.destroy({
                where: { user_id: userId },
                transaction
            });
        } catch (error) {
            throw new DbError("Hiba a kosár ürítésekor", { details: error.message, data: userId });
        }
    }
}

module.exports = RendelesRepository;