const { Op } = require('sequelize');
const { DbError } = require("../errors");

class TermekRepository {
    constructor(db) {
        this.Termek = db.Termek;
        this.sequelize = db.sequelize;
    }

    async getTermekek() {
        try {
            return await this.Termek.findAll();
        } catch (error) {
            throw new DbError("Hiba a termékek lekérésekor", { details: error.message });
        }
    }

    async getTermek(termek_id) {
        try {
            return await this.Termek.findOne({
                where: { termek_id }
            });
        } catch (error) {
            throw new DbError("Hiba a termék lekérésekor", { details: error.message, data: termek_id });
        }
    }

    async deleteTermek(termek_id) {
        try {
            return await this.Termek.destroy({
                where: { termek_id }
            });
        } catch (error) {
            throw new DbError("Hiba a termék törlésekor", { details: error.message, data: termek_id });
        }
    }

    async editTermek(termek_id, termekData) {
        try {
            await this.Termek.update(termekData, { where: { termek_id } });
            return await this.getTermek(termek_id);
        } catch (error) {
            throw new DbError("Hiba a termék módosításakor", { details: error.message, data: { termek_id, termekData } });
        }
    }

    async postTermek(termekData) {
        try {
            return await this.Termek.create(termekData);
        } catch (error) {
            throw new DbError("Hiba a termék létrehozásakor", {
                details: error.message,
                data: termekData,
            });
        }
    }

    async getTermekekBykosar_id(kosar_id) {
    try {
        const KosarTetel = this.sequelize.models.KosarTetel;
        const tetelek = await KosarTetel.findAll({
            where: { kosar_id },
            include: [
                {
                    model: this.Termek,
                    as: "Termek",
                },
            ],
        });

        return tetelek.map(t => ({
            ...t.Termek?.toJSON(),
            mennyiseg: t.mennyiseg,
            kosar_tetel_id: t.id
        }));
    } catch (error) {
        throw new DbError("Hiba a kosár tartalmának lekérésekor", { details: error.message, data: kosar_id });
    }
}

    async getTermekekBy_ids(ids) {
        try {
            return await this.Termek.findAll({
                where: {
                    termek_id: {
                        [Op.in]: ids
                    }
                }
            });
        } catch (error) {
            throw new DbError("Hiba a termékek listázásakor (IDs)", { details: error.message, data: ids });
        }
    }

    async keresTermek(keres) {
        try {
            if (!keres) return [];
            return await this.Termek.findAll({
                where: {
                    [Op.or]: [
                        { nev: { [Op.like]: `%${keres}%` } },
                        { leiras: { [Op.like]: `%${keres}%` } }
                    ]
                }
            });
        } catch (error) {
            throw new DbError("Hiba a keresés során", { details: error.message, data: keres });
        }
    }

    async getTermekekByKategoria(kategoriaId) {
        try {
            return await this.Termek.findAll({
                where: {
                    kategoria_id: kategoriaId
                }
            });
        } catch (error) {
            throw new DbError("Hiba a kategória lekérésekor", { details: error.message, data: kategoriaId });
        }
    }
}

module.exports = TermekRepository;