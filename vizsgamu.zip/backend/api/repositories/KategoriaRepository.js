const { DbError } = require("../errors");

class KategoriaRepository {
    constructor(db) {
        this.Kategoria = db.Kategoria;
    }

    async getKategoriak() {
        try {
            return await this.Kategoria.findAll();
        } catch (error) {
            throw new DbError("Hiba a kategóriák lekérésekor", { details: error.message });
        }
    }
    async postKategoria(kategoria){
        try {
            return await this.Kategoria.create(kategoria)
        } catch(error){
             throw new DbError("Hiba a kategória létrehozásakor", { details: error.message });
        }
    }
}

module.exports = KategoriaRepository;