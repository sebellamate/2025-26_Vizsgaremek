const request = require("supertest");
const app = require("../../app"); // Points to your Express application
const db = require("../db"); // Points to your Sequelize db initialization
const { userIsLoggedIn } = require("../middlewares/authMiddleware");

// 1. Tell Jest to use your manual mock implementation from ./api/db/__mocks__
jest.mock("../db");
jest.mock("../models/User");

// 2. NEW: Mock the authUtils to bypass real JWT verification in tests
jest.mock("../utilities/authUtils", () => ({
  verifyToken: jest.fn((token) => {
    if (token === "valid_mock_token_for_admin" || token === "valid_admin_token") {
      return { id: 1, userID: 1, isAdmin: true, name: "AdminUser" };
    }
    if (token === "valid_user_token") {
      return { id: 2, userID: 2, isAdmin: false, name: "NormalUser" };
    }
    throw new Error("Invalid token");
  }),
  generateUserToken: jest.fn().mockReturnValue("valid_user_token"),
  setCookie: jest.fn(),
}));

describe("Express API CRUD Tests", () => {
  // --- SETUP AND TEARDOWN ---
  beforeAll(async () => {
    // Initialize/Sync the mocked database before running any tests
    if (db.sequelize && db.sequelize.sync) {
      await db.sequelize.sync({ force: true });

      if (db.Kategoria) {
            await db.Kategoria.create({ id: 1, nev: 'Teszt Kategória' });
        }

        if (db.User) {
          // FIX: Use a password that passes the Sequelize regex validation
          await db.User.create({ 
              ID: 1, // Note: Your model uses uppercase 'ID' as primaryKey
              name: 'Admin', 
              email: 'admin@test.com', 
              password: 'AdminPassword123' // <--- CHANGED HERE
          });
      }
    }
  });

  afterAll(async () => {
    // Close the mocked database connection after all tests complete
    if (db.sequelize && db.sequelize.close) {
      await db.sequelize.close();
    }
  });

  beforeEach(() => {
    // Clear mock histories between tests to avoid test pollution
    jest.clearAllMocks();
  });

  // Dummy cookie for routes protected by authMiddleware (userIsLoggedIn / isAdmin)
  // Adjust this based on how your mock auth middleware validates the token
  const mockAuthCookie = "user_token=valid_mock_token_for_admin";

  // --- TERMÉKEK (PRODUCTS) CRUD TESTS ---
  describe("Termékek API (/api/termekek)", () => {
    let createdTermekId = 1; // Assuming mock DB will return ID 1

    it("POST /api/termekek - should create a new termek", async () => {
      // Payload matching termekController.postTermek expectation
      const newTermek = {
        nev: "Teszt Termék",
        leiras: "Ez egy csodálatos teszt termék leírása.",
        ar: 2500,
        kep_url: "/kepek/teszt.jpg",
        kategoria_id: 1,
      };

      const res = await request(app)
        .post("/api/termekek")
        .set("Cookie", [mockAuthCookie]) // Requires userIsLoggedIn & isAdmin
        .send(newTermek);

        console.error(res);

      expect(res.statusCode).toBe(200); // Your controller uses res.status(200) for creation
      expect(res.body).toHaveProperty("nev", newTermek.nev);
      
      if (res.body.termek_id) createdTermekId = res.body.termek_id;
    });

    it("GET /api/termekek - should fetch all termekek", async () => {
      const res = await request(app).get("/api/termekek");

      expect(res.statusCode).toBe(200);
      expect(Array.isArray(res.body)).toBeTruthy();
    });

    it("GET /api/termekek/:termek_id - should fetch a single termek by ID", async () => {
      const res = await request(app).get(`/api/termekek/${createdTermekId}`);

      expect(res.statusCode).toBe(200);
      // Validate the mock response format
      expect(res.body).toBeDefined();
    });

    it("DELETE /api/termekek/:termek_id - should delete a termek", async () => {
      const res = await request(app)
        .delete(`/api/termekek/${createdTermekId}`)
        .set("Cookie", [mockAuthCookie]); // Requires auth

      expect(res.statusCode).toBe(200);
    });
  });

  // --- USERS CRUD TESTS ---
  describe("Users API (/api/users)", () => {
    let createdUserId = 1;

    it("POST /api/users - should create a new user", async () => {
      // Payload matching userController.createUser expectation
      const newUser = {
        username: "TestElek",
        email: "teszt.elek@example.com",
        password: "securepassword123",
      };

      const res = await request(app)
        .post("/api/users")
        .send(newUser);

      expect(res.statusCode).toBe(201); // Your controller uses res.status(201)
      expect(res.body).toHaveProperty("email", newUser.email);
      expect(res.body).toHaveProperty("name", newUser.username);

      if (res.body.id) createdUserId = res.body.id;
    });

    it("GET /api/users - should fetch all users", async () => {
      const res = await request(app)
        .get("/api/users")
        .set("Cookie", [mockAuthCookie]); // Requires isAdmin & isLoggedIn

      expect(res.statusCode).toBe(200);
      expect(Array.isArray(res.body)).toBeTruthy();
    });

    it("GET /api/users/:userID - should fetch a user by ID", async () => {
      const res = await request(app).get(`/api/users/${createdUserId}`);

      expect(res.statusCode).toBe(200);
    });
  });

  // --- KOSÁR TÉTELEK (BASKET ITEMS) CRUD TESTS ---
  describe("Kosártételek API (/api/kosartetelek)", () => {
    let tetelId = 1;
    let activeTermekId;

    beforeAll(async () => {
      // 1. Create a fresh product specifically for the Kosár tests
      // (Because the previous test suite just deleted termek_id 1)
      if (db.Termek) {
        const ujTermek = await db.Termek.create({
          nev: "Kosár Teszt Termék",
          leiras: "Ez egy termék a kosár teszthez",
          ar: 1500,
          kep_url: "/kepek/teszt.jpg",
          kategoria_id: 1,
        });
        activeTermekId = ujTermek.termek_id || ujTermek.id;
      }
    });

    it("POST /api/kosartetelek - should add an item to the basket", async () => {
      const newTetel = {
        user_id: 1, 
        termek_id: activeTermekId, // Uses the freshly created product ID
        mennyiseg: 1
      };

      const res = await request(app)
        .post("/api/kosartetelek")
        .send(newTetel);

      expect(res.statusCode).toBe(200);
      
      if(res.body && res.body.id) tetelId = res.body.id;
    });

    it("GET /api/kosartetelek/osszes/:id - should fetch all items for a user", async () => {
      const res = await request(app).get(`/api/kosartetelek/osszes/1`);

      expect(res.statusCode).toBe(200);
      expect(Array.isArray(res.body)).toBeTruthy();
    });

    it("PUT /api/kosartetelek/pluszegy/:id - should increment item quantity", async () => {
      const res = await request(app).put(`/api/kosartetelek/pluszegy/${tetelId}`);

      expect(res.statusCode).toBe(200);
    });
  });
});