const express = require("express");

const router = express.Router();

const kosartetelController = require("../controllers/kosartetelController");
const authMiddleware = require("../middlewares/authMiddleware");


router.post("/", [ authMiddleware.userIsLoggedIn], kosartetelController.postTetel);

router.param("id", (req, res, next, id) => 
{
    req.id = id;

    next();
});

router.get("/:id", [ authMiddleware.userIsLoggedIn], kosartetelController.getTetel);
router.get("/osszes/:id", [ authMiddleware.userIsLoggedIn], kosartetelController.getTetelek);
router.put("/pluszegy/:id", [ authMiddleware.userIsLoggedIn], kosartetelController.PlusOne);
router.put("/minuszegy/:id", [ authMiddleware.userIsLoggedIn], kosartetelController.MinusOne);
router.delete("/torles/:id", [ authMiddleware.userIsLoggedIn], kosartetelController.deleteTetel)

module.exports = router;