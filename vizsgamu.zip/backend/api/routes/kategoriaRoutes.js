const express = require("express");

const router = express.Router();

const kategoriaController = require("../controllers/kategoriaController");
const authMiddleware = require("../middlewares/authMiddleware");

router.get("/", kategoriaController.getKategoriak);
router.post("/", [ authMiddleware.userIsLoggedIn, authMiddleware.isAdmin ], kategoriaController.postKategoria);


module.exports = router;