const { Sequelize } = require("sequelize");

// 1. Create the real in-memory SQLite instance for testing
const sequelize = new Sequelize("sqlite::memory:", {
  logging: false, // Keeps your test console clean
});

// 2. Initialize your actual models with the in-memory instance
// Make sure this path correctly points to your models folder/index
const models = require("../../models")(sequelize);

// 3. (Optional) Spy on the Sequelize methods.
// This allows you to do expect(db.sequelize.sync).toHaveBeenCalled() in your tests
// while STILL actually executing the real in-memory sync/close/transaction.
jest.spyOn(sequelize, 'sync');
jest.spyOn(sequelize, 'close');
jest.spyOn(sequelize, 'transaction');

// 4. Export the standard DB object format expected by your services/controllers
module.exports = {
  Sequelize,
  sequelize,
  ...models,
};