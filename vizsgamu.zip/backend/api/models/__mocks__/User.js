const { Model, DataTypes } = require("sequelize");

module.exports = (sequelize) => {
    class User extends Model {};

    User.init(
        {
            ID: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true, allowNull: false },
            name: {
                type: DataTypes.STRING,
                allowNull: false,
            },
            email: {
                type: DataTypes.STRING,
                allowNull: false,
                validate: { isEmail: true }
            },
            password: {
                type: DataTypes.STRING,
                allowNull: false,
                // VALIDATION REMOVED FOR MOCK
            },
            reset_token: { type: DataTypes.STRING, allowNull: true },
            reset_expires: { type: DataTypes.DATE, allowNull: true },
            isAdmin: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false }
        },
        {
            sequelize,
            modelName: "User",
            createdAt: "registeredAt",
            updatedAt: false,
            scopes: {
                public: { attributes: ["name", "email", "registeredAt", "isAdmin"] },
                admin: { where: { isAdmin: true } }
            }
        }
    );

    // Dummy mock for password hashing so tests run fast without bcrypt
    const mockHashPassword = (user) => {
        if (user.changed('password')) {
            user.password = "mock_hashed_" + user.password;
        }
    };

    User.beforeCreate(mockHashPassword);
    User.beforeUpdate(mockHashPassword);

    return User;
};