"use client"

import { createFileRoute } from '@tanstack/react-router'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useTermek } from '../../../components/hooks/useTermek'
import { useErtekelesek, useCreateErtekeles } from '@/components/hooks/useErtekelesek' 
// Itt importáljuk be az új hookot (ellenőrizd az elérési utat, ha máshol van!)
import { useTetelPost } from '@/components/hooks/useTetelpost' 
import { useAuthStatus } from '@/components/hooks/useAuthStatus'
import { Navbar } from "@/components/Navbar"
import { NavbarLoggedIn } from "@/components/NavbarLoggedin" 
import { ShoppingCart, Star, MessageSquare, Send } from 'lucide-react'
import { useMemo, useState } from 'react'

export const Route = createFileRoute('/products/$id/')({
  component: RouteComponent,
})

function RouteComponent() {
  const params = Route.useParams()
  const termekId = Number(params.id)
  
  const [ujVelemeny, setUjVelemeny] = useState("")
  const [ujPontszam, setUjPontszam] = useState(5)

  const { data: user, isLoading: authLoading } = useAuthStatus()
  const { data: termek, isLoading: termekLoading, error } = useTermek(termekId)
  const { data: ertekelesek, isLoading: ertekelesLoading } = useErtekelesek(termekId)
  
  const createErtekelesMutation = useCreateErtekeles()
  
  // Itt hívjuk meg a hookot a kosárba tevéshez
  const { createTetel, isPending } = useTetelPost()

  const handleErtekelesBekuldes = () => {
    if (!user) return;
    
    createErtekelesMutation.mutate({
      termek_id: termekId,
      user_id: user.userID,
      pontszam: ujPontszam,
      velemeny: ujVelemeny
    }, {
      onSuccess: () => {
        setUjVelemeny("");
        setUjPontszam(5);
      }
    });
  };

  const atlagPontszam = useMemo(() => {
    if (!ertekelesek || ertekelesek.length === 0) return 0;
    const osszeg = ertekelesek.reduce((acc, curr) => acc + curr.pontszam, 0);
    return (osszeg / ertekelesek.length).toFixed(1);
  }, [ertekelesek]);

  const isLoggedIn = !!user

  if (authLoading || termekLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-white">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-700" />
      </div>
    )
  }

  if (error) return <div className="p-20 text-center text-red-500 font-bold">A keresett termék nem található.</div>

  return (
    <div className="min-h-screen bg-slate-50/30">
      {isLoggedIn ? <NavbarLoggedIn /> : <Navbar />}

      <main className="max-w-6xl mx-auto p-6 lg:p-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          
          <div className="lg:sticky lg:top-24">
            <div className="aspect-square rounded-3xl overflow-hidden shadow-2xl border-8 border-white bg-white">
              <img 
                src={`/kepek/${termek?.kep_url}`} 
                alt={termek?.nev} 
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          <div className="flex flex-col space-y-8">
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Badge variant="outline" className="text-emerald-600 border-emerald-200 bg-emerald-50 px-3 py-1">
                  Készleten
                </Badge>
                {ertekelesek && ertekelesek.length > 0 && (
                  <div className="flex items-center gap-1 text-yellow-500 font-bold">
                    <Star className="w-4 h-4 fill-current" />
                    <span>{atlagPontszam}</span>
                    <span className="text-slate-400 font-normal text-sm">({ertekelesek.length} vélemény)</span>
                  </div>
                )}
              </div>
              
              <h1 className="text-5xl font-black text-emerald-950 tracking-tight leading-tight">
                {termek?.nev}
              </h1>
              <p className="text-slate-500 text-xl leading-relaxed">
                {termek?.leiras}
              </p>
            </div>

            <div className="p-8 bg-white rounded-3xl shadow-sm border border-emerald-100 flex flex-col gap-6">
              <div>
                <span className="text-slate-400 text-xs font-bold uppercase tracking-widest">Bruttó ár</span>
                <div className="text-5xl font-black text-emerald-800">
                  {Number(termek?.ar).toLocaleString()} <span className="text-2xl">Ft</span>
                </div>
              </div>

              {/* Kosár gomb feltételes megjelenítése (mint a HomepageTable-ben) */}
              {isLoggedIn ? (
                <Button 
                  onClick={(e) => {
                    e.preventDefault();
                    // A useTetelPost hook által biztosított függvényt hívjuk, 
                    // csak a termek_id-t adjuk át, ahogy a HomepageTable-ben is.
                    createTetel({ termek_id: termekId });
                  }}
                  disabled={isPending}
                  className="w-full h-16 bg-emerald-600 hover:bg-emerald-700 text-white text-xl font-bold rounded-2xl shadow-xl shadow-emerald-200 transition-all active:scale-95 flex gap-3 justify-center items-center"
                >
                  <ShoppingCart className="w-6 h-6" />
                  {isPending ? "Hozzáadás..." : "Kosárba teszem"}
                </Button>
              ) : (
                <div className="h-16 flex items-center justify-center border-2 border-dashed border-slate-300 bg-slate-50 rounded-2xl">
                  <p className="text-slate-500 font-medium">Jelentkezz be a vásárláshoz</p>
                </div>
              )}
            </div>

            <div className="space-y-6 pt-4">
              <h2 className="text-2xl font-bold text-emerald-950 flex items-center gap-2">
                <MessageSquare className="w-6 h-6 text-emerald-600" />
                Vásárlói vélemények
              </h2>

              {user ? (
                <div className="bg-emerald-50/50 p-6 rounded-2xl border border-emerald-100 space-y-4">
                  <h3 className="font-bold text-emerald-900 text-sm uppercase">Írj véleményt!</h3>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map((csillag) => (
                      <Star 
                        key={csillag}
                        className={`w-6 h-6 cursor-pointer transition-colors ${ujPontszam >= csillag ? 'fill-yellow-400 text-yellow-400' : 'text-slate-300'}`}
                        onClick={() => setUjPontszam(csillag)}
                      />
                    ))}
                  </div>
                  <textarea 
                    className="w-full p-4 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 outline-none min-h-[100px] text-sm bg-white"
                    placeholder="Oszd meg a tapasztalataidat..."
                    value={ujVelemeny}
                    onChange={(e) => setUjVelemeny(e.target.value)}
                  />
                  <Button 
                    onClick={handleErtekelesBekuldes}
                    disabled={createErtekelesMutation.isPending || !ujVelemeny.trim()}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white gap-2"
                  >
                    <Send className="w-4 h-4" />
                    {createErtekelesMutation.isPending ? "Küldés..." : "Vélemény beküldése"}
                  </Button>
                </div>
              ) : (
                <div className="bg-slate-100 p-6 rounded-2xl text-center text-sm text-slate-500 border border-dashed border-slate-300">
                  Vélemény írásához jelentkezz be!
                </div>
              )}

              {ertekelesLoading ? (
                <p className="text-slate-400 animate-pulse">Vélemények betöltése...</p>
              ) : ertekelesek && ertekelesek.length > 0 ? (
                <div className="grid gap-4">
                  {ertekelesek.map((e) => (
                    <div key={e.ertekeles_id} className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm transition-hover hover:shadow-md">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <span className="font-bold text-emerald-900 block">{e.Iro?.name || "Vendég"}</span>
                          <div className="flex gap-1 mt-1">
                            {[...Array(5)].map((_, i) => (
                              <Star key={i} className={`w-3 h-3 ${i < e.pontszam ? 'fill-yellow-400 text-yellow-400' : 'text-slate-200'}`} />
                            ))}
                          </div>
                        </div>
                        <span className="text-[10px] text-slate-400 font-medium">
                          {new Date(e.datum).toLocaleDateString('hu-HU')}
                        </span>
                      </div>

                      <p className="text-slate-600 italic leading-relaxed">
                        "{e.velemeny}" 
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="bg-white/50 border-2 border-dashed border-slate-200 rounded-3xl p-10 text-center text-slate-400">
                  <p>Erről a termékről még nem írtak véleményt.</p>
                  <p className="text-sm">Legyél te az első!</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}