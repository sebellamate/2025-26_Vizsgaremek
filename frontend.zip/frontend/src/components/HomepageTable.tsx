"use client"

import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Badge } from "@/components/ui/badge" // Ha van ilyen komponensed, ha nincs, sima div-vel is jó
import { useTermekekByKategoria } from "./hooks/useTermekekByKategoria"; 
import axios from "axios";
import { useMutation, useQueryClient } from "@tanstack/react-query";

type HomepageTableProps = {
  userId: number | null;
  kategoriaId: number | null;
}

type Tetel = {
  user_id: number;
  termek_id: number;
}

const postTetel = (data: Tetel) => {
  return axios.post("http://localhost:5000/api/kosartetelek", data, {
    withCredentials: true,
  });
};

export function HomepageTable({ userId, kategoriaId }: HomepageTableProps) {
  const { data: termekek, isLoading } = useTermekekByKategoria(kategoriaId);
  
  const isLoggedIn = !!userId;
  const queryClient = useQueryClient();

  const { mutate: posttetel, isPending } = useMutation({
    mutationFn: (data: Tetel) => postTetel(data),
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["kosar_tetelek", userId],
      });
    }
  });

  if (isLoading) return <div className="p-8 text-center">Betöltés...</div>;

  const termekLista = Array.isArray(termekek) ? termekek : termekek?.data || [];

  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-8 text-center text-emerald-900">
        {kategoriaId ? "Kategória ajánlatai" : "Kiemelt termékek"}
      </h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {termekLista.map((t: any) => {
          // Árkalkuláció: ha van akció, kiszámoljuk a csökkentett árat
          const vanAkcio = t.akcio > 0;
          const akciosAr = vanAkcio 
            ? Math.round(t.ar * (1 - t.akcio / 100)) 
            : t.ar;

          return (
            <Card key={t.termek_id} className="hover:shadow-lg transition-all border-emerald-100 overflow-hidden relative">
              {/* Akció jelvény a kép sarkában */}
              {vanAkcio && (
                <div className="absolute top-2 right-2 z-10">
                  <Badge className="bg-red-600 hover:bg-red-600 text-white font-bold">
                    -{t.akcio}%
                  </Badge>
                </div>
              )}

              <CardHeader className="p-0">
                <img
                  src={`/kepek/${t.kep_url}`}
                  className="h-48 w-full object-cover"
                  alt={t.nev}
                />
              </CardHeader>
              
              <CardContent className="p-4">
                <CardTitle className="text-lg font-semibold mb-2">{t.nev}</CardTitle>
                <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
                  {t.leiras}
                </p>
                
                {/* Ár szekció */}
                <div className="mb-4 h-12 flex flex-col justify-end">
                  {vanAkcio ? (
                    <>
                      <span className="text-sm text-red-500 line-through decoration-1">
                        {Number(t.ar).toLocaleString("hu-HU")} Ft
                      </span>
                      <span className="font-bold text-emerald-700 text-xl">
                        {akciosAr.toLocaleString("hu-HU")} Ft
                      </span>
                    </>
                  ) : (
                    <span className="font-bold text-emerald-700 text-xl">
                      {Number(t.ar).toLocaleString("hu-HU")} Ft
                    </span>
                  )}
                </div>
                
                {isLoggedIn && (
                  <Button
                    className="w-full bg-emerald-600 hover:bg-emerald-700 transition-colors"
                    onClick={() =>
                      posttetel({
                        user_id: userId!,  
                        termek_id: t.termek_id
                      })
                    }
                    disabled={isPending}
                  >
                    {isPending ? "Hozzáadás..." : "Kosárba"}
                  </Button>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {termekLista.length === 0 && (
        <p className="text-center text-muted-foreground mt-10 italic">
          Nincs megjeleníthető termék ebben a kategóriában.
        </p>
      )}
    </div>
  );
}