import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { useTermekek } from "./hooks/useTermekek";
import axios from "axios";
import { useMutation, useQueryClient } from "@tanstack/react-query";


type HomepageTableProps = {
  userId: number | null
}
type Tetel = {
  kosar_id: number
  termek_id: number
}

const postTetel = (data: Tetel) => {
  return axios.post("http://localhost:5000/api/kosartetelek", data, {
    withCredentials: true,
  });
};


export function HomepageTable({ userId }: HomepageTableProps) {
  const { data: termekek } = useTermekek()
  const isLoggedIn = !!userId
  
const queryClient = useQueryClient()

  // --- MUTATION ---
  const { mutate: posttetel, isPending } = useMutation({
    mutationFn: (data: Tetel) => postTetel(data),

    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["kosar_tetelek", userId],
      });
    }
  });



  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-8 text-center">Kiemelt termékek</h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {termekek?.data.map((t) => (
          <Card key={t.termek_id} className="hover:shadow-lg transition-all">
            <CardHeader>
              <img
                src={`/kepek/${t.kep_url}`}
                className="h-48 w-full object-cover rounded-lg mb-2"
                alt={t.nev}
              />
              <CardTitle className="text-lg font-semibold">{t.nev}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
                {t.leiras}
              </p>
              {t.ar && (
                <p className="font-bold text-primary mb-3">
                  {t.ar.toLocaleString("hu-HU")} Ft
                </p>
              )}
              {isLoggedIn && (
                <Button
                  className="w-full"
                  onClick={() =>
                    posttetel({
                      kosar_id: userId!,  
                      termek_id: t.termek_id
                    })
                  }
                  disabled={isPending}
                >
                  {isPending ? "Hozzáadás..." : "Kosárba"}
                </Button>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}


