"use client"

import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
// FIGYELEM: Itt az új hookot importáljuk!
import { useTermekekByKategoria } from "./hooks/useTermekekByKategoria"; 
import axios from "axios";
import { useMutation, useQueryClient } from "@tanstack/react-query";

type HomepageTableProps = {
  userId: number | null;
  kategoriaId: number | null;
}

type Tetel = {
  kosar_id: number;
  termek_id: number;
}

const postTetel = (data: Tetel) => {
  return axios.post("http://localhost:5000/api/kosartetelek", data, {
    withCredentials: true,
  });
};

export function HomepageTable({ userId, kategoriaId }: HomepageTableProps) {
  // ITT HASZNÁLJUK AZ ÚJ HOOKOT:
  const { data: termekek, isLoading } = useTermekekByKategoria(kategoriaId);
  
  const isLoggedIn = !!userId;
  const queryClient = useQueryClient();

  const { mutate: posttetel, isPending } = useMutation({
    mutationFn: (data: Tetel) => postTetel(data),
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["kosar_tetelek", userId],
      });
    }
  });

  if (isLoading) return <div className="p-8 text-center">Betöltés...</div>;

  // Adatkezelés: Megnézzük, hogy a backend sima tömböt ad-e, vagy { data: [] } objektumot
  const termekLista = Array.isArray(termekek) ? termekek : termekek?.data || [];

  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-8 text-center text-emerald-900">
        {kategoriaId ? "Kategória ajánlatai" : "Kiemelt termékek"}
      </h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {termekLista.map((t: any) => (
          <Card key={t.termek_id} className="hover:shadow-lg transition-all border-emerald-100">
            <CardHeader>
              <img
                src={`/kepek/${t.kep_url}`}
                className="h-48 w-full object-cover rounded-lg mb-2"
                alt={t.nev}
              />
              <CardTitle className="text-lg font-semibold">{t.nev}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
                {t.leiras}
              </p>
              <p className="font-bold text-emerald-700 mb-3 text-lg">
                {Number(t.ar).toLocaleString("hu-HU")} Ft
              </p>
              
              {isLoggedIn && (
                <Button
                  className="w-full bg-emerald-600 hover:bg-emerald-700"
                  onClick={() =>
                    posttetel({
                      kosar_id: userId!,  
                      termek_id: t.termek_id
                    })
                  }
                  disabled={isPending}
                >
                  {isPending ? "Hozzáadás..." : "Kosárba"}
                </Button>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {termekLista.length === 0 && (
        <p className="text-center text-muted-foreground mt-10 italic">
          Nincs megjeleníthető termék.
        </p>
      )}
    </div>
  );
}