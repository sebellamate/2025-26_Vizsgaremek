"use client"

import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
} from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useTermekekByKategoria } from "./hooks/useTermekekByKategoria"; 
import axios from "axios";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { ShoppingCart, Eye } from "lucide-react";

type HomepageTableProps = {
  userId: number | null;
  kategoriaId: number | null;
}

type Tetel = {
  user_id: number;
  termek_id: number;
}

const postTetel = (data: Tetel) => {
  return axios.post("http://localhost:5000/api/kosartetelek", data, {
    withCredentials: true,
  });
};

export function HomepageTable({ userId, kategoriaId }: HomepageTableProps) {
  const { data: termekek, isLoading } = useTermekekByKategoria(kategoriaId);
  const isLoggedIn = !!userId;
  const queryClient = useQueryClient();

  const { mutate: posttetel, isPending } = useMutation({
    mutationFn: (data: Tetel) => postTetel(data),
    onSuccess: () => {
      alert("Termék sikeresen a kosárba került!");
      queryClient.invalidateQueries({
        queryKey: ["kosar_tetelek", userId],
      });
    },
    onError: (error: any) => {
      if (error.response && (error.response.status === 400 || error.response.status === 500)) {
        alert("Ez a termék már szerepel a kosaradban!");
      } else {
        alert("Hiba történt a kosárba tétel során.");
      }
    }
  });

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-700" />
        <p className="text-emerald-800 font-medium animate-pulse">Termékek válogatása...</p>
      </div>
    );
  }

  const termekLista = Array.isArray(termekek) ? termekek : termekek?.data || [];

  return (
    <div className="p-8 bg-slate-50/30 min-h-screen">
      <h1 className="text-4xl font-black mb-10 text-center text-emerald-900 tracking-tight">
        {kategoriaId ? "Kategória ajánlatai" : "Kiemelt termékek"}
      </h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {termekLista.map((t: any) => {
          const vanAkcio = t.akcio > 0;
          const akciosAr = vanAkcio 
            ? Math.round(t.ar * (1 - t.akcio / 100)) 
            : t.ar;

          return (
            <Card key={t.termek_id} className="group hover:shadow-2xl transition-all duration-500 border-emerald-100/50 overflow-hidden bg-white flex flex-col relative">
              
              {/* Akció jelvény */}
              {vanAkcio && (
                <div className="absolute top-3 left-3 z-20">
                  <Badge className="bg-red-500 hover:bg-red-500 text-white font-bold shadow-lg border-none px-2 py-1">
                    -{t.akcio}%
                  </Badge>
                </div>
              )}

              {/* Kattintható felső rész */}
              <Link 
                to="/products/$id" 
                params={{ id: t.termek_id.toString() }}
                className="cursor-pointer flex-1 group"
              >
                <div className="relative overflow-hidden h-56">
                  <img
                    src={`/kepek/${t.kep_url}`}
                    className="h-full w-full object-cover transform group-hover:scale-110 transition-transform duration-700 ease-in-out"
                    alt={t.nev}
                  />
                  {/* Overlay effekt hoverkor */}
                  <div className="absolute inset-0 bg-emerald-900/0 group-hover:bg-emerald-900/10 transition-colors duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100">
                     <div className="bg-white/90 p-2 rounded-full shadow-xl">
                        <Eye className="w-6 h-6 text-emerald-700" />
                     </div>
                  </div>
                </div>

                <CardContent className="p-5">
                  <h3 className="text-lg font-bold text-emerald-950 mb-2 group-hover:text-emerald-700 transition-colors line-clamp-1">
                    {t.nev}
                  </h3>
                  <p className="text-sm text-slate-500 line-clamp-2 mb-4 h-10 leading-relaxed">
                    {t.leiras}
                  </p>
                  
                  <div className="flex flex-col justify-end h-14">
                    {vanAkcio ? (
                      <div>
                        <span className="text-xs text-slate-400 line-through block">
                          {Number(t.ar).toLocaleString("hu-HU")} Ft
                        </span>
                        <span className="font-black text-emerald-700 text-2xl">
                          {akciosAr.toLocaleString("hu-HU")} Ft
                        </span>
                      </div>
                    ) : (
                      <span className="font-black text-emerald-700 text-2xl">
                        {Number(t.ar).toLocaleString("hu-HU")} Ft
                      </span>
                    )}
                  </div>
                </CardContent>
              </Link>

              {/* Alsó gomb rész - Külön tartva a Link-től */}
              <div className="p-5 pt-0 mt-auto">
                {isLoggedIn ? (
                  <Button
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl h-12 shadow-md shadow-emerald-200/50 transform active:scale-95 transition-all flex gap-2 items-center justify-center"
                    onClick={(e) => {
                      e.preventDefault(); 
                      posttetel({
                        user_id: userId!,  
                        termek_id: t.termek_id
                      })
                    }}
                    disabled={isPending}
                  >
                    <ShoppingCart className="w-4 h-4" />
                    {isPending ? "Hozzáadás..." : "Kosárba teszem"}
                  </Button>
                ) : (
                  <div className="h-12 flex items-center justify-center border border-dashed border-slate-200 rounded-xl">
                    <p className="text-xs text-slate-400 italic">Jelentkezz be a vásárláshoz</p>
                  </div>
                )}
              </div>
            </Card>
          );
        })}
      </div>

      {termekLista.length === 0 && (
        <div className="flex flex-col items-center justify-center py-20 text-slate-400">
           <ShoppingCart className="w-16 h-16 mb-4 opacity-20" />
           <p className="text-lg italic">Nincs megjeleníthető termék ebben a kategóriában.</p>
        </div>
      )}
    </div>
  );
}