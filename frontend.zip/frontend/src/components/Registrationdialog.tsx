import { useForm } from "react-hook-form"
import z from "zod"
import { zodResolver } from "@hookform/resolvers/zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import axios from "axios"
import { useMutation, useQueryClient } from "@tanstack/react-query"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useState } from "react"

const formSchema = z.object({
  username: z.string().nonempty({ message: "Érvényes email címet adj meg!" }),
  email: z.string().nonempty({ message: "A mező kitöltése kötelező!" }),
  password: z.string().min(4, {message: "legalabb 4 tag"}).nonempty({ message: "A mező kitöltése kötelező!" }),

})

type FormSchema = z.infer<typeof formSchema>

const postUsers = async (user: FormSchema) => {
  const response = await axios.post("http://localhost:5000/api/users", user)
  return response.data
}

export function RegistrationDialog() {
  const [open, setOpen] = useState(false)
  const queryClient = useQueryClient()

  const form = useForm<FormSchema>({
    mode: "onChange",
    resolver: zodResolver(formSchema),
    defaultValues: {
      username: "",
      email: "",
      password: "",
    },
  })

  const { mutate: registration, isPending } = useMutation({
    mutationFn: (user: FormSchema) => postUsers(user),
    onSuccess() {
      queryClient.invalidateQueries({ queryKey: ["users"] })
      setOpen(false)
      form.reset()
    },
  })

  function onSubmit(values: FormSchema) {
    registration(values)
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>Regisztráció</Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Regisztrálás</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="username"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Név</FormLabel>
                  <FormControl>
                    <Input placeholder="Add meg a felhasználó nevét" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input type="email" placeholder="Add meg az email címet" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Jelszó</FormLabel>
                  <FormControl>
                    <Input type="password" placeholder="Add meg a jelszót" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="flex gap-2 justify-end">
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                Mégse
              </Button>
              <Button type="submit" disabled={!form.formState.isValid || isPending}>
                {isPending ? "Regisztrálás..." : "Regisztrálás"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}
