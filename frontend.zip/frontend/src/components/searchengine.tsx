import { useState } from "react";
import { Button } from "./ui/button";
import { useNavigate } from "@tanstack/react-router";
import axios from "axios";

type SearchResult = {
  termek_id: number;
  nev: string;
  leiras: string;
  ar: string;
  kep_url: string;
  kategoria_id: number;
};

const SearchEngine = () => {
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSearch = async () => {
    if (!query) return;

    setLoading(true);
    try {
      const response = await axios.get<SearchResult[]>(
        `http://localhost:5000/api/termekek/kerestermek/${query}`
      );

      const ids = response.data
        .map((item) => item.termek_id)
        .join(",");

      navigate({
        to: "/search/$id",
        params: {
          id: ids,
        },
      });

    } catch (error) {
      console.error("Keresési hiba:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <input
        type="text"
        placeholder="Keresés..."
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />

      <Button onClick={handleSearch}>🔍</Button>

      {loading && <p>Betöltés...</p>}
    </div>
  );
};

export default SearchEngine;

