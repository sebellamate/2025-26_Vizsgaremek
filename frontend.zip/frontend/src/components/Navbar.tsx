"use client"

import {
  NavigationMenu,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
} from "@/components/ui/navigation-menu"
import { Link } from "@tanstack/react-router"
import { Button } from "./ui/button"
import { RegistrationDialog } from "./Registrationdialog"
import { LoginDialog } from "./Logindialog"
import { Input } from "./ui/input"

export function Navbar() {
  return (
    <header className="border-b bg-background">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        
        {/* Bal oldal: site név + kereső */}
        <div className="flex items-center gap-6">

          {/* Oldal neve */}
          <Link to="/" className="text-2xl font-bold">
            webshop
          </Link>

          {/* Kereső sáv */}
          <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-full shadow-md">
            <Input
              type="text"
              placeholder="Keresés…"
              className="border-none focus-visible:ring-0 shadow-none"
            />
            <Button size="sm" className="rounded-full">
              🔍
            </Button>
          </div>
        </div>

        {/* Jobb oldal: NavigationMenu */}
        <NavigationMenu>
          <NavigationMenuList className="flex items-center gap-4">

            <NavigationMenuItem>
              <NavigationMenuLink>
                <RegistrationDialog />
              </NavigationMenuLink>
            </NavigationMenuItem>

            <NavigationMenuItem>
              <NavigationMenuLink>
                <LoginDialog />
              </NavigationMenuLink>
            </NavigationMenuItem>

          </NavigationMenuList>
        </NavigationMenu>
      </div>
    </header>
  )
}
