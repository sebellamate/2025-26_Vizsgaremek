"use client"

import {
  NavigationMenu,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
} from "@/components/ui/navigation-menu"
import { Link } from "@tanstack/react-router"
import { RegistrationDialog } from "./Registrationdialog"
import { LoginDialog } from "./Logindialog"
import SearchEngine from "./searchengine"

export function Navbar() {
  return (
    <header className="border-b bg-background">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        
        {/* Bal oldal: site név + kereső */}
        <div className="flex items-center gap-6">

          {/* Oldal neve */}
          <Link to="/" className="text-2xl font-bold">
            webshop
          </Link>

          {/* Kereső sáv */}
          <div>
            <SearchEngine />
          </div>
        </div>

        {/* Jobb oldal: NavigationMenu */}
        <NavigationMenu>
          <NavigationMenuList className="flex items-center gap-4">

            <NavigationMenuItem>
              <NavigationMenuLink>
                <RegistrationDialog />
              </NavigationMenuLink>
            </NavigationMenuItem>

            <NavigationMenuItem>
              <NavigationMenuLink>
                <LoginDialog />
              </NavigationMenuLink>
            </NavigationMenuItem>

          </NavigationMenuList>
        </NavigationMenu>
      </div>
    </header>
  )
}
