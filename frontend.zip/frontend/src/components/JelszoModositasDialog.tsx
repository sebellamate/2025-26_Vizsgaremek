import { useForm } from "react-hook-form";
import z from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useState } from "react";
import { KeyRound, Save, Loader2, AlertCircle, CheckCircle2, ChevronLeft, Send, Mail } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import axios from "axios";

const changePasswordSchema = z.object({
  currentPassword: z.string().nonempty({ message: "A jelenlegi jelszó kötelező!" }),
  newPassword: z.string()
    .min(8, { message: "Legalább 8 karakter!" })
    .regex(/[A-Z]/, { message: "Kell egy nagybetű!" })
    .regex(/[a-z]/, { message: "Kell egy kisbetű!" })
    .regex(/[0-9]/, { message: "Kell egy szám!" }),
  confirmPassword: z.string().nonempty({ message: "A megerősítés kötelező!" }),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "Nem egyeznek a jelszavak!",
  path: ["confirmPassword"],
});

const forgotPasswordSchema = z.object({
  email: z.string().email({ message: "Érvénytelen e-mail cím!" }),
});

export function JelszoModositasDialog() {
  const [open, setOpen] = useState(false);
  const [view, setView] = useState<"change" | "forgot">("change");
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const changeForm = useForm<z.infer<typeof changePasswordSchema>>({
    resolver: zodResolver(changePasswordSchema),
    defaultValues: { currentPassword: "", newPassword: "", confirmPassword: "" },
  });

  const forgotForm = useForm<z.infer<typeof forgotPasswordSchema>>({
    resolver: zodResolver(forgotPasswordSchema),
    defaultValues: { email: "" },
  });

  const resetStates = () => {
    changeForm.reset();
    forgotForm.reset();
    setSuccessMessage(null);
    setView("change");
  };

  const changePasswordMutation = useMutation({
    mutationFn: async (values: z.infer<typeof changePasswordSchema>) => {
      return axios.put("http://localhost:5000/api/auth/change-password", values, { withCredentials: true });
    },
    onSuccess: () => {
      setSuccessMessage("Jelszó sikeresen módosítva!");
      setTimeout(() => {
        setOpen(false);
        resetStates();
      }, 2000);
    },
    onError: (error: any) => {
      changeForm.setError("root", { message: error.response?.data?.message || "Hiba történt!" });
    }
  });

  const forgotPasswordMutation = useMutation({
    mutationFn: async (values: z.infer<typeof forgotPasswordSchema>) => {
      return axios.post("http://localhost:5000/api/auth/forgot-password", values);
    },
    onSuccess: () => {
      setSuccessMessage("Az útmutatót elküldtük az e-mail címedre!");
      forgotForm.reset();
    },
    onError: (error: any) => {
      forgotForm.setError("root", { message: error.response?.data?.message || "Hiba történt!" });
    }
  });

  return (
    <Dialog open={open} onOpenChange={(val) => { setOpen(val); if(!val) resetStates(); }}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="border-emerald-200 text-emerald-700 hover:bg-emerald-600 hover:text-white gap-2 transition-colors font-semibold shadow-sm">
          <KeyRound className="w-4 h-4" /> Módosítás
        </Button>
      </DialogTrigger>

      <DialogContent className="sm:max-w-[425px] border-emerald-100 shadow-2xl p-0 overflow-hidden font-sans rounded-xl">
        <DialogHeader className="p-6 bg-emerald-50/50 border-b border-emerald-100">
          <DialogTitle className="flex items-center gap-2 text-emerald-900 text-xl font-bold">
            {view === "change" ? <><KeyRound className="w-5 h-5 text-emerald-600" /> Jelszó módosítása</> : <><Mail className="w-5 h-5 text-emerald-600" /> Elfelejtett jelszó</>}
          </DialogTitle>
          <DialogDescription className="text-emerald-700/80 mt-1">
            {view === "change" ? "Add meg a jelenlegi és az új jelszavadat a frissítéshez." : "Add meg az e-mail címed, és küldünk egy linket."}
          </DialogDescription>
        </DialogHeader>

        <div className="p-6">
          {successMessage && (
            <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-lg flex items-center gap-2 mb-4 animate-in fade-in slide-in-from-top-1">
              <CheckCircle2 className="h-4 w-4 text-emerald-600 flex-shrink-0" />
              <p className="text-emerald-600 text-xs font-bold leading-tight">{successMessage}</p>
            </div>
          )}

          {view === "change" ? (
            <Form {...changeForm}>
              <form key="change-form" onSubmit={changeForm.handleSubmit((v) => changePasswordMutation.mutate(v))} className="space-y-4">
                {changeForm.formState.errors.root && (
                  <div className="bg-red-50 border border-red-200 p-3 rounded-lg flex items-center gap-2 text-red-600 text-xs font-bold">
                    <AlertCircle className="h-4 w-4 flex-shrink-0" /> {changeForm.formState.errors.root.message}
                  </div>
                )}
                
                <FormField control={changeForm.control} name="currentPassword" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-emerald-900">Jelenlegi jelszó</FormLabel>
                    <FormControl><Input type="password" {...field} className="border-emerald-100 focus-visible:ring-emerald-500 rounded-lg" /></FormControl>
                    <FormMessage className="text-[10px] font-medium italic" />
                  </FormItem>
                )} />

                <FormField control={changeForm.control} name="newPassword" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-emerald-900">Új jelszó</FormLabel>
                    <FormControl><Input type="password" {...field} className="border-emerald-100 focus-visible:ring-emerald-500 rounded-lg" /></FormControl>
                    <FormMessage className="text-[10px] font-medium italic" />
                  </FormItem>
                )} />

                <FormField control={changeForm.control} name="confirmPassword" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-emerald-900">Új jelszó megerősítése</FormLabel>
                    <FormControl><Input type="password" {...field} className="border-emerald-100 focus-visible:ring-emerald-500 rounded-lg" /></FormControl>
                    <FormMessage className="text-[10px] font-medium italic" />
                  </FormItem>
                )} />
                
                <button 
                  type="button" 
                  onClick={() => { setView("forgot"); setSuccessMessage(null); }} 
                  className="text-xs text-emerald-600 hover:text-emerald-700 hover:underline font-bold transition-colors"
                >
                  Elfelejtetted a jelszavad?
                </button>

                <DialogFooter className="pt-2">
                  <Button type="submit" disabled={changePasswordMutation.isPending} className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold h-11 rounded-lg shadow-md transition-all">
                    {changePasswordMutation.isPending ? <Loader2 className="animate-spin h-5 w-5" /> : <><Save className="w-4 h-4 mr-2" /> Jelszó mentése</>}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          ) : (
            <Form {...forgotForm}>
              <form key="forgot-form" onSubmit={forgotForm.handleSubmit((v) => forgotPasswordMutation.mutate(v))} className="space-y-4">
                {forgotForm.formState.errors.root && (
                  <div className="bg-red-50 border border-red-200 p-3 rounded-lg flex items-center gap-2 text-red-600 text-xs font-bold">
                    <AlertCircle className="h-4 w-4 flex-shrink-0" /> {forgotForm.formState.errors.root.message}
                  </div>
                )}
                
                <FormField control={forgotForm.control} name="email" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-emerald-900 font-semibold">E-mail cím</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="pelda@email.hu" 
                        {...field} 
                        className="border-emerald-100 focus-visible:ring-emerald-500 rounded-lg"
                        autoFocus // Automatikusan ide ugrik a kurzor váltáskor
                      />
                    </FormControl>
                    <FormMessage className="text-[10px] font-medium italic" />
                  </FormItem>
                )} />
                
                <Button 
                  variant="ghost" 
                  size="sm" 
                  type="button"
                  onClick={() => { setView("change"); setSuccessMessage(null); }} 
                  className="text-emerald-600 p-0 h-auto hover:bg-transparent font-bold hover:text-emerald-700 transition-colors"
                >
                  <ChevronLeft className="w-4 h-4 mr-1" /> Vissza a módosításhoz
                </Button>

                <DialogFooter className="pt-2">
                  <Button type="submit" disabled={forgotPasswordMutation.isPending} className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold h-11 rounded-lg shadow-md transition-all">
                    {forgotPasswordMutation.isPending ? <Loader2 className="animate-spin h-5 w-5" /> : <><Send className="w-4 h-4 mr-2" /> E-mail küldése</>}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}