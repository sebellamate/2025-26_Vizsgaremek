import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "./ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import { useRendelesPost } from "./hooks/useRendelesPost";
import { PackageCheck, Truck, Loader2 } from "lucide-react";

type RendelesDialogProps = {
  userId: number;
  vegosszeg: number;
  kosartetelek: any[];
  termekek: any[];
  onSuccess: () => void;
};

export function RendelesDialog({ userId, vegosszeg, kosartetelek, termekek, onSuccess }: RendelesDialogProps) {
  const [open, setOpen] = useState(false);
  const [cim, setCim] = useState("");
  const { createRendelesAsync, isPending } = useRendelesPost();

  const handleRendelesLeadasa = async () => {
    // 1. Alapvető validáció
    if (!cim.trim()) {
      alert("Kérjük, adja meg a szállítási címet!");
      return;
    }

    // 2. Adatok összefésülése (Backend formátumra hozás)
    const tetelek = kosartetelek.map((kt) => {
      const termekInfo = termekek.find((t) => t.termek_id === kt.termek_id);
      
      // Akciós ár újraszámolása, hogy a rendelés pillanatában érvényes ár kerüljön a DB-be
      const vanAkcio = termekInfo?.akcio > 0;
      const aktualisEgysegAr = vanAkcio 
        ? Math.round(termekInfo.ar * (1 - termekInfo.akcio / 100)) 
        : termekInfo.ar;

      return {
        termek_id: kt.termek_id,
        mennyiseg: kt.mennyiseg,
        egyseg_ar: aktualisEgysegAr,
      };
    });

    try {
      // 3. Backend tranzakció hívása
      await createRendelesAsync({
        user_id: userId,
        osszeg: vegosszeg,
        cim: cim,
        tetelek: tetelek,
      });

      // 4. Siker esetén
      alert("Sikeres rendelés! Köszönjük a vásárlást.");
      setOpen(false);
      onSuccess(); // Ez zárja be a szülő Kosár modalt is
    } catch (error: any) {
      // 5. Hiba esetén
      console.error("Rendelési hiba:", error);
      alert("Hiba történt a rendelés során: " + (error.response?.data?.message || "Szerver hiba"));
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button 
          className="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-6 px-8 rounded-xl shadow-lg transition-all flex gap-2 items-center"
        >
          <PackageCheck className="w-5 h-5" />
          Pénztár
        </Button>
      </DialogTrigger>

      <DialogContent className="sm:max-w-[425px] border-emerald-100">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-emerald-900 flex items-center gap-2">
            <Truck className="w-6 h-6 text-emerald-600" />
            Szállítási adatok
          </DialogTitle>
          <DialogDescription>
            Kérjük, adja meg a pontos címet a kiszállításhoz.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-6 py-4">
          <div className="space-y-2">
            <Label htmlFor="address" className="text-emerald-900 font-semibold">
              Szállítási cím
            </Label>
            <Input
              id="address"
              placeholder="Város, utca, házszám..."
              className="border-emerald-200 focus:ring-emerald-500"
              value={cim}
              onChange={(e) => setCim(e.target.value)}
              disabled={isPending}
            />
          </div>

          <div className="bg-emerald-50 p-4 rounded-lg border border-emerald-100 space-y-2">
            <div className="flex justify-between items-center text-sm text-emerald-700">
              <span>Rendelt tételek:</span>
              <span className="font-bold">{kosartetelek.length} típus</span>
            </div>
            <div className="flex justify-between items-center text-lg text-emerald-900 font-black border-t border-emerald-200 pt-2">
              <span>Fizetendő:</span>
              <span>{vegosszeg.toLocaleString()} Ft</span>
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2 sm:gap-0">
          <Button
            variant="outline"
            onClick={() => setOpen(false)}
            disabled={isPending}
            className="border-emerald-200 text-emerald-700"
          >
            Mégse
          </Button>
          <Button
            onClick={handleRendelesLeadasa}
            disabled={isPending || !cim.trim()}
            className="bg-emerald-700 hover:bg-emerald-800 text-white min-w-[140px]"
          >
            {isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Küldés...
              </>
            ) : (
              "Rendelés leadása"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}