import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "./ui/button";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { useAuthStatus } from "./hooks/useAuthStatus";
import { useState, useMemo } from "react";
import { useTermekekBy_ids } from "./hooks/useTermekekByid";
import { useItemsByid } from './hooks/useItemsByid';
import { useQueryClient, useMutation } from "@tanstack/react-query";
import axios from "axios";
import { 
  ShoppingCart, Trash2, Plus, Minus, CreditCard, 
  ShoppingBag, Loader2, MapPin, Phone, ArrowRight 
} from "lucide-react";
import { useCreateOrder } from "./hooks/useCreateOrder";

// Típusdefiníciók a modellek alapján
type KosarTetel = {
  id: number; 
  user_id: number;
  termek_id: number;
  mennyiseg: number;
};

type Termek = {
  termek_id: number;
  nev: string;
  leiras: string;
  ar: number;
  kep_url?: string;
  kategoria_id: number;
};

// API hívások a kosár műveletekhez
const PlusOne = ({id}: {id: number}) => axios.put(`http://localhost:5000/api/kosartetelek/pluszegy/${id}`);
const MinusOne = ({id}: {id: number}) => axios.put(`http://localhost:5000/api/kosartetelek/minuszegy/${id}`);
const deleteTetel = ({id}: {id:number}) => axios.delete(`http://localhost:5000/api/kosartetelek/torles/${id}`);

export function KosarDialog() {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState<'cart' | 'checkout'>('cart'); // Lépés követése
  const [szallitasiAdatok, setSzallitasiAdatok] = useState({ cim: "", telefon: "" });
  
  const queryClient = useQueryClient();
  const { data: user, isLoading: userLoading } = useAuthStatus();
  const { data: kosartetelek, isLoading: kosartetelekLoading } = useItemsByid(user?.userID);

  const termekIdk = useMemo(() => {
    if (!kosartetelek) return [];
    return kosartetelek.map((t: KosarTetel) => t.termek_id);
  }, [kosartetelek]);

  const { data: termekek, isLoading: termekLoading } = useTermekekBy_ids(termekIdk);
  const createOrderMutation = useCreateOrder();

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ['kosar_tetelek', user?.userID] });

  const { mutate: plusOne } = useMutation({ mutationFn: PlusOne, onSuccess: invalidate });
  const { mutate: minusOne } = useMutation({ mutationFn: MinusOne, onSuccess: invalidate });
  const { mutate: terminate } = useMutation({ mutationFn: deleteTetel, onSuccess: invalidate });

  const vegosszeg = useMemo(() => {
    if (!termekek || !kosartetelek) return 0;
    return termekek.reduce((acc: number, t: Termek) => {
      const tetel = kosartetelek.find((kt: KosarTetel) => kt.termek_id === t.termek_id);
      return acc + (Number(t.ar) * (tetel?.mennyiseg || 0));
    }, 0);
  }, [termekek, kosartetelek]);

  // RENDELÉS VÉGLEGESÍTÉSE ÉS KÜLDÉSE
  const handleFinalOrder = () => {
    if (!termekek || !kosartetelek || !szallitasiAdatok.cim || !szallitasiAdatok.telefon) {
        alert("Kérjük, töltsön ki minden adatot!");
        return;
    }

    const orderData = {
      osszeg: vegosszeg,
      szallitasi_cim: szallitasiAdatok.cim,
      telefonszam: szallitasiAdatok.telefon,
      tetelek: termekek.map((t: Termek) => {
        const kt = kosartetelek.find((item: KosarTetel) => item.termek_id === t.termek_id);
        return {
          termek_id: t.termek_id,
          mennyiseg: kt?.mennyiseg || 0,
          egyseg_ar: t.ar
        };
      })
    };

    createOrderMutation.mutate(orderData, {
      onSuccess: () => {
        setOpen(false);
        setStep('cart');
        queryClient.invalidateQueries({ queryKey: ['kosar_tetelek'] });
        alert("Sikeres rendelés!");
      }
    });
  };

  const isLoading = userLoading || kosartetelekLoading || termekLoading;
  const isEmpty = !termekek || termekek.length === 0;

  return (
    <Dialog open={open} onOpenChange={(val) => { setOpen(val); if(!val) setStep('cart'); }}>
      <DialogTrigger asChild>
        <Button className="bg-emerald-800 hover:bg-emerald-900 text-white rounded-full flex gap-2 items-center" disabled={isLoading}>
          <ShoppingCart className="w-4 h-4" />
          <span>Kosár</span>
          {!isEmpty && <span className="bg-emerald-500 text-[10px] px-1.5 py-0.5 rounded-full">{termekek.length}</span>}
        </Button>
      </DialogTrigger>

      <DialogContent className="max-w-2xl max-h-[85vh] flex flex-col p-0 border-emerald-100">
        <DialogHeader className="p-6 bg-emerald-50/50 border-b">
          <DialogTitle className="flex items-center gap-2 text-emerald-900">
            {step === 'cart' ? <ShoppingBag className="w-6 h-6" /> : <MapPin className="w-6 h-6" />}
            {step === 'cart' ? 'Az Ön Kosara' : 'Szállítási adatok megadása'}
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto p-6">
          {step === 'cart' ? (
            // KOSÁR NÉZET
            isEmpty ? (
              <p className="text-center py-10 text-gray-500">A kosarad üres.</p>
            ) : (
              <div className="space-y-4">
                {termekek.map((t: Termek) => {
                  const kosarTetel = kosartetelek?.find((kt: KosarTetel) => kt.termek_id === t.termek_id);
                  return (
                    <Card key={t.termek_id}>
                      <CardContent className="p-4 flex items-center justify-between">
                        <div>
                          <h4 className="font-bold">{t.nev}</h4>
                          <p className="text-emerald-700 font-bold">{t.ar.toLocaleString()} Ft</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button size="icon" variant="ghost" onClick={() => minusOne({id: kosarTetel!.id})} disabled={kosarTetel!.mennyiseg <= 1}><Minus className="w-4 h-4"/></Button>
                          <span>{kosarTetel?.mennyiseg}</span>
                          <Button size="icon" variant="ghost" onClick={() => plusOne({id: kosarTetel!.id})}><Plus className="w-4 h-4"/></Button>
                          <Button size="icon" variant="ghost" className="text-red-500" onClick={() => terminate({id: kosarTetel!.id})}><Trash2 className="w-4 h-4"/></Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )
          ) : (
            // ADATBEKÉRŐ NÉZET (CHECKOUT)
            <div className="space-y-6 py-4">
              <div className="space-y-2">
                <label className="text-sm font-bold flex items-center gap-2"><MapPin className="w-4 h-4" /> Szállítási cím</label>
                <input 
                    type="text" 
                    className="w-full p-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none" 
                    placeholder="Város, utca, házszám..."
                    value={szallitasiAdatok.cim}
                    onChange={(e) => setSzallitasiAdatok({...szallitasiAdatok, cim: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold flex items-center gap-2"><Phone className="w-4 h-4" /> Telefonszám</label>
                <input 
                    type="text" 
                    className="w-full p-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none" 
                    placeholder="+36..."
                    value={szallitasiAdatok.telefon}
                    onChange={(e) => setSzallitasiAdatok({...szallitasiAdatok, telefon: e.target.value})}
                />
              </div>
              <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-100">
                <p className="text-sm text-emerald-800">Összesen fizetendő: <strong>{vegosszeg.toLocaleString()} Ft</strong></p>
              </div>
            </div>
          )}
        </div>

        {!isEmpty && (
          <DialogFooter className="p-6 border-t bg-gray-50/50">
            {step === 'cart' ? (
              <Button className="w-full bg-emerald-600 hover:bg-emerald-700 py-6 text-lg rounded-2xl" onClick={() => setStep('checkout')}>
                Folytatás a rendeléshez <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            ) : (
              <div className="flex gap-3 w-full">
                <Button variant="outline" className="flex-1 py-6" onClick={() => setStep('cart')}>Vissza</Button>
                <Button 
                    className="flex-[2] bg-emerald-700 hover:bg-emerald-800 py-6 text-lg rounded-2xl" 
                    onClick={handleFinalOrder}
                    disabled={createOrderMutation.isPending}
                >
                  {createOrderMutation.isPending ? <Loader2 className="animate-spin" /> : <CreditCard className="mr-2" />}
                  Rendelés Leadása
                </Button>
              </div>
            )}
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  );
}