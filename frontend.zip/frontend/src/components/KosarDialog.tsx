import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "./ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { useAuthStatus } from "./hooks/useAuthStatus";
import { useState, useMemo } from "react";
import { useTermekekBy_ids } from "./hooks/useTermekekByid";
import { useItemsByid } from './hooks/useItemsByid';
import { useQueryClient } from "@tanstack/react-query";
import axios from "axios";
import { useMutation } from "@tanstack/react-query";

type KosarTetel = {
  id: number; 
  kosar_id: number;
  termek_id: number;
  mennyiseg: number;
};

type Termek = {
  termek_id: number;
  nev: string;
  leiras: string;
  ar: number;
  kep_url?: string;
  kategoria_id: number;
};

const PlusOne = ({id}: {id: number}) => {
  return axios.put(`http://localhost:5000/api/kosartetelek/pluszegy/${id}`)
}

const MinusOne = ({id}: {id: number}) => {
  return axios.put(`http://localhost:5000/api/kosartetelek/minuszegy/${id}`)
}

const deleteTetel = ({id}: {id:number}) => {
  return axios.delete(`http://localhost:5000/api/kosartetelek/torles/${id}`)
}



export function KosarDialog() {
  const [open, setOpen] = useState(false);

  const { data: user, isLoading: userLoading } = useAuthStatus();
  const { data: kosartetelek, isLoading: kosartetelekLoading } = useItemsByid(user?.userID);

  const sv = useMemo(() => {
    if (!kosartetelek) return [];
    return kosartetelek.map((t: KosarTetel) => t.termek_id);
  }, [kosartetelek]);

  const queryClient = useQueryClient();

  const {mutate: plusOne, isPending: plusOneLoading} = useMutation({
    mutationFn: ({id}: {id:number}) => PlusOne({id}),
    onSuccess: () => {
    queryClient.invalidateQueries({
      queryKey: ['kosar_tetelek', user?.userID],
    });
  },
  })

  const {mutate: minusOne, isPending: minusOneLoading} = useMutation({
    mutationFn: ({id}: {id:number}) => MinusOne({id}),
    onSuccess: () => {
    queryClient.invalidateQueries({
      queryKey: ['kosar_tetelek', user?.userID],
    });
  },
  })

  const {mutate: terminate} = useMutation({
    mutationFn: ({id}: {id:number}) => deleteTetel({id}),
    onSuccess: () => {
    queryClient.invalidateQueries({
      queryKey: ['kosar_tetelek', user?.userID],
    });
}})

  const { data: termekek, isLoading: termekLoading } = useTermekekBy_ids(sv);

  const isLoading = userLoading || kosartetelekLoading || termekLoading;
  const isEmpty = !termekek || termekek.length === 0;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button disabled={isLoading}>Kosár</Button>
      </DialogTrigger>

      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Kosarad 🛒</DialogTitle>
        </DialogHeader>

        <div className="p-6">
          {isLoading ? (
            <p>Betöltés...</p>
          ) : isEmpty ? (
            <p>A kosarad üres.</p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {termekek.map((t: Termek) => {
                const kosarTetel = kosartetelek?.find(
                  (kt: KosarTetel) => kt.termek_id === t.termek_id
                );

                return (
                  <Card key={t.termek_id} className="hover:shadow-lg transition-all">
                    <CardHeader>
                      <CardTitle className="text-lg font-semibold">
                        {t.nev}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
                        {t.leiras}
                      </p>
                      <p className="font-bold text-primary mb-3">
                        {t.ar} Ft
                      </p>
                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          onClick={() => {
                            if (!kosarTetel) return;
                          minusOne({id: kosarTetel.id});
                          }}
                          disabled={minusOneLoading}>-</Button>
                        <span>{kosarTetel?.mennyiseg ?? 0}</span>
                        <Button
                          size="sm"
                          onClick={() => {
                            if (!kosarTetel) return;
                          plusOne({id: kosarTetel.id});
                          }}
                          disabled={plusOneLoading}>+</Button>

                          <Button onClick={()=>{
                            terminate({id: kosarTetel.id})
                          }}>Törlés</Button>

                      </div>
                      
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
          <Button>Rendelés</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}


