import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "./ui/button";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { useAuthStatus } from "./hooks/useAuthStatus";
import { useState, useMemo } from "react";
import { useTermekekBy_ids } from "./hooks/useTermekekByid";
import { useItemsByid } from './hooks/useItemsByid';
import { useQueryClient, useMutation } from "@tanstack/react-query";
import axios from "axios";
import { ShoppingCart, Trash2, Plus, Minus, ShoppingBag } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { RendelesDialog } from "./RendelesDialog";

type KosarTetel = {
  id: number; 
  kosar_id: number;
  termek_id: number;
  mennyiseg: number;
};

type Termek = {
  termek_id: number;
  nev: string;
  leiras: string;
  ar: number;
  akcio: number;
  kep_url?: string;
  kategoria_id: number;
};

const PlusOne = ({id}: {id: number}) => axios.put(
  `http://localhost:5000/api/kosartetelek/pluszegy/${id}`, 
  {},
  { withCredentials: true }
);

const MinusOne = ({id}: {id: number}) => axios.put(
  `http://localhost:5000/api/kosartetelek/minuszegy/${id}`, 
  {},
  { withCredentials: true }
);

const deleteTetel = ({id}: {id:number}) => axios.delete(
  `http://localhost:5000/api/kosartetelek/torles/${id}`, 
  { withCredentials: true }
);

export function KosarDialog() {
  const [open, setOpen] = useState(false);
  const queryClient = useQueryClient();

  const { data: user, isLoading: userLoading } = useAuthStatus();
  const { data: kosartetelek, isLoading: kosartetelekLoading } = useItemsByid(user?.userID);

  const termekIdk = useMemo(() => {
    if (!kosartetelek) return [];
    return kosartetelek.map((t: KosarTetel) => t.termek_id);
  }, [kosartetelek]);

  const { data: termekek, isLoading: termekLoading } = useTermekekBy_ids(termekIdk);

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ['kosar_tetelek', user?.userID] });

  const { mutate: plusOne, isPending: plusOneLoading } = useMutation({ mutationFn: PlusOne, onSuccess: invalidate });
  const { mutate: minusOne, isPending: minusOneLoading } = useMutation({ mutationFn: MinusOne, onSuccess: invalidate });
  const { mutate: terminate } = useMutation({ mutationFn: deleteTetel, onSuccess: invalidate });

  // MODOSÍTOTT: Kosár összesítő számítása akcióval
  const vegosszeg = useMemo(() => {
    if (!termekek || !kosartetelek) return 0;
    return termekek.reduce((acc: number, t: Termek) => {
      const tetel = kosartetelek.find((kt: KosarTetel) => kt.termek_id === t.termek_id);
      const mennyiseg = tetel?.mennyiseg || 0;
      
      // Akciós ár kalkulálása termékenként
      const vanAkcio = t.akcio > 0;
      const aktualisAr = vanAkcio 
        ? Math.round(t.ar * (1 - t.akcio / 100)) 
        : t.ar;

      return acc + (aktualisAr * mennyiseg);
    }, 0);
  }, [termekek, kosartetelek]);

  const isLoading = userLoading || kosartetelekLoading || termekLoading;
  const isEmpty = !termekek || termekek.length === 0;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="bg-emerald-800 hover:bg-emerald-900 text-emerald-50 font-bold py-2 px-6 rounded-full shadow-lg shadow-emerald-900/30 transform transition-all duration-200 hover:scale-105 active:scale-95 flex gap-2 items-center border border-emerald-700/50" disabled={isLoading}>
          <ShoppingCart className="w-4 h-4" />
          <span>Kosár</span>
          {!isEmpty && <span className="bg-emerald-500 text-[10px] px-1.5 py-0.5 rounded-full ml-1">{termekek.length}</span>}
        </Button>
      </DialogTrigger>

      <DialogContent className="max-w-2xl max-h-[85vh] overflow-hidden flex flex-col p-0 border-emerald-100 shadow-2xl">
        <DialogHeader className="p-6 bg-emerald-50/50 border-b border-emerald-100">
          <DialogTitle className="flex items-center gap-2 text-emerald-900 text-xl">
            <ShoppingBag className="w-6 h-6 text-emerald-700" />
            Az Ön Kosara
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto p-6">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-20 gap-4">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-700" />
              <p className="text-emerald-800 font-medium">Frissítés...</p>
            </div>
          ) : isEmpty ? (
            <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
              <div className="bg-gray-50 p-6 rounded-full">
                <ShoppingCart className="w-12 h-12 text-gray-300" />
              </div>
              <p className="text-gray-500 font-medium italic">A kosarad jelenleg üres.</p>
              <Button variant="outline" onClick={() => setOpen(false)} className="text-emerald-700 border-emerald-200">
                Vásárlás megkezdése
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {termekek.map((t: Termek) => {
                const kosarTetel = kosartetelek?.find((kt: KosarTetel) => kt.termek_id === t.termek_id);
                if (!kosarTetel) return null;

                // Akciós számítások
                const vanAkcio = t.akcio > 0;
                const akciosEgysegAr = vanAkcio 
                  ? Math.round(t.ar * (1 - t.akcio / 100)) 
                  : t.ar;

                return (
                  <Card key={t.termek_id} className="border-emerald-50 shadow-sm hover:shadow-md transition-shadow relative">
                    <CardContent className="p-4 flex items-center justify-between gap-4">
                      {/* Termék infó */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                            <h4 className="font-bold text-emerald-900 truncate">{t.nev}</h4>
                            {vanAkcio && (
                                <Badge className="bg-red-500 hover:bg-red-500 text-[10px] h-4 px-1">
                                    -{t.akcio}%
                                </Badge>
                            )}
                        </div>
                        <p className="text-xs text-gray-500 line-clamp-1 mb-1">{t.leiras}</p>
                        
                        {/* MODOSÍTOTT: Ár megjelenítése */}
                        <div className="flex items-center gap-2">
                            {vanAkcio ? (
                                <>
                                    <span className="text-emerald-700 font-bold text-lg">
                                        {akciosEgysegAr.toLocaleString()} Ft
                                    </span>
                                    <span className="text-xs text-gray-400 line-through">
                                        {t.ar.toLocaleString()} Ft
                                    </span>
                                </>
                            ) : (
                                <span className="text-emerald-700 font-bold text-lg">
                                    {t.ar.toLocaleString()} Ft
                                </span>
                            )}
                        </div>
                      </div>

                      {/* Mennyiség szabályzó */}
                      <div className="flex items-center gap-3 bg-emerald-50/50 p-1.5 rounded-xl border border-emerald-100">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-emerald-700 hover:bg-emerald-100 rounded-lg"
                          onClick={() => minusOne({id: kosarTetel.id})}
                          disabled={minusOneLoading || kosarTetel.mennyiseg <= 1}
                        >
                          <Minus className="w-4 h-4" />
                        </Button>
                        <span className="font-bold text-emerald-900 min-w-[20px] text-center">
                          {kosarTetel.mennyiseg}
                        </span>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-emerald-700 hover:bg-emerald-100 rounded-lg"
                          onClick={() => plusOne({id: kosarTetel.id})}
                          disabled={plusOneLoading}
                        >
                          <Plus className="w-4 h-4" />
                        </Button>
                      </div>

                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="text-red-400 hover:text-red-600 hover:bg-red-50"
                        onClick={() => terminate({id: kosarTetel.id})}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </div>

        {!isEmpty && !isLoading && (
          <DialogFooter className="p-6 bg-emerald-50/30 border-t border-emerald-100 flex-col sm:flex-row items-center gap-4">
            <div className="flex flex-col items-center sm:items-start flex-1">
              <span className="text-xs text-emerald-600 font-bold uppercase tracking-wider">Fizetendő összesen</span>
              {/* Itt már az akciós vegosszeg jelenik meg */}
              <span className="text-2xl font-black text-emerald-900">{vegosszeg.toLocaleString()} Ft</span>
            </div>
            <RendelesDialog 
    // Itt volt a hiba: a user.userID-t (nagybetűs) adjuk át a userId (kisbetűs i) propnak
    userId={user?.userID} 
    vegosszeg={vegosszeg}
    kosartetelek={kosartetelek}
    termekek={termekek}
    onSuccess={() => setOpen(false)} 
/>
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  );
}