import { useMutation, useQueryClient } from '@tanstack/react-query'
import axios from 'axios'

// 1. Csak a termek_id kell, a backend a tokenből intézi a többit!
type Tetel = {
  termek_id: number
}

const postTetel = async (tetel: Tetel) => {
  const response = await axios.post(
    "http://localhost:5000/api/kosartetelek", 
    tetel,
    { withCredentials: true } // 2. Itt a varázsszó!
  )
  return response.data
}

export function useTetelPost() {
  const queryClient = useQueryClient()

  const mutation = useMutation({
    mutationFn: (tetel: Tetel) => postTetel(tetel),
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ['kosar_tetelek'], 
      });
      alert("Termék sikeresen a kosárba került!");
    },
    onError: (error: any) => {
      if (error.response && (error.response.status === 400 || error.response.status === 500)) {
        alert("Ez a termék már szerepel a kosaradban!");
      } else {
        alert("Hiba történt a kosárba tétel során.");
      }
    }
  })

  return {
    createTetel: mutation.mutate,
    createTetelAsync: mutation.mutateAsync,
    ...mutation,
  }
}