import { useMutation, useQueryClient } from '@tanstack/react-query'
import axios from 'axios'

type RendelesAdatok = {
  user_id: number;
  osszeg: number;
  cim: string;
  kupon_id?: string | null; // Új mező a kuponnak
  tetelek: {
    termek_id: number;
    mennyiseg: number;
    egyseg_ar: number;
  }[];
}

const postRendeles = async (rendeles: RendelesAdatok) => {
  // Tisztítjuk az adatot: ha a kupon_id "none" vagy üres, null-ként küldjük
  const adatokToSend = {
    ...rendeles,
    kupon_id: (rendeles.kupon_id === "none" || !rendeles.kupon_id) ? null : rendeles.kupon_id
  };

  const response = await axios.post("http://localhost:5000/api/rendeles", adatokToSend, {
    withCredentials: true 
  })
  return response.data
}

export function useRendelesPost() {
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: postRendeles,
    onSuccess: (variables) => {
      queryClient.invalidateQueries({ queryKey: ['kosar_tetelek', variables.user_id] });
      queryClient.invalidateQueries({ queryKey: ['kuponok', variables.user_id] });
      queryClient.invalidateQueries({ queryKey: ['rendelesek', variables.user_id] });
      queryClient.invalidateQueries({ queryKey: ['termekek'] });
    },
    onError: (error) => {
      console.error("Rendelési hiba:", error);
    }
  });

  return {
    // A mutation.mutate és mutation.mutateAsync átnevezése a kényelem kedvéért
    createRendeles: mutation.mutate,
    createRendelesAsync: mutation.mutateAsync,
    
    // Minden más (isPending, isError, error, status, stb.) 
    // automatikusan belekerül a spread operátorral
    ...mutation, 
  };
}