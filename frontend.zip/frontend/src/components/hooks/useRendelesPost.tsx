import { useMutation, useQueryClient } from '@tanstack/react-query'
import axios from 'axios'

// A backend-ed ilyen struktúrát vár a Service-ben:
type RendelesAdatok = {
  user_id: number;
  osszeg: number;
  cim: string;
  tetelek: {
    termek_id: number;
    mennyiseg: number;
    egyseg_ar: number;
  }[];
}

const postRendeles = async (rendeles: RendelesAdatok) => {
  const response = await axios.post("http://localhost:5000/api/rendeles", rendeles, {
    withCredentials: true 
  })
  return response.data
}

export function useRendelesPost() {
  const queryClient = useQueryClient()

  const mutation = useMutation({
    mutationFn: postRendeles,
    onSuccess: (data, variables) => {
      // Ha sikeres a rendelés, érvénytelenítjük a kosarat, 
      // mert a backend-edben a tranzakció üríti a kosár táblát!
      queryClient.invalidateQueries({ queryKey: ['kosar_tetelek', variables.user_id] })
      
      // Esetleg a termékek listáját is frissíthetjük, ha van készletkezelés
      queryClient.invalidateQueries({ queryKey: ['termekek'] })
      
      console.log("Rendelés sikeres:", data)
    },
    onError: (error) => {
      console.error("Rendelési hiba:", error)
    }
  })

  return {
    createRendeles: mutation.mutate,
    createRendelesAsync: mutation.mutateAsync,
    ...mutation,
  }
}