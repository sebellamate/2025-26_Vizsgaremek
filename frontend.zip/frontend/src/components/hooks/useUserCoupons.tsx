import { useQuery } from '@tanstack/react-query'
import axios from 'axios'

const getUserCoupons = async (userID: number | string | null) => {
  if (!userID) return []
  
  const response = await axios.get(`http://localhost:5000/api/users/${userID}/kuponok`, {
    withCredentials: true, 
  })
  
  return response.data
}

export function useUserCoupons(userID: number | string | null) {
  return useQuery({
    queryKey: ['coupons', userID],
    queryFn: () => getUserCoupons(userID),
    enabled: !!userID, 
    retry: 1, 
  })
}