import { useQuery } from '@tanstack/react-query'
import axios from 'axios'

export type RendelesTetel = {
    termek_id: number;
    mennyiseg: number;
    egyseg_ar: number;
    Termek?: {
        nev: string;
        kep_url: string;
    };
}

export type Rendeles = {
    rendeles_id: number;
    user_id: number;
    osszeg: number;
    cim: string;
    statusz: string;
    rendeles_datuma: string;
    Tetelek: RendelesTetel[]; // A backend include-nak köszönhetően
}

const getUserRendelesek = async (userId: number) => {
    const response = await axios.get<Rendeles[]>(
        `http://localhost:5000/api/rendeles/user/${userId}`
    );
    return response.data;
}

export function useUserOrders(userId: number | null) {
    return useQuery({
        queryKey: ['rendelesek', 'user', userId],
        queryFn: () => getUserRendelesek(userId!),
        enabled: !!userId,
    })
}