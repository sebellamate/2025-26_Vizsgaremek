import { useQuery } from '@tanstack/react-query'
import axios from 'axios'

const getItems = async (id:number) => {
  const response = await axios.get(`http://localhost:5000/api/kosartetelek/osszes/${id}`, {
    withCredentials: true,
  })
  return response.data
}

export function useItemsByid(id:number) {
  return useQuery({
    queryKey: ['kosar_tetelek', id],
    queryFn: () => getItems(id),
    retry: false,
  })
}
