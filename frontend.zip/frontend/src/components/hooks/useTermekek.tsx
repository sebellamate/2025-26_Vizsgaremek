import { useQuery } from '@tanstack/react-query'
import axios from 'axios'

type Termek = {
    termek_id: number,
    nev: string,
    leiras: string,
    ar: number,
    kep_url: string,
    kategoria_id: number
}

const getTermekek = async () => {
  return await axios.get<Termek[]>("http://localhost:5000/api/termekek")
}

export function useTermekek() {
  return useQuery({
    queryKey: ['termekek'],
    queryFn: getTermekek,
  })
}