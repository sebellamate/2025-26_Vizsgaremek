import { useQuery } from '@tanstack/react-query'
import axios from 'axios'

type Termekek = {
    termek_id: number,
    nev: string,
    leiras: string,
    ar: number,
    kep_url: string,
    kategoria_id: number
}
const getCart = async (id: number) => {
  const response = await axios.get<Termekek[]>(`http://localhost:5000/api/kosarak/${id}`)
  return response.data
}

export function useSearch(id: number) {
  return useQuery({
    queryKey: ['cart', id], 
    queryFn: () => getCart(id),
    enabled: !!id, 
  })
}