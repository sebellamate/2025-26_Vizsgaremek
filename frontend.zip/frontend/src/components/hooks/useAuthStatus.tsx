import { useQuery } from '@tanstack/react-query'
import axios from 'axios'


const getStatus = async () => {
  const response = await axios.get('http://localhost:5000/api/auth/status', {
    withCredentials: true,
  })
  console.log(response.data)
  return response.data
}

export function useAuthStatus() {
  return useQuery({
    queryKey: ['status'],
    queryFn: getStatus,
    retry: false,
  })
}
