import { useQuery } from "@tanstack/react-query";
import axios from "axios";

export function useUserData(userID: number | null) {
  return useQuery({
    queryKey: ["user_details", userID],
    queryFn: async () => {
      if (!userID) return null;
      
      const response = await axios.get(`http://localhost:5000/api/users/${userID}`, {
        withCredentials: true,
      });
      return response.data;
    },
    enabled: !!userID,
  });
}