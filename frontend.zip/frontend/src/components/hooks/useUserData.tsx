import { useQuery } from "@tanstack/react-query";
import axios from "axios";

export function useUserData(userID: number | null) {
  return useQuery({
    queryKey: ["user_details", userID],
    queryFn: async () => {
      // Csak akkor indul el, ha van userID
      if (!userID) return null;
      
      // Figyelj az URL-re! Ha a router a /felhasznalok alatt van, írd be azt is.
      const response = await axios.get(`http://localhost:5000/api/users/${userID}`, {
        withCredentials: true,
      });
      return response.data;
    },
    enabled: !!userID, // Csak akkor fut le, ha be van jelentkezve (van ID)
  });
}