import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import axios from 'axios'

export type Ertekeles = {
    ertekeles_id: number;
    termek_id: number;
    user_id: number;
    pontszam: number;
    velemeny: string;
    datum: string;
    Iro?: {
        name: string;
    };
}

export type CreateErtekelesRequest = {
    user_id: number;
    termek_id: number;
    pontszam: number;
    velemeny: string;
}

const API_URL = 'http://localhost:5000/api/ertekelesek';


const getErtekelesekByTermek = async (termekId: number) => {
    const response = await axios.get<Ertekeles[]>(`${API_URL}/termek/${termekId}`);
    return response.data;
}

const postErtekeles = async (ujAdat: CreateErtekelesRequest) => {
    const response = await axios.post<Ertekeles>(API_URL, ujAdat);
    return response.data;
}

export function useErtekelesek(termekId: number) {
    return useQuery({
        queryKey: ['ertekelesek', 'termek', termekId],
        queryFn: () => getErtekelesekByTermek(termekId),
        enabled: !!termekId,
    })
}

export function useCreateErtekeles() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: postErtekeles,
        onSuccess: (mentettErtekeles) => {
            queryClient.invalidateQueries({ 
                queryKey: ['ertekelesek', 'termek', mentettErtekeles.termek_id] 
            });
        },
    });
}