import { useQuery } from '@tanstack/react-query'
import axios from 'axios'

export type Ertekeles = {
    ertekeles_id: number;
    termek_id: number;
    user_id: number;
    pontszam: number;
    velemeny: string;
    datum: string;
    Iro?: {
        name: string;
    };
}

const getErtekelesekByTermek = async (termekId: number) => {
    const response = await axios.get<Ertekeles[]>(
        `http://localhost:5000/api/ertekelesek/termek/${termekId}`
    );
    return response.data;
}

export function useErtekelesek(termekId: number) {
    return useQuery({
        queryKey: ['ertekelesek', 'termek', termekId],
        queryFn: () => getErtekelesekByTermek(termekId),
        enabled: !!termekId,
    })
}