import { useQuery } from '@tanstack/react-query'
import axios from 'axios'

type Termek = {
    termek_id: number,
    nev: string,
    leiras: string,
    ar: number,
    kep_url: string,
    kategoria_id: number
}
const getTermek = async (id: number) => {
  const response = await axios.get<Termek>(`http://localhost:5000/api/termekek/${id}`)
  return response.data
}

export function useTermek(id: number) {
  return useQuery({
    queryKey: ['termekek', id], 
    queryFn: () => getTermek(id),
    enabled: !!id, 
  })
}