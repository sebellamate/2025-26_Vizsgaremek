import { useMutation, useQueryClient } from '@tanstack/react-query'
import axios from 'axios'

// 1. Definiáljuk a rendelés tétel típusát
type OrderItem = {
  termek_id: number;
  mennyiseg: number;
  egyseg_ar: number;
}

type OrderData = {
  user_id: number;      
  osszeg: number;
  cim: string; 
  tetelek: OrderItem[];
  kupon_id: string | number | null; 
}

// 3. API hívás
const postOrder = async (orderData: OrderData) => {
  const response = await axios.post('http://localhost:5000/api/rendeles', orderData, {
    withCredentials: true,
  })
  return response.data
}

export function useCreateOrder() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: postOrder,
    onSuccess: () => {
      // Invalidate-eljük a kosarat és a státuszt is, hogy frissüljön a felület
      queryClient.invalidateQueries({ queryKey: ['status'] })
      queryClient.invalidateQueries({ queryKey: ['kosar_tetelek'] })
    },
    onError: (error: any) => {
      console.error('Hiba a rendelés során:', error.response?.data || error.message)
    }
  })
}