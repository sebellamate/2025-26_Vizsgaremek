import { useMutation, useQueryClient } from '@tanstack/react-query'
import axios from 'axios'

// 1. Definiáljuk a rendelés tétel típusát
interface OrderItem {
  termek_id: number;
  mennyiseg: number;
  egyseg_ar: number;
}

// 2. Definiáljuk a teljes rendelési adat típusát
interface OrderData {
  osszeg: number;
  tetelek: OrderItem[];
}

// 3. Típusosítsuk a paramétert
const postOrder = async (orderData: OrderData) => {
  const response = await axios.post('http://localhost:5000/api/rendeles', orderData, {
    withCredentials: true,
  })
  return response.data
}

export function useCreateOrder() {
  const queryClient = useQueryClient()

  // A useMutation-nek is átadhatjuk a típusokat: <VisszatérésiÉrték, HibaTípus, VáltozóTípus>
  return useMutation({
    mutationFn: postOrder,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['status'] })
    },
    onError: (error: any) => {
      console.error('Hiba:', error.response?.data || error.message)
    }
  })
}