import { useForm } from "react-hook-form"
import z from "zod"
import { zodResolver } from "@hookform/resolvers/zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import axios from "axios"
import { useMutation, useQueryClient } from "@tanstack/react-query"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useState } from "react"


const formSchema = z.object({
  userID: z.string().nonempty({ message: "Érvényes email címet adj meg!" }),
  password: z.string().nonempty({ message: "A mező kitöltése kötelező!" }),

})

type FormSchema = z.infer<typeof formSchema>

const Login = async (user: FormSchema) => {
  const response = await axios.post("http://localhost:5000/api/auth/login", user, {
    withCredentials: true,
  })
  console.log(response.data)
  return response.data
}

  


export function LoginDialog() {
  const [open, setOpen] = useState(false)
  const queryClient = useQueryClient()

  const form = useForm<FormSchema>({
    mode: "onChange",
    resolver: zodResolver(formSchema),
    defaultValues: {
      userID: "",
      password: "",
    },
  })

  const { mutate: login, isPending } = useMutation({
    mutationFn: (user: FormSchema) => Login(user),
    onSuccess() {
      queryClient.invalidateQueries({ queryKey: ["users"] })
      setOpen(false)
      form.reset()
      window.location.href = "/"
    },
  })

  function onSubmit(values: FormSchema) {
    login(values)
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>Bejelentkezés</Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Bejelentkezés</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="userID"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Felhasznalónév</FormLabel>
                  <FormControl>
                    <Input type="userID"  {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Jelszó</FormLabel>
                  <FormControl>
                    <Input type="password"  {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="flex gap-2 justify-end">
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                Mégse
              </Button>
              <Button type="submit" disabled={!form.formState.isValid || isPending}>
                {isPending ? "Bejelentkezés..." : "Bejelentkezés"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}


