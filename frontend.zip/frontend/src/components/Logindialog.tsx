import { useForm } from "react-hook-form"
import z from "zod"
import { zodResolver } from "@hookform/resolvers/zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import axios from "axios"
import { useMutation, useQueryClient } from "@tanstack/react-query"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useState } from "react"


const formSchema = z.object({
  userID: z.string().nonempty({ message: "Érvényes email címet adj meg!" }),
  password: z.string().nonempty({ message: "A mező kitöltése kötelező!" }),

})

type FormSchema = z.infer<typeof formSchema>

const Login = async (user: FormSchema) => {
  const response = await axios.post("http://localhost:5000/api/auth/login", user, {
    withCredentials: true,
  })
  console.log(response.data)
  return response.data
}

  



export function LoginDialog() {
  const [open, setOpen] = useState(false)
  const queryClient = useQueryClient()

  const form = useForm<FormSchema>({
    mode: "onChange",
    resolver: zodResolver(formSchema),
    defaultValues: {
      userID: "",
      password: "",
    },
  })

  const { mutate: login, isPending } = useMutation({
    mutationFn: (user: FormSchema) => Login(user),
    onSuccess() {
      queryClient.invalidateQueries({ queryKey: ["users"] })
      setOpen(false)
      form.reset()
      window.location.href = "/"
    },
    onError(error: any) {
      const errorMessage = error.response?.data?.message || "Hibás felhasználónév vagy jelszó!";
      form.setError("root", {
        message: errorMessage
      });
    }
  })

  function onSubmit(values: FormSchema) {
    login(values)
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {/* A gomb stílusa maradt a sötétzöld, elegáns verzió */}
        <Button className="bg-emerald-800 hover:bg-emerald-900 text-emerald-50 font-bold py-2 px-8 rounded-full shadow-lg shadow-emerald-900/40 transform transition-all duration-200 hover:scale-105 active:scale-95 tracking-wide uppercase text-sm border border-emerald-700/50">
          Bejelentkezés
        </Button>
      </DialogTrigger>
      
      {/* A Dialógus háttér és keret finomítása */}
      <DialogContent className="max-w-md border-emerald-900/20 bg-slate-50">
        <DialogHeader>
          <DialogTitle className="text-emerald-950 text-2xl font-bold tracking-tight">
            Üdvözöljük újra!
          </DialogTitle>
          <p className="text-emerald-800/60 text-sm">Jelentkezzen be a fiókjába</p>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5 pt-4">
            
            {form.formState.errors.root && (
              <div className="bg-red-50 border border-red-200 p-3 rounded-lg flex items-center gap-2">
                <div className="h-1.5 w-1.5 rounded-full bg-red-500" />
                <p className="text-red-600 text-xs font-semibold uppercase tracking-wider">
                  {form.formState.errors.root.message}
                </p>
              </div>
            )}

            <FormField
              control={form.control}
              name="userID"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-emerald-900 font-semibold ml-1">Felhasználónév / Email</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="pelda@email.com"
                      {...field} 
                      className="bg-white border-emerald-100 focus-visible:ring-emerald-600 focus-visible:border-emerald-600 rounded-xl transition-all"
                    />
                  </FormControl>
                  <FormMessage className="text-rose-500 font-medium italic text-xs" />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-emerald-900 font-semibold ml-1">Jelszó</FormLabel>
                  <FormControl>
                    <Input 
                      type="password" 
                      placeholder="••••••••"
                      {...field} 
                      className="bg-white border-emerald-100 focus-visible:ring-emerald-600 focus-visible:border-emerald-600 rounded-xl transition-all"
                    />
                  </FormControl>
                  <FormMessage className="text-rose-500 font-medium italic text-xs" />
                </FormItem>
              )}
            />

            <div className="flex flex-col gap-3 pt-4">
              <Button 
                type="submit" 
                disabled={!form.formState.isValid || isPending}
                className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-6 rounded-xl shadow-md transition-all active:scale-[0.98]"
              >
                {isPending ? "Folyamatban..." : "Bejelentkezés"}
              </Button>
              
              <Button 
                type="button" 
                variant="ghost" 
                onClick={() => setOpen(false)}
                className="text-emerald-800 hover:text-emerald-950 hover:bg-emerald-100/50 font-medium"
              >
                Mégse
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}


