"use client"

import { Link } from "@tanstack/react-router"
import axios from "axios"
import { Button } from "./ui/button"
import {
  NavigationMenu,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
} from "@/components/ui/navigation-menu"
import { KosarDialog } from "./KosarDialog"
import { useNavigate } from "@tanstack/react-router"

export function NavbarLoggedIn() {
  const navigate = useNavigate();
  const handleLogout = async () => {
  await axios.delete("http://localhost:5000/api/auth/logout", {
    withCredentials: true,
  })
  window.location.href = "/"
}

  return (
    <header className="border-b bg-background">
      
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <Link to="/" className="text-2xl font-bold">webshop</Link>
        

        <NavigationMenu className="hidden md:flex">
          <NavigationMenuList>
            <NavigationMenuItem>
              <NavigationMenuLink>
                  <KosarDialog />
              </NavigationMenuLink>
            </NavigationMenuItem>
            <NavigationMenuItem>
              <NavigationMenuLink>
                <div className="flex gap-4">
                  <Button onClick={handleLogout}>
                    Logout
                  </Button>
                </div>
              </NavigationMenuLink>
            </NavigationMenuItem>
            <NavigationMenuItem>
              <NavigationMenuLink>
                <div className="flex gap-4">
                  <Button onClick={()=> {navigate({
                    to: "/profile"
                  })}}> 
                    Profil
                  </Button>
                </div>
              </NavigationMenuLink>
            </NavigationMenuItem>
          </NavigationMenuList>
        </NavigationMenu>

        
      </div>
    </header>
  )
}