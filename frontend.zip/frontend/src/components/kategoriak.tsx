"use client"

import { useKategoriak } from "./hooks/useKategoriak";
import { Skeleton } from "@/components/ui/skeleton"
import { cn } from "@/lib/utils" // Ha nincs cn-ed, használd a sima template literalt

// 1. Definiáljuk a Propos típusait
interface CategoryBarProps {
  selectedId: number | null;
  onSelect: (id: number | null) => void;
}

// 2. Adjunk típust a komponensnek
export function CategoryBar({ selectedId, onSelect }: CategoryBarProps) {
  const { data, isLoading, error } = useKategoriak();

  if (error) return null;

  return (
    <div className="w-full bg-white border-b overflow-x-auto no-scrollbar shadow-sm">
      <div className="container mx-auto flex items-center justify-center gap-2 py-3 px-4">
        {isLoading ? (
          Array.from({ length: 7 }).map((_, i) => (
            <Skeleton key={i} className="h-8 w-24 rounded-full" />
          ))
        ) : (
          <>
            {/* "Összes" gomb - onSelect(null)-t hív meg */}
            <button
              onClick={() => onSelect(null)}
              className={cn(
                "px-4 py-1.5 text-sm font-semibold rounded-full transition-all border shadow-sm",
                selectedId === null 
                  ? "bg-emerald-600 text-white border-emerald-600" 
                  : "bg-emerald-50 text-emerald-900 border-emerald-100 hover:bg-emerald-100"
              )}
            >
              Összes
            </button>

            {/* Dinamikus gombok */}
            {data?.data.map((kat) => (
              <button
                key={kat.kategoria_id}
                onClick={() => onSelect(kat.kategoria_id)}
                className={cn(
                  "px-4 py-1.5 text-sm font-medium rounded-full transition-all border",
                  selectedId === kat.kategoria_id
                    ? "bg-emerald-600 text-white border-emerald-600 shadow-md"
                    : "bg-emerald-50 text-emerald-900 border-emerald-100 hover:bg-emerald-600 hover:text-white"
                )}
              >
                {kat.nev}
              </button>
            ))}
          </>
        )}
      </div>
    </div>
  );
}