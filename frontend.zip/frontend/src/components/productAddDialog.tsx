import { useForm } from "react-hook-form"
import z from "zod"
import { zodResolver } from "@hookform/resolvers/zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { useState } from "react"
import { useMutation, useQueryClient } from "@tanstack/react-query"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useKategoriak } from "./hooks/useKategoriak"
import axios from "axios"

const formSchema = z.object({
  nev: z.string().nonempty({ message: "A mező kitöltése kötelező!" }),
  leiras: z.string().nonempty({ message: "A mező kitöltése kötelező!" }),
  ar: z.string().nonempty({ message: "A mező kitöltése kötelező!" }),
  kep_url: z.string(),
  kategoria_id: z.string().nonempty({ message: "A mező kitöltése kötelező!" }),
})

type FormSchema = z.infer<typeof formSchema>

const postTermek = async (termek: FormSchema) => {
  const response = await axios.post("http://localhost:5000/api/termekek", termek,
    {withCredentials: true}
  )
  return response.data
}

const uploadFile = async (file: File) => {
  const formData = new FormData()
  formData.append("file", file)
  const response = await axios.post("http://localhost:5000/api/picupload", formData, {
    headers: { "Content-Type": "multipart/form-data" },
  })
  return response.data.filename
}

export function TermekCreateDialog() {
  const { data: kategoriak } = useKategoriak()
  const [open, setOpen] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const queryClient = useQueryClient()

  const form = useForm<FormSchema>({
    mode: "onChange",
    resolver: zodResolver(formSchema),
    defaultValues: {
      nev: "",
      leiras: "",
      ar: "",
      kep_url: "",
      kategoria_id: "",
    },
  })

  const { mutate: create, isPending } = useMutation({
    mutationFn: (termek: FormSchema) => postTermek(termek),
    onSuccess() {
      queryClient.invalidateQueries({ queryKey: ["termekek"] })
      setOpen(false)
      form.reset()
      setSelectedFile(null)
    },
  })

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0] || null
    setSelectedFile(file)
  }

  async function onSubmit(values: FormSchema) {
  try {
    // Ha van kiválasztott fájl, először töltsük fel a backendre
    if (selectedFile) {
      const filename = await uploadFile(selectedFile)
      form.setValue("kep_url", filename) // Frissítjük a form state-et
      values.kep_url = filename
    }

    // Backend felé a termék adatokat elküldjük
    create(values)
  } catch (error) {
    console.error("Hiba a kép feltöltésénél:", error)
    alert("Hiba történt a kép feltöltése közben!")
  }
}


  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>Új Termék</Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Termék hozzáadása</DialogTitle>
          <DialogDescription>Töltsd ki az alábbi mezőket a termék létrehozásához</DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="nev"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Név</FormLabel>
                  <FormControl>
                    <Input placeholder="Add meg a termék nevét" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="leiras"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Leírás</FormLabel>
                  <FormControl>
                    <Input placeholder="Add meg a termék leírását" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="ar"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Ár</FormLabel>
                  <FormControl>
                    <Input placeholder="Add meg a termék árát" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
  control={form.control}
  name="kep_url"
  render={({ field }) => (
    <FormItem>
      <FormLabel>Kép fájl neve</FormLabel>
      <FormControl>
        <Input
          placeholder="Feltöltés után automatikusan kitöltődik"
          {...field}
          readOnly
        />
      </FormControl>
      <FormMessage />
    </FormItem>
  )}
/>

            <FormItem>
              <FormLabel>Kép feltöltése</FormLabel>
              <FormControl>
                <Input type="file" accept="image/*" onChange={handleFileChange} />
              </FormControl>
              {selectedFile && <p className="text-sm mt-1">Feltöltött fájl: {selectedFile.name}</p>}
            </FormItem>
            <FormField
              control={form.control}
              name="kategoria_id"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Válassz kategóriát</FormLabel>
                  <FormControl>
                    <Select value={field.value} onValueChange={field.onChange} disabled={!kategoriak}>
                      <SelectTrigger>
                        <SelectValue placeholder="Kategória kiválasztása" />
                      </SelectTrigger>
                      <SelectContent>
                        {kategoriak?.data.map((k) => (
                          <SelectItem key={k.kategoria_id} value={k.kategoria_id.toString()}>
                            {k.nev}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="flex gap-2 justify-end">
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                Mégse
              </Button>
              <Button type="submit" disabled={isPending}>
  {isPending ? "Mentés..." : "Mentés"}
</Button>

            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}
