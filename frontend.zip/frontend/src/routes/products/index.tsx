import { createFileRoute } from '@tanstack/react-router'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { useTermekek } from "../../components/hooks/useTermekek";
import { Button } from '@/components/ui/button';
import { TermekCreateDialog } from '@/components/productAddDialog';
import { useNavigate } from '@tanstack/react-router';
import { DeleteproductDialog } from '@/components/DeleteproductDialog';
import { ProductEditDialog } from '@/components/ProductEditDialog';
export const Route = createFileRoute('/products/')({
  component: RouteComponent,
})


function RouteComponent() {
    const { data: termekek } = useTermekek()
    const navigate = useNavigate()
  return (
    <div>
      <TermekCreateDialog />   
      <Table>
  <TableHeader>
    <TableRow>
      <TableHead>ID</TableHead>
      <TableHead>Név</TableHead>
      <TableHead>Leírás</TableHead>
      <TableHead>Ár</TableHead>
      <TableHead>Kép Url</TableHead>
      <TableHead>Kategória_ID</TableHead>
    </TableRow>
  </TableHeader>
  <TableBody>
    {termekek?.data.map((termek) => 
        <TableRow key={termek.termek_id}>
      <TableCell>{termek.termek_id}</TableCell>
      <TableCell>{termek.nev}</TableCell>
      <TableCell>{termek.leiras}</TableCell>
      <TableCell>{termek.ar}</TableCell>
      <TableCell>{termek.kep_url}</TableCell>
      <TableCell>{termek.kategoria_id}</TableCell>
      <TableCell>
        <ProductEditDialog termek_id={termek.termek_id}/>
      </TableCell>

      <TableCell>
        <DeleteproductDialog termek_id={termek.termek_id}/>
      </TableCell>

      <TableCell>
        <Button onClick={() => navigate({
          to: "/products/$id",
          params:{
              id:termek.termek_id.toString()
          }
        })}>Megtekintés</Button>
      </TableCell>

    </TableRow>
    )}
  </TableBody>
</Table>
    </div>
  )
}
