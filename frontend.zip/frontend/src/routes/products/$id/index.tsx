import { createFileRoute } from '@tanstack/react-router'
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardAction,
} from "@/components/ui/card"
import { Button } from '@/components/ui/button'
import { useNavigate } from '@tanstack/react-router'
import { useTermek } from '../../../components/hooks/useTermek' 

export const Route = createFileRoute('/products/$id/')({
  component: RouteComponent,
})

function RouteComponent() {
  const params = Route.useParams()
const { data: termek, isLoading, error } = useTermek(Number(params.id))
const navigate = useNavigate()
if (isLoading) return <p>Betöltés...</p>
  if (error) return <p>Hiba történt a termék lekérése közben.</p>
     return (
    <Card>
      <CardHeader>
        <CardTitle>Termék megtekintése</CardTitle>
        <CardAction>
          <Button
            onClick={() =>
              navigate({
                to: "/products",
              })
            }
          >
            Vissza
          </Button>
        </CardAction>
      </CardHeader>
      <CardContent>
        <p>Termék ID: {termek?.termek_id}</p>
        <p>Név: {termek?.nev}</p>
        <p>Leírás: {termek?.leiras}</p>
        <p>Ár: {termek?.ar} Ft</p>
        <p>Kép URL: {termek?.kep_url}</p>
        <p>Kategória ID: {termek?.kategoria_id}</p>
      </CardContent>
    </Card>
  )
  
}
