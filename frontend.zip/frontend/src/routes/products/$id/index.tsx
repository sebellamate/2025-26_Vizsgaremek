import { createFileRoute, useNavigate } from '@tanstack/react-router'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useTermek } from '../../../components/hooks/useTermek'
import { useErtekelesek } from '@/components/hooks/useErtekelesek' 
import { useMutation, useQueryClient } from "@tanstack/react-query"
import axios from "axios"
import { useAuthStatus } from '@/components/hooks/useAuthStatus'
import { ShoppingCart, ArrowLeft, Star, MessageSquare } from 'lucide-react'
import { useMemo } from 'react'

export const Route = createFileRoute('/products/$id/')({
  component: RouteComponent,
})

const postTetel = (data: { user_id: number; termek_id: number }) => {
  return axios.post("http://localhost:5000/api/kosartetelek", data, {
    withCredentials: true,
  });
};

function RouteComponent() {
  const params = Route.useParams()
  const termekId = Number(params.id)
  const queryClient = useQueryClient()
  const navigate = useNavigate()
  
  const { data: user } = useAuthStatus()
  const { data: termek, isLoading: termekLoading, error } = useTermek(termekId)
  const { data: ertekelesek, isLoading: ertekelesLoading } = useErtekelesek(termekId)

  const { mutate: posttetel, isPending } = useMutation({
    mutationFn: postTetel,
    onSuccess: () => {
      alert("Termék sikeresen a kosárba került!");
      queryClient.invalidateQueries({ queryKey: ["kosar_tetelek", user?.userID] });
    },
    onError: (error: any) => {
      if (error.response?.status === 400 || error.response?.status === 500) {
        alert("Ez a termék már szerepel a kosaradban!");
      } else {
        alert("Hiba történt a kosárba tétel során.");
      }
    }
  });

  const atlagPontszam = useMemo(() => {
    if (!ertekelesek || ertekelesek.length === 0) return 0;
    const osszeg = ertekelesek.reduce((acc, curr) => acc + curr.pontszam, 0);
    return (osszeg / ertekelesek.length).toFixed(1);
  }, [ertekelesek]);

  if (termekLoading) return <div className="p-20 text-center animate-pulse text-emerald-700 font-bold">Termék betöltése...</div>
  if (error) return <div className="p-20 text-center text-red-500 font-bold">A keresett termék nem található.</div>

  return (
    <div className="max-w-6xl mx-auto p-6 lg:p-12 bg-slate-50/30 min-h-screen">
      {/* Vissza gomb */}
      <Button 
        variant="ghost" 
        onClick={() => navigate({ to: "/" })} 
        className="mb-8 text-emerald-700 hover:bg-emerald-100/50 gap-2 transition-all font-medium"
      >
        <ArrowLeft className="w-4 h-4" />
        Vissza a főoldalra
      </Button>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
        {/* BAL OLDAL: Kép */}
        <div className="sticky top-24">
          <div className="aspect-square rounded-3xl overflow-hidden shadow-2xl border-8 border-white bg-white">
            <img 
              src={`/kepek/${termek?.kep_url}`} 
              alt={termek?.nev} 
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        {/* JOBB OLDAL: Termék infók */}
        <div className="flex flex-col space-y-8">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <Badge variant="outline" className="text-emerald-600 border-emerald-200 bg-emerald-50 px-3 py-1">
                Készleten
              </Badge>
              {ertekelesek && ertekelesek.length > 0 && (
                <div className="flex items-center gap-1 text-yellow-500 font-bold">
                  <Star className="w-4 h-4 fill-current" />
                  <span>{atlagPontszam}</span>
                  <span className="text-slate-400 font-normal text-sm">({ertekelesek.length} vélemény)</span>
                </div>
              )}
            </div>
            
            <h1 className="text-5xl font-black text-emerald-950 tracking-tight leading-none">
              {termek?.nev}
            </h1>
            <p className="text-slate-500 text-xl leading-relaxed">
              {termek?.leiras}
            </p>
          </div>

          <div className="p-8 bg-white rounded-3xl shadow-sm border border-emerald-100 flex flex-col gap-6">
            <div>
              <span className="text-slate-400 text-xs font-bold uppercase tracking-widest">Bruttó ár</span>
              <div className="text-5xl font-black text-emerald-800">
                {Number(termek?.ar).toLocaleString()} <span className="text-2xl">Ft</span>
              </div>
            </div>

            <Button 
              onClick={() => {
                if (!user) return alert("Jelentkezz be a vásárláshoz!");
                posttetel({ user_id: user.userID, termek_id: termekId });
              }}
              disabled={isPending}
              className="w-full h-16 bg-emerald-600 hover:bg-emerald-700 text-white text-xl font-bold rounded-2xl shadow-xl shadow-emerald-200 transition-all active:scale-95 flex gap-3"
            >
              <ShoppingCart className="w-6 h-6" />
              {isPending ? "Hozzáadás..." : "Kosárba teszem"}
            </Button>
          </div>

          {/* ÉRTÉKELÉSEK SZEKCIÓ */}
          <div className="space-y-6 pt-4">
            <h2 className="text-2xl font-bold text-emerald-950 flex items-center gap-2">
              <MessageSquare className="w-6 h-6 text-emerald-600" />
              Vásárlói vélemények
            </h2>

            {ertekelesLoading ? (
              <p className="text-slate-400 animate-pulse">Vélemények betöltése...</p>
            ) : ertekelesek && ertekelesek.length > 0 ? (
              <div className="grid gap-4">
                {ertekelesek.map((e) => (
                  <div key={e.ertekeles_id} className="bg-white p-6 rounded-2xl border border-slate-100">
                    <div className="flex justify-between items-start mb-3">
                      <span className="font-bold text-emerald-900">{e.Iro?.name || "Vendég"}</span>
              </div>

              <p className="text-slate-600 italic leading-relaxed">
                "{e.velemeny}" 
              </p>

              <div className="text-[10px] text-slate-300 mt-2">
                {new Date(e.datum).toLocaleDateString('hu-HU')}
              </div>
            </div>
            ))}
              </div>
            ) : (
              <div className="bg-white/50 border-2 border-dashed border-slate-200 rounded-3xl p-10 text-center text-slate-400">
                <p>Erről a termékről még nem írtak véleményt.</p>
                <p className="text-sm">Legyél te az első!</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}