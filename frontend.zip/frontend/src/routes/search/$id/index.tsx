"use client"

import { createFileRoute, useNavigate, Link } from "@tanstack/react-router"
import {
  Card,
  CardContent,
} from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useTermekekBy_ids } from "@/components/hooks/useTermekekByid"
import { ShoppingBag, ArrowLeft, Eye } from "lucide-react"

type Termek = {
  termek_id: number
  nev: string
  leiras: string
  ar: number // Átírtam numberre a számoláshoz
  akcio: number
  kep_url: string
  kategoria_id: number
}

export const Route = createFileRoute("/search/$id/")({
  component: SearchResultsRoute,
})

function SearchResultsRoute() {
  const navigate = useNavigate()
  const { id } = Route.useParams()
  const ids = id.split(",").map(Number)

  const {
    data: termekek,
    isLoading,
    error,
  } = useTermekekBy_ids(ids)

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-700" />
        <p className="text-emerald-800 font-medium">Találatok keresése...</p>
      </div>
    )
  }

  if (error || !termekek || termekek.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
        <ShoppingBag className="w-16 h-16 text-slate-200" />
        <h2 className="text-2xl font-bold text-slate-700">Nincs találat</h2>
        <p className="text-slate-500">Sajnos nem találtunk a keresésnek megfelelő terméket.</p>
        <Button onClick={() => navigate({ to: "/" })} variant="outline" className="border-emerald-200 text-emerald-700">
          Vissza a főoldalra
        </Button>
      </div>
    )
  }

  return (
    <div className="p-8 bg-slate-50/30 min-h-screen">
      {/* Fejléc és Vissza gomb */}
      <div className="max-w-7xl mx-auto mb-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-4xl font-black text-emerald-900 tracking-tight">Keresési találatok</h1>
          <p className="text-slate-500 mt-1">{termekek.length} terméket találtunk</p>
        </div>
        <Button 
          variant="ghost" 
          onClick={() => navigate({ to: "/" })} 
          className="text-emerald-700 hover:bg-emerald-50 self-start gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Vissza a főoldalra
        </Button>
      </div>

      {/* Grid elrendezés - Pont mint a Homepage-en */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
        {termekek.map((t: Termek) => {
          const vanAkcio = t.akcio > 0;
          const akciosAr = vanAkcio 
            ? Math.round(t.ar * (1 - t.akcio / 100)) 
            : t.ar;

          return (
            <Card key={t.termek_id} className="group hover:shadow-2xl transition-all duration-500 border-emerald-100/50 overflow-hidden bg-white flex flex-col relative">
              
              {vanAkcio && (
                <div className="absolute top-3 left-3 z-20">
                  <Badge className="bg-red-500 hover:bg-red-500 text-white font-bold shadow-lg border-none px-2 py-1">
                    -{t.akcio}%
                  </Badge>
                </div>
              )}

              {/* Kattintható rész a részletekhez */}
              <Link 
                to="/products/$id" 
                params={{ id: t.termek_id.toString() }}
                className="cursor-pointer flex-1 group"
              >
                <div className="relative overflow-hidden h-56">
                  <img
                    src={`/kepek/${t.kep_url}`}
                    className="h-full w-full object-cover transform group-hover:scale-110 transition-transform duration-700 ease-in-out"
                    alt={t.nev}
                  />
                  <div className="absolute inset-0 bg-emerald-900/0 group-hover:bg-emerald-900/10 transition-colors duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100">
                     <div className="bg-white/90 p-2 rounded-full shadow-xl">
                        <Eye className="w-6 h-6 text-emerald-700" />
                     </div>
                  </div>
                </div>

                <CardContent className="p-5">
                  <h3 className="text-lg font-bold text-emerald-950 mb-2 group-hover:text-emerald-700 transition-colors line-clamp-1">
                    {t.nev}
                  </h3>
                  <p className="text-sm text-slate-500 line-clamp-2 mb-4 h-10 leading-relaxed">
                    {t.leiras}
                  </p>
                  
                  <div className="flex flex-col justify-end h-14">
                    {vanAkcio ? (
                      <div>
                        <span className="text-xs text-slate-400 line-through block">
                          {Number(t.ar).toLocaleString("hu-HU")} Ft
                        </span>
                        <span className="font-black text-emerald-700 text-2xl">
                          {akciosAr.toLocaleString("hu-HU")} Ft
                        </span>
                      </div>
                    ) : (
                      <span className="font-black text-emerald-700 text-2xl">
                        {Number(t.ar).toLocaleString("hu-HU")} Ft
                      </span>
                    )}
                  </div>
                </CardContent>
              </Link>

              <div className="p-5 pt-0">
                <Button
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl h-11 transition-all active:scale-95"
                  onClick={() =>
                    navigate({
                      to: "/products/$id",
                      params: { id: String(t.termek_id) },
                    })
                  }
                >
                  Megtekintés
                </Button>
              </div>
            </Card>
          )
        })}
      </div>
    </div>
  )
}