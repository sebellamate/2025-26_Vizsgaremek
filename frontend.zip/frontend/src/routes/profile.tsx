import { createFileRoute } from '@tanstack/react-router'
import { useAuthStatus } from '@/components/hooks/useAuthStatus'
import { Button } from '@/components/ui/button'
import { useNavigate } from '@tanstack/react-router'

export const Route = createFileRoute('/profile')({
  component: RouteComponent,
})

function RouteComponent() {
  const navigate = useNavigate();
  const { data: user, isLoading } = useAuthStatus()
  if(isLoading){
    return <p>Betoltes....</p>
  }
  if(user.isAdmin){
    return (
    <div>
        <p>Bejelentkezett felhasználó: {user.username}</p>
        <p>Admin: igen</p>
        <Button onClick={()=>{navigate({
            to:"/Adminpage"
        })}}>CRUD</Button>
    </div>
    )
  }else{
    return (
    <div>
        <p>Bejelentkezett felhasználó: {user.username}</p>
        <p>Admin: nem</p>
    </div>
    )
  }
  
}
