import { useState } from 'react'
import { createFileRoute, useNavigate } from '@tanstack/react-router'
import { LoginDialog } from '@/components/Logindialog'
import { JelszoModositasDialog } from '@/components/JelszoModositasDialog'

// Hookok
import { useAuthStatus } from '@/components/hooks/useAuthStatus'
import { useUserData } from '@/components/hooks/useUserData'
import { useUserCoupons } from '@/components/hooks/useUserCoupons'
import { useUserOrders, Rendeles, RendelesTetel } from '@/components/hooks/useUserOrders'

// UI Komponensek
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

// Ikonok
import { 
  User, ShieldCheck, Package, LogOut, Ticket, Mail, 
  Lock, Settings2, Percent, Copy, CheckCircle2, XCircle, 
  Calendar, MapPin, ChevronRight
} from 'lucide-react'
import axios from "axios"

export const Route = createFileRoute('/profile')({
  component: RouteComponent,
})

function RouteComponent() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'profil' | 'kuponok' | 'rendelesek'>('profil')

  const handleLogout = async () => {
    try {
      await axios.delete("http://localhost:5000/api/auth/logout", {
        withCredentials: true,
      });
      window.location.href = "/";
    } catch (error) {
      console.error("Hiba a kijelentkezés során:", error);
    }
  };

  // 1. ADATOK LEKÉRÉSE
  const { data: authUser, isLoading: authLoading } = useAuthStatus()
  const userId = authUser?.userID || null;

  const { data: fullUser, isLoading: detailsLoading } = useUserData(userId)
  const { data: coupons, isLoading: couponsLoading } = useUserCoupons(userId)
  const { data: orders, isLoading: ordersLoading } = useUserOrders(userId)
  
  // BETÖLTÉSI ÁLLAPOT
  if (authLoading || detailsLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-emerald-50/20">
        <div className="flex flex-col items-center gap-2">
          <div className="h-12 w-12 animate-spin rounded-full border-4 border-emerald-600 border-t-transparent"></div>
          <p className="text-emerald-700 font-medium animate-pulse">Profil szinkronizálása...</p>
        </div>
      </div>
    )
  }
  
  const user = fullUser || authUser;

  // HA NINCS BEJELENTKEZVE
  if (!user) {
    return (
      <div className="container mx-auto p-20 text-center flex flex-col items-center justify-center min-h-[60vh]">
        <div className="bg-emerald-50 p-6 rounded-full mb-6">
          <User className="w-16 h-16 text-emerald-200" />
        </div>
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Bejelentkezés szükséges</h2>
        <p className="mb-6 text-gray-500 max-w-xs mx-auto">A profilod és kedvezményeid eléréséhez kérjük, lépj be a fiókodba.</p>
        <LoginDialog />
      </div>
    )
  }

  return (
    <div className="container mx-auto py-10 px-4 max-w-5xl">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        
        {/* OLDALSÁV - NAVIGÁCIÓ */}
        <aside className="md:col-span-1 space-y-4">
          <Card className="border-emerald-100 shadow-md overflow-hidden bg-white">
            <div className="bg-emerald-600 h-2 w-full" />
            <CardHeader className="text-center pb-4">
              <div className="mx-auto bg-emerald-50 w-20 h-20 rounded-full flex items-center justify-center mb-3 border-2 border-emerald-100 shadow-inner">
                <User className="w-10 h-10 text-emerald-600" />
              </div>
              <CardTitle className="text-xl font-bold text-gray-800 truncate px-2">
                {user.username || user.name}
              </CardTitle>
              {user.isAdmin && (
                <Badge className="mt-1 bg-emerald-600 hover:bg-emerald-700 shadow-sm px-3">
                  <ShieldCheck className="w-3 h-3 mr-1" /> Admin
                </Badge>
              )}
            </CardHeader>
            <CardContent className="p-2 space-y-1">
              {[
                { id: 'profil', label: 'Profil adatok', icon: User },
                { id: 'kuponok', label: 'Kuponjaim', icon: Ticket, count: coupons?.length },
                { id: 'rendelesek', label: 'Rendeléseim', icon: Package, count: orders?.length },
              ].map((tab) => (
                <Button 
                  key={tab.id}
                  variant="ghost" 
                  className={`w-full justify-start transition-all duration-200 ${
                    activeTab === tab.id 
                    ? 'bg-emerald-50 text-emerald-700 font-bold shadow-sm' 
                    : 'text-gray-500 hover:text-emerald-600 hover:bg-emerald-50/50'
                  }`}
                  onClick={() => setActiveTab(tab.id as any)}
                >
                  <tab.icon className={`w-4 h-4 mr-3 ${activeTab === tab.id ? 'text-emerald-600' : ''}`} />
                  {tab.label}
                  {tab.count !== undefined && tab.count > 0 && (
                    <span className="ml-auto bg-emerald-100 text-emerald-700 text-[10px] py-0.5 px-1.5 rounded-full">
                      {tab.count}
                    </span>
                  )}
                </Button>
              ))}
            </CardContent>
          </Card>

          <Button 
    variant="outline" 
    className="w-full text-red-500 border-red-100 hover:bg-red-50 hover:text-red-600 transition-all shadow-sm"
    onClick={handleLogout}
  >
    <LogOut className="w-4 h-4 mr-2" /> Kijelentkezés
  </Button>
        </aside>

        {/* FŐ TARTALOM */}
        <main className="md:col-span-3 min-h-[500px]">
          
          {/* 1. PROFIL FÜL */}
          {activeTab === 'profil' && (
            <Card className="border-emerald-100 shadow-md animate-in fade-in slide-in-from-right-4 duration-500 bg-white">
              <CardHeader className="border-b border-gray-50 pb-6">
                <div className="flex items-center gap-2 text-emerald-800 mb-1">
                  <Settings2 className="w-5 h-5" />
                  <CardTitle>Fiók beállítások</CardTitle>
                </div>
                <CardDescription>Itt találod a személyes adataidat és jelszókezelési beállításaidat.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-8 pt-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase text-gray-400 ml-1">Felhasználónév</label>
                    <div className="p-4 border border-gray-100 rounded-2xl bg-gray-50/30 flex items-center gap-3">
                      <User className="w-4 h-4 text-emerald-500" />
                      <p className="font-semibold text-gray-700">{user.name}</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase text-gray-400 ml-1">Email cím</label>
                    <div className="p-4 border border-gray-100 rounded-2xl bg-gray-50/30 flex items-center gap-3">
                      <Mail className="w-4 h-4 text-emerald-500" />
                      <p className="font-semibold text-gray-700">{user.email || "Nincs megadva"}</p>
                    </div>
                  </div>

                  <div className="sm:col-span-2 space-y-2">
                    <label className="text-xs font-bold uppercase text-gray-400 ml-1">Biztonság</label>
                    <div className="p-4 border border-gray-100 rounded-2xl bg-gray-50/30 flex justify-between items-center group">
                      <div className="flex items-center gap-3">
                        <Lock className="w-4 h-4 text-emerald-500" />
                        <div>
                          <p className="text-sm font-semibold text-gray-700">Jelszó</p>
                          <p className="text-xs text-gray-400 tracking-[0.3em]">••••••••••••</p>
                        </div>
                      </div>
                      <JelszoModositasDialog/>
                    </div>
                  </div>
                </div>

                {user.isAdmin && (
                  <div className="p-6 bg-emerald-600 rounded-2xl shadow-lg shadow-emerald-100 flex flex-col sm:flex-row items-center justify-between gap-4 text-white">
                    <div className="flex items-center gap-4 text-center sm:text-left">
                      <div className="p-3 bg-white/20 rounded-xl backdrop-blur-sm">
                        <ShieldCheck className="w-8 h-8 text-white" />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg leading-tight">Adminisztrációs Panel</h3>
                        <p className="text-emerald-50 text-sm opacity-90">Rendszer teljeskörű kezelése.</p>
                      </div>
                    </div>
                    <Button 
                      className="bg-white text-emerald-700 hover:bg-emerald-50 font-bold px-8 shadow-sm transition-transform active:scale-95" 
                      onClick={() => navigate({ to: "/Adminpage" })}
                    >
                      Kezelés indítása
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* 2. KUPONOK FÜL */}
          {activeTab === 'kuponok' && (
            <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-500">
              <h2 className="text-xl font-bold text-emerald-900 flex items-center gap-2 mb-2 px-2">
                <Ticket className="w-5 h-5" /> Saját kedvezmények
              </h2>

              {couponsLoading ? (
                <div className="flex justify-center py-20 bg-white rounded-3xl border border-emerald-50 shadow-sm">
                   <div className="h-8 w-8 animate-spin rounded-full border-4 border-emerald-600 border-t-transparent"></div>
                </div>
              ) : coupons && coupons.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {coupons.map((kupon: any) => (
                    <Card key={kupon.id} className={`overflow-hidden border-none shadow-md transition-all hover:shadow-lg ${!kupon.ervenyes && 'grayscale opacity-60'}`}>
                      <div className="flex h-full min-h-[120px]">
                        <div className="flex flex-col items-center justify-center w-24 bg-emerald-600 text-white p-4 text-center">
                           <Percent className="w-4 h-4 mb-1 opacity-80" />
                           <span className="text-2xl font-black">{kupon.szazalek}%</span>
                           <span className="text-[10px] uppercase font-bold tracking-tighter">OFF</span>
                        </div>
                        <CardContent className="p-4 flex-1 bg-white flex flex-col justify-between">
                          <div className="flex justify-between items-start">
                            <code className="bg-emerald-50 text-emerald-700 px-2 py-1 rounded font-mono font-bold text-sm border border-emerald-100 uppercase">
                              {kupon.kod}
                            </code>
                            {kupon.ervenyes ? (
                              <Badge className="bg-emerald-100 text-emerald-700 border-none text-[10px] font-bold"><CheckCircle2 className="w-3 h-3 mr-1"/> AKTÍV</Badge>
                            ) : (
                              <Badge variant="secondary" className="text-[10px] font-bold"><XCircle className="w-3 h-3 mr-1"/> LEJÁRT</Badge>
                            )}
                          </div>
                          <div className="mt-4 pt-3 border-t border-gray-50 flex justify-between items-center">
                            <span className="text-[10px] text-gray-400 italic">Egyszeri felhasználás</span>
                            {kupon.ervenyes && (
                              <Button 
                                size="sm" variant="ghost" className="h-7 px-2 text-emerald-600 hover:bg-emerald-50"
                                onClick={() => {
                                  navigator.clipboard.writeText(kupon.kod);
                                  // Ide jöhet egy toast értesítés ha van
                                }}
                              >
                                <Copy className="w-3 h-3 mr-1" /> Másolás
                              </Button>
                            )}
                          </div>
                        </CardContent>
                      </div>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card className="border-emerald-100 shadow-md border-dashed flex flex-col items-center justify-center py-24 text-center bg-white">
                  <Ticket className="w-12 h-12 text-emerald-600 opacity-20 mb-4" />
                  <CardTitle className="text-gray-700 text-xl">Nincsenek kuponjaid</CardTitle>
                  <CardDescription>Nézz vissza később új ajánlatokért!</CardDescription>
                </Card>
              )}
            </div>
          )}

          {/* 3. RENDELÉSEK FÜL */}
          {activeTab === 'rendelesek' && (
            <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-500">
              <h2 className="text-xl font-bold text-emerald-900 flex items-center gap-2 mb-2 px-2">
                <Package className="w-5 h-5" /> Rendelési előzmények
              </h2>

              {ordersLoading ? (
                <div className="flex justify-center py-20 bg-white rounded-3xl border border-emerald-50 shadow-sm">
                   <div className="h-8 w-8 animate-spin rounded-full border-4 border-emerald-600 border-t-transparent"></div>
                </div>
              ) : orders && orders.length > 0 ? (
                <div className="space-y-4">
                  {orders.map((rendeles: Rendeles) => (
                    <Card key={rendeles.rendeles_id} className="border-emerald-100 shadow-sm overflow-hidden bg-white hover:shadow-md transition-all">
                      {/* Fejléc */}
                      <div className="bg-gray-50/80 p-4 border-b border-gray-100 flex flex-wrap justify-between items-center gap-4">
                        <div className="flex items-center gap-4">
                          <div className="bg-white p-2 rounded-lg border border-gray-200">
                            <Package className="w-5 h-5 text-emerald-600" />
                          </div>
                          <div>
                            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Rendelés száma</p>
                            <p className="font-mono font-bold text-gray-700">#ORD-{rendeles.rendeles_id}</p>
                          </div>
                        </div>
                        <div className="flex gap-6">
                           <div className="hidden sm:block">
                              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider text-right">Dátum</p>
                              <div className="flex items-center text-sm text-gray-600 gap-1.5">
                                <Calendar className="w-3.5 h-3.5" />
                                {new Date(rendeles.rendeles_datuma).toLocaleDateString('hu-HU')}
                              </div>
                           </div>
                           <div>
                              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider text-right">Állapot</p>
                              <Badge className={`${rendeles.statusz === 'fizetve' ? 'bg-emerald-500 hover:bg-emerald-600' : 'bg-blue-500'} shadow-none`}>
                                {rendeles.statusz.toUpperCase()}
                              </Badge>
                           </div>
                        </div>
                      </div>

                      {/* Tartalom (Tételek) */}
                      <CardContent className="p-4 sm:p-6">
                        <div className="space-y-4">
                          {rendeles.Tetelek?.map((tetel: RendelesTetel, idx: number) => (
                            <div key={idx} className="flex items-center justify-between group">
                              <div className="flex items-center gap-3">
                                <div className="h-10 w-10 bg-emerald-50 rounded-lg flex items-center justify-center text-emerald-600 font-bold text-xs border border-emerald-100">
                                  {tetel.mennyiseg}x
                                </div>
                                <div>
                                  <p className="text-sm font-bold text-gray-700 group-hover:text-emerald-700 transition-colors">
                                    {tetel.Termek?.nev || "Betöltés..."}
                                  </p>
                                  <p className="text-xs text-gray-400">Egységár: {tetel.egyseg_ar.toLocaleString()} Ft</p>
                                </div>
                              </div>
                              <span className="font-semibold text-gray-600 text-sm">
                                {(tetel.mennyiseg * tetel.egyseg_ar).toLocaleString()} Ft
                              </span>
                            </div>
                          ))}
                        </div>

                        {/* Összesítő rész */}
                        <div className="mt-6 pt-6 border-t border-dashed border-gray-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                          <div className="flex items-center gap-2 text-gray-400 text-xs">
                            <MapPin className="w-3.5 h-3.5" />
                            <span className="truncate max-w-[200px]">{rendeles.cim}</span>
                          </div>
                          <div className="flex items-center gap-4 w-full sm:w-auto justify-between">
                            <span className="text-sm font-medium text-gray-500">Végösszeg:</span>
                            <span className="text-2xl font-black text-emerald-600 tracking-tight">
                              {rendeles.osszeg.toLocaleString()} Ft
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card className="border-emerald-100 shadow-md border-dashed flex flex-col items-center justify-center py-24 text-center bg-white">
                  <Package className="w-12 h-12 text-emerald-600 opacity-20 mb-4" />
                  <CardTitle className="text-gray-700 text-xl">Még nincs rendelésed</CardTitle>
                  <CardDescription className="mb-4">Válogass kedvedre termékeink közül!</CardDescription>
                  <Button 
                    variant="outline" 
                    onClick={() => navigate({to: '/'})} 
                    className="border-emerald-600 text-emerald-600 hover:bg-emerald-50 font-bold"
                  >
                    Vásárlás indítása <ChevronRight className="ml-2 w-4 h-4" />
                  </Button>
                </Card>
              )}
            </div>
          )}
        </main>
      </div>
    </div>
  )
}