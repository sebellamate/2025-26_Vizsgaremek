import { createFileRoute } from '@tanstack/react-router'
import { Button } from '@/components/ui/button'
import { useNavigate } from '@tanstack/react-router'

export const Route = createFileRoute('/Adminpage')({
  component: RouteComponent,
})

function RouteComponent() {
  const navigate = useNavigate()
  return (
    <Button onClick={()=>{navigate({to:"/products"})}}>Termékek</Button>
  )
}
