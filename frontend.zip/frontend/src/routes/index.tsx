import { createFileRoute } from '@tanstack/react-router'
import { Navbar } from '@/components/Navbar'
import { NavbarLoggedIn } from '@/components/NavbarLoggedin'
import { HomepageTable } from '@/components/HomepageTable'
import { useAuthStatus } from '@/components/hooks/useAuthStatus'

export const Route = createFileRoute('/')({
  component: RouteComponent,
})

function RouteComponent() {
  const { data: user, isLoading } = useAuthStatus()
  if (isLoading) return <p>Betöltés...</p>
  
  const isLoggedIn = user

   return (
    <>
      {isLoggedIn ? <NavbarLoggedIn /> : <Navbar />}
      <div className="container mx-auto mt-8">
        {!isLoggedIn ? (
          <p>Kérlek jelentkezz be, hogy minden funkció elérhető legyen.</p>
          
        ) : (
          null
        )}
      </div>
      <HomepageTable userId={user?.userID || null}/>
    </>
    
  )

}
