"use client"

import { useState } from 'react'
import { createFileRoute } from '@tanstack/react-router'
import { Navbar } from '@/components/Navbar'
import { NavbarLoggedIn } from '@/components/NavbarLoggedin'
import { HomepageTable } from '@/components/HomepageTable'
import { useAuthStatus } from '@/components/hooks/useAuthStatus'
import { CategoryBar } from '@/components/kategoriak'

export const Route = createFileRoute('/')({
  component: RouteComponent,
})

function RouteComponent() {
  const { data: user, isLoading: authLoading } = useAuthStatus()
  
  // State a kiválasztott kategóriának: null = összes, szám = kategória ID
  const [selectedKategoria, setSelectedKategoria] = useState<number | null>(null)
  
  if (authLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <p className="text-emerald-700 animate-pulse font-medium">Betöltés...</p>
      </div>
    )
  }
  
  const isLoggedIn = !!user

  return (
    <div className="min-h-screen bg-gray-50">
      {/* 1. Navigáció a bejelentkezési állapottól függően */}
      {isLoggedIn ? <NavbarLoggedIn /> : <Navbar />}
      
      {/* 2. Kategória választó sáv 
          Átadjuk az aktuális ID-t és a függvényt, amivel módosíthatja azt */}
      <CategoryBar 
        selectedId={selectedKategoria} 
        onSelect={setSelectedKategoria} 
      />

      <main className="container mx-auto py-8 px-4">
        {/* Üdvözlő üzenet vagy bejelentkezési figyelmeztetés */}
        <div className="mb-8 text-center">
          {isLoggedIn ? (
            <h2 className="text-xl font-medium text-emerald-900">
              Üdv újra, {user.keresztnev || 'Vásárló'}!
            </h2>
          ) : (
            <div className="bg-emerald-50 border border-emerald-100 p-4 rounded-xl inline-block">
              <p className="text-emerald-800 text-sm">
                Jelentkezz be, hogy termékeket tudj kosárba tenni!
              </p>
            </div>
          )}
        </div>
        
        {/* 3. A termékeket megjelenítő táblázat/grid
            Ez a komponens fogja meghívni az új useTermekekByKategoria hookot */}
        <HomepageTable 
          userId={user?.userID || null}
          kategoriaId={selectedKategoria}
        />
      </main>

      <footer className="py-10 text-center text-gray-400 text-sm">
        <p>© 2024 Webshop - Minden jog fenntartva</p>
      </footer>
    </div>
  )
}