import { useForm } from "react-hook-form";
import z from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation } from "@tanstack/react-query";
import axios from "axios";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { KeyRound, Loader2, CheckCircle2, AlertCircle } from "lucide-react";
import { useState } from "react";

// 1. Zod séma a validációhoz
const resetPasswordSchema = z.object({
  password: z
    .string()
    .min(8, { message: "Legalább 8 karakter hosszúnak kell lennie!" })
    .regex(/[A-Z]/, { message: "Tartalmaznia kell legalább egy nagybetűt!" })
    .regex(/[a-z]/, { message: "Tartalmaznia kell legalább egy kisbetűt!" })
    .regex(/[0-9]/, { message: "Tartalmaznia kell legalább egy számot!" }),
  confirmPassword: z.string().nonempty({ message: "A megerősítés kötelező!" }),
}).refine((data) => data.password === data.confirmPassword, {
  message: "A jelszavak nem egyeznek meg!",
  path: ["confirmPassword"],
});

type ResetPasswordForm = z.infer<typeof resetPasswordSchema>;

export const Route = createFileRoute('/reset-password')({
  component: ResetPasswordPage,
})

function ResetPasswordPage() {
  const navigate = useNavigate();
  const search = Route.useSearch() as { token?: string };
  const token = search.token;

  const [isSuccess, setIsSuccess] = useState(false);

  // 2. Form inicializálása Zod-dal
  const form = useForm<ResetPasswordForm>({
    resolver: zodResolver(resetPasswordSchema),
    defaultValues: {
      password: "",
      confirmPassword: "",
    },
  });

  // 3. Mutáció a beküldéshez
  const resetMutation = useMutation({
    mutationFn: async (values: ResetPasswordForm) => {
      return axios.post("http://localhost:5000/api/auth/reset-password", {
        token,
        newPassword: values.password,
      });
    },
    onSuccess: () => {
      setIsSuccess(true);
      setTimeout(() => navigate({ to: '/' }), 4000);
    },
    onError: (error: any) => {
      const message = error.response?.data?.message || "Hiba történt a visszaállítás során.";
      form.setError("root", { message });
    },
  });

  function onSubmit(values: ResetPasswordForm) {
    if (!token) {
      form.setError("root", { message: "Érvénytelen vagy hiányzó biztonsági token!" });
      return;
    }
    resetMutation.mutate(values);
  }

  if (isSuccess) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-emerald-50/30 p-4 font-sans">
        <Card className="w-full max-w-md border-emerald-100 shadow-xl text-center p-8 animate-in fade-in zoom-in duration-300">
          <CheckCircle2 className="w-16 h-16 text-emerald-500 mx-auto mb-4" />
          <CardTitle className="text-2xl text-emerald-900 mb-2">Sikeres módosítás!</CardTitle>
          <CardDescription className="text-emerald-700">
            A jelszavadat frissítettük. Pillanatokon belül visszairányítunk a főoldalra, ahol bejelentkezhetsz az új jelszavaddal.
          </CardDescription>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-emerald-50/30 p-4 font-sans">
      <Card className="w-full max-w-md border-emerald-100 shadow-xl overflow-hidden">
        <CardHeader className="bg-emerald-600 text-white p-6">
          <CardTitle className="flex items-center gap-2 text-2xl">
            <KeyRound className="w-6 h-6" /> Új jelszó megadása
          </CardTitle>
          <CardDescription className="text-emerald-100 font-medium">
            Állíts be egy új, biztonságos jelszót a fiókodhoz.
          </CardDescription>
        </CardHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <CardContent className="p-6 space-y-4">
              
              {/* BACKEND HIBA VAGY HIÁNYZÓ TOKEN */}
              {(form.formState.errors.root || !token) && (
                <div className="bg-red-50 border border-red-200 p-3 rounded-lg flex items-center gap-2 animate-in slide-in-from-top-1">
                  <AlertCircle className="h-4 w-4 text-red-600" />
                  <p className="text-red-600 text-xs font-semibold">
                    {!token ? "Hiba: A link érvénytelen (hiányzik az azonosító token)!" : form.formState.errors.root?.message}
                  </p>
                </div>
              )}

              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-emerald-900 font-semibold">Új jelszó</FormLabel>
                    <FormControl>
                      <Input
                        type="password"
                        placeholder="••••••••"
                        className="border-emerald-100 focus-visible:ring-emerald-500 rounded-xl"
                        {...field}
                        disabled={!token || resetMutation.isPending}
                      />
                    </FormControl>
                    <FormMessage className="text-xs italic" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="confirmPassword"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-emerald-900 font-semibold">Megerősítés</FormLabel>
                    <FormControl>
                      <Input
                        type="password"
                        placeholder="••••••••"
                        className="border-emerald-100 focus-visible:ring-emerald-500 rounded-xl"
                        {...field}
                        disabled={!token || resetMutation.isPending}
                      />
                    </FormControl>
                    <FormMessage className="text-xs italic" />
                  </FormItem>
                )}
              />
            </CardContent>

            <CardFooter className="p-6 bg-emerald-50/50 border-t border-emerald-100">
              <Button 
                type="submit" 
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white h-12 rounded-xl font-bold shadow-lg transition-all"
                disabled={resetMutation.isPending || !token}
              >
                {resetMutation.isPending ? (
                  <Loader2 className="w-5 h-5 animate-spin mr-2" />
                ) : "Jelszó véglegesítése"}
              </Button>
            </CardFooter>
          </form>
        </Form>
      </Card>
    </div>
  );
}