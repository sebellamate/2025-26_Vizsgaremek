﻿using System.Text.Json.Serialization;

namespace AdminPanel_VR
{
    public struct Kategoria
    {
        [JsonPropertyName("kategoria_id")]
        public int ID { get; set; }
        [JsonPropertyName("nev")]
        public string Name { get; set; }
        [JsonPropertyName("szulo_kategoria_id")]
        public int? ParentID { get; set; }
    }
}
