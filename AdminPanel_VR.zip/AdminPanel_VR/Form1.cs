using AdminPanel;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace AdminPanel_VR
{
    public partial class Form1 : Form
    {
        ConnHandle client = new("localhost:3000/api");
        public Form1()
        {
            InitializeComponent();

            dataGridView1.Columns.Add("ID", "ID");
            dataGridView1.Columns.Add("N�v", "N�v");
            dataGridView1.Columns.Add("Le�r�s", "Le�r�s");
            dataGridView1.Columns.Add("�r", "�r");
            dataGridView1.Columns.Add("K�p URL", "K�p URL");
            dataGridView1.Columns.Add("Kateg�ria ID", "Kateg�ria ID");
            dataGridView1.Columns.Add("Sz�l� Kateg�ria ID", "Sz�l� Kateg�ria ID");
        }

        private void Clear()
        {
            while (dataGridView1.Rows.Count > 0)
                dataGridView1.Rows.RemoveAt(0);
        }

        private void CreateThis(List<Termek> items)
        {
            foreach (Termek item in items)
            {
                dataGridView1.Rows.Add(item.termek_id, item.nev, item.leiras, item.ar, item.kep_url, item.kategoria_id, item.sz_kategoria_id);
            }
        }

        private async void SendButton_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text, img_url = textBox4.Text, desc = textBox5.Text;
            decimal? cat = numericUpDown5.Value, price = numericUpDown1.Value;
            if (cat == 0) cat = null;
            HttpResponseMessage msg = await client.Post(new Content($"{{\"nev\":\"{name}\",\"leiras\":\"{desc}\",\"ar\":\"{price}\",\"kep_url\":\"{img_url}\",\"kategoria_id\":\"{cat}\"}}", "application/json"), "termekek");

            if (msg.IsSuccessStatusCode) MessageBox.Show("Created!");
            else MessageBox.Show($"POST method fail ({(int)msg.StatusCode}: {msg.StatusCode})");
        }

        private async void Button4_Click(object sender, EventArgs e)
        {
            HttpResponseMessage mes = await client.Get(textBox6.Text);
            if (!mes.IsSuccessStatusCode)
            {
                MessageBox.Show($"GET method fail ({(int)mes.StatusCode}: {mes.StatusCode})");
                return;
            }

            Stream s = mes.Content.ReadAsStream();
            byte[] b;
            await s.ReadExactlyAsync(b = new byte[s.Length], 0, (int)s.Length);
            string content = Encoding.UTF8.GetString(b);

            List<Termek>? t = new();

            try
            {
                t = JsonSerializer.Deserialize<List<Termek>>(content);
                if (t == null)
                    throw new NullReferenceException("List<Termek> is null");

                Clear();
                CreateThis(t);
            }
            catch
            {
                MessageBox.Show("Cannot GET data from specified location as a readable JSON object");
            }
            finally
            {
                await s.DisposeAsync();
            }
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            string s = $"termekek/{(int)numericUpDown2.Value}";
            HttpResponseMessage msg = await client.Delete(s);

            if (msg.IsSuccessStatusCode) MessageBox.Show("Deleted!");
            else MessageBox.Show($"DELETE method fail ({(int)msg.StatusCode}: {msg.StatusCode})");
        }

        private async void button2_Click(object sender, EventArgs e)
        {
            string s = $"termekek/{(int)numericUpDown3.Value}";

            Content cont = new($"""
{'{'}
    "nev": {textBox2.Text},
    "kategoria": {numericUpDown6.Value},
    "ar": {numericUpDown4.Value},
    "kep_url": {textBox7.Text},
    "leiras": {textBox3.Text}
{'}'}
""", "application/json");

            HttpResponseMessage msg = await client.Put(cont, s);

            if (msg.IsSuccessStatusCode) MessageBox.Show("Modified!");
            else MessageBox.Show($"PUT method fail: {(int)msg.StatusCode}: {msg.StatusCode}");
        }
    }
}
