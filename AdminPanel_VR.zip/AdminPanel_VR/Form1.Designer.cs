﻿namespace AdminPanel_VR
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listData = new TabPage();
            dataGridView1 = new DataGridView();
            GetButton = new Button();
            textBox6 = new TextBox();
            label13 = new Label();
            tabPage3 = new TabPage();
            textBox3 = new TextBox();
            textBox7 = new TextBox();
            label9 = new Label();
            label12 = new Label();
            numericUpDown6 = new NumericUpDown();
            button2 = new Button();
            label6 = new Label();
            numericUpDown4 = new NumericUpDown();
            label7 = new Label();
            label8 = new Label();
            textBox2 = new TextBox();
            numericUpDown3 = new NumericUpDown();
            label5 = new Label();
            tabPage2 = new TabPage();
            numericUpDown2 = new NumericUpDown();
            label4 = new Label();
            DeleteButton = new Button();
            tabPage1 = new TabPage();
            textBox5 = new TextBox();
            textBox4 = new TextBox();
            textBox1 = new TextBox();
            label11 = new Label();
            label10 = new Label();
            numericUpDown5 = new NumericUpDown();
            label3 = new Label();
            numericUpDown1 = new NumericUpDown();
            label2 = new Label();
            label1 = new Label();
            SendButton = new Button();
            tabControl1 = new TabControl();
            listData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown3).BeginInit();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown2).BeginInit();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            tabControl1.SuspendLayout();
            SuspendLayout();
            // 
            // listData
            // 
            listData.Controls.Add(dataGridView1);
            listData.Controls.Add(GetButton);
            listData.Controls.Add(textBox6);
            listData.Controls.Add(label13);
            listData.Location = new Point(4, 24);
            listData.Name = "listData";
            listData.Padding = new Padding(3);
            listData.Size = new Size(768, 398);
            listData.TabIndex = 4;
            listData.Text = "List Data";
            listData.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            dataGridView1.Location = new Point(8, 35);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(754, 357);
            dataGridView1.TabIndex = 4;
            // 
            // GetButton
            // 
            GetButton.Location = new Point(687, 5);
            GetButton.Name = "GetButton";
            GetButton.Size = new Size(75, 23);
            GetButton.TabIndex = 3;
            GetButton.Text = "Get";
            GetButton.UseVisualStyleBackColor = true;
            GetButton.Click += Button4_Click;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(50, 6);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(631, 23);
            textBox6.TabIndex = 2;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(8, 9);
            label13.Name = "label13";
            label13.Size = new Size(38, 15);
            label13.TabIndex = 1;
            label13.Text = "Table:";
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(textBox3);
            tabPage3.Controls.Add(textBox7);
            tabPage3.Controls.Add(label9);
            tabPage3.Controls.Add(label12);
            tabPage3.Controls.Add(numericUpDown6);
            tabPage3.Controls.Add(button2);
            tabPage3.Controls.Add(label6);
            tabPage3.Controls.Add(numericUpDown4);
            tabPage3.Controls.Add(label7);
            tabPage3.Controls.Add(label8);
            tabPage3.Controls.Add(textBox2);
            tabPage3.Controls.Add(numericUpDown3);
            tabPage3.Controls.Add(label5);
            tabPage3.Location = new Point(4, 24);
            tabPage3.Name = "tabPage3";
            tabPage3.Size = new Size(768, 398);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Modify Item";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // textBox3
            // 
            textBox3.BorderStyle = BorderStyle.FixedSingle;
            textBox3.Location = new Point(8, 169);
            textBox3.Multiline = true;
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(752, 194);
            textBox3.TabIndex = 18;
            // 
            // textBox7
            // 
            textBox7.BorderStyle = BorderStyle.FixedSingle;
            textBox7.Location = new Point(79, 123);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(681, 23);
            textBox7.TabIndex = 16;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(8, 151);
            label9.Name = "label9";
            label9.Size = new Size(70, 15);
            label9.TabIndex = 17;
            label9.Text = "Description:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(9, 125);
            label12.Name = "label12";
            label12.Size = new Size(67, 15);
            label12.TabIndex = 15;
            label12.Text = "Image URL:";
            // 
            // numericUpDown6
            // 
            numericUpDown6.BorderStyle = BorderStyle.FixedSingle;
            numericUpDown6.Location = new Point(79, 65);
            numericUpDown6.Maximum = new decimal(new int[] { int.MaxValue, 0, 0, 0 });
            numericUpDown6.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            numericUpDown6.Name = "numericUpDown6";
            numericUpDown6.Size = new Size(681, 23);
            numericUpDown6.TabIndex = 14;
            numericUpDown6.UpDownAlign = LeftRightAlignment.Left;
            numericUpDown6.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // button2
            // 
            button2.Location = new Point(687, 369);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 13;
            button2.Text = "Modify";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(37, 96);
            label6.Name = "label6";
            label6.Size = new Size(36, 15);
            label6.TabIndex = 12;
            label6.Text = "Price:";
            // 
            // numericUpDown4
            // 
            numericUpDown4.BorderStyle = BorderStyle.FixedSingle;
            numericUpDown4.DecimalPlaces = 2;
            numericUpDown4.Increment = new decimal(new int[] { 1, 0, 0, 131072 });
            numericUpDown4.Location = new Point(79, 94);
            numericUpDown4.Maximum = new decimal(new int[] { int.MaxValue, 0, 0, 0 });
            numericUpDown4.Name = "numericUpDown4";
            numericUpDown4.Size = new Size(681, 23);
            numericUpDown4.TabIndex = 11;
            numericUpDown4.UpDownAlign = LeftRightAlignment.Left;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(15, 67);
            label7.Name = "label7";
            label7.Size = new Size(58, 15);
            label7.TabIndex = 9;
            label7.Text = "Category:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(31, 38);
            label8.Name = "label8";
            label8.Size = new Size(42, 15);
            label8.TabIndex = 8;
            label8.Text = "Name:";
            // 
            // textBox2
            // 
            textBox2.BorderStyle = BorderStyle.FixedSingle;
            textBox2.Location = new Point(79, 36);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(681, 23);
            textBox2.TabIndex = 7;
            // 
            // numericUpDown3
            // 
            numericUpDown3.Location = new Point(79, 6);
            numericUpDown3.Maximum = new decimal(new int[] { -1, -1, -1, 0 });
            numericUpDown3.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            numericUpDown3.Name = "numericUpDown3";
            numericUpDown3.Size = new Size(681, 23);
            numericUpDown3.TabIndex = 4;
            numericUpDown3.UpDownAlign = LeftRightAlignment.Left;
            numericUpDown3.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(52, 8);
            label5.Name = "label5";
            label5.Size = new Size(21, 15);
            label5.TabIndex = 3;
            label5.Text = "ID:";
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(numericUpDown2);
            tabPage2.Controls.Add(label4);
            tabPage2.Controls.Add(DeleteButton);
            tabPage2.Location = new Point(4, 24);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(768, 398);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Delete Item";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // numericUpDown2
            // 
            numericUpDown2.Location = new Point(35, 6);
            numericUpDown2.Maximum = new decimal(new int[] { -1, -1, -1, 0 });
            numericUpDown2.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            numericUpDown2.Name = "numericUpDown2";
            numericUpDown2.Size = new Size(725, 23);
            numericUpDown2.TabIndex = 2;
            numericUpDown2.UpDownAlign = LeftRightAlignment.Left;
            numericUpDown2.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(8, 8);
            label4.Name = "label4";
            label4.Size = new Size(21, 15);
            label4.TabIndex = 1;
            label4.Text = "ID:";
            // 
            // DeleteButton
            // 
            DeleteButton.Location = new Point(687, 369);
            DeleteButton.Name = "DeleteButton";
            DeleteButton.Size = new Size(75, 23);
            DeleteButton.TabIndex = 0;
            DeleteButton.Text = "Delete";
            DeleteButton.UseVisualStyleBackColor = true;
            DeleteButton.Click += button1_Click;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(textBox5);
            tabPage1.Controls.Add(textBox4);
            tabPage1.Controls.Add(textBox1);
            tabPage1.Controls.Add(label11);
            tabPage1.Controls.Add(label10);
            tabPage1.Controls.Add(numericUpDown5);
            tabPage1.Controls.Add(label3);
            tabPage1.Controls.Add(numericUpDown1);
            tabPage1.Controls.Add(label2);
            tabPage1.Controls.Add(label1);
            tabPage1.Controls.Add(SendButton);
            tabPage1.Location = new Point(4, 24);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(768, 398);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Add Item";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // textBox5
            // 
            textBox5.BorderStyle = BorderStyle.FixedSingle;
            textBox5.Location = new Point(8, 140);
            textBox5.Multiline = true;
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(752, 223);
            textBox5.TabIndex = 11;
            // 
            // textBox4
            // 
            textBox4.BorderStyle = BorderStyle.FixedSingle;
            textBox4.Location = new Point(79, 94);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(681, 23);
            textBox4.TabIndex = 9;
            // 
            // textBox1
            // 
            textBox1.BorderStyle = BorderStyle.FixedSingle;
            textBox1.Location = new Point(79, 7);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(681, 23);
            textBox1.TabIndex = 1;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(6, 122);
            label11.Name = "label11";
            label11.Size = new Size(70, 15);
            label11.TabIndex = 10;
            label11.Text = "Description:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(6, 96);
            label10.Name = "label10";
            label10.Size = new Size(67, 15);
            label10.TabIndex = 8;
            label10.Text = "Image URL:";
            // 
            // numericUpDown5
            // 
            numericUpDown5.BorderStyle = BorderStyle.FixedSingle;
            numericUpDown5.Location = new Point(79, 36);
            numericUpDown5.Maximum = new decimal(new int[] { 65535, 0, 0, 0 });
            numericUpDown5.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            numericUpDown5.Name = "numericUpDown5";
            numericUpDown5.Size = new Size(681, 23);
            numericUpDown5.TabIndex = 7;
            numericUpDown5.UpDownAlign = LeftRightAlignment.Left;
            numericUpDown5.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(37, 67);
            label3.Name = "label3";
            label3.Size = new Size(36, 15);
            label3.TabIndex = 6;
            label3.Text = "Price:";
            // 
            // numericUpDown1
            // 
            numericUpDown1.BorderStyle = BorderStyle.FixedSingle;
            numericUpDown1.DecimalPlaces = 2;
            numericUpDown1.Increment = new decimal(new int[] { 1, 0, 0, 131072 });
            numericUpDown1.Location = new Point(79, 65);
            numericUpDown1.Maximum = new decimal(new int[] { int.MaxValue, 0, 0, 0 });
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(681, 23);
            numericUpDown1.TabIndex = 5;
            numericUpDown1.UpDownAlign = LeftRightAlignment.Left;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(15, 38);
            label2.Name = "label2";
            label2.Size = new Size(58, 15);
            label2.TabIndex = 3;
            label2.Text = "Category:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(31, 9);
            label1.Name = "label1";
            label1.Size = new Size(42, 15);
            label1.TabIndex = 2;
            label1.Text = "Name:";
            // 
            // SendButton
            // 
            SendButton.Location = new Point(687, 369);
            SendButton.Name = "SendButton";
            SendButton.Size = new Size(75, 23);
            SendButton.TabIndex = 0;
            SendButton.Text = "Create";
            SendButton.UseVisualStyleBackColor = true;
            SendButton.Click += SendButton_Click;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Controls.Add(listData);
            tabControl1.Location = new Point(0, 0);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(776, 426);
            tabControl1.TabIndex = 0;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(776, 424);
            Controls.Add(tabControl1);
            Name = "Form1";
            Text = "Form1";
            listData.ResumeLayout(false);
            listData.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown6).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown4).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown3).EndInit();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown2).EndInit();
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown5).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            tabControl1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TabPage listData;
        private DataGridView dataGridView1;
        private Button GetButton;
        private TextBox textBox6;
        private Label label13;
        private TabPage tabPage3;
        private Button button2;
        private Label label6;
        private NumericUpDown numericUpDown4;
        private Label label7;
        private Label label8;
        private TextBox textBox2;
        private NumericUpDown numericUpDown3;
        private Label label5;
        private TabPage tabPage2;
        private NumericUpDown numericUpDown2;
        private Label label4;
        private Button DeleteButton;
        private TabPage tabPage1;
        private TextBox textBox5;
        private TextBox textBox4;
        private TextBox textBox1;
        private Label label11;
        private Label label10;
        private NumericUpDown numericUpDown5;
        private Label label3;
        private NumericUpDown numericUpDown1;
        private Label label2;
        private Label label1;
        private Button SendButton;
        private TabControl tabControl1;
        private NumericUpDown numericUpDown6;
        private TextBox textBox3;
        private TextBox textBox7;
        private Label label9;
        private Label label12;
    }
}
