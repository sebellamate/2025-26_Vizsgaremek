using System.Text.Json.Serialization;

namespace AdminPanel_VR
{
    public struct Termek
    {
        [JsonPropertyName("termek_id")]
        public int? termek_id { get; set; }

        [JsonPropertyName("nev")]
        public string? nev { get; set; }

        [JsonPropertyName("leiras")]
        public string? leiras { get; set; }

        [JsonPropertyName("ar")]
        public string? ar { get; set; }

        [JsonPropertyName("kep_url")]
        public string? kep_url { get; set; }

        [JsonPropertyName("kategoria_id")]
        public int? kategoria_id { get; set; }

        [JsonPropertyName("szulo_kategoria_id")]
        public int? sz_kategoria_id { get; set; }

        public override string ToString()
        {
            string part = leiras.Length > 20 ? string.Concat(leiras.AsSpan(0, 20), "...") : leiras;

            return $"ID = {termek_id} | {nev} {ar} @ {kategoria_id ?? '-'}({sz_kategoria_id ?? '-'}) | img = {kep_url}, desc = {part}";
        }
    }
}
