﻿using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;

namespace AdminPanel
{
    public class ConnHandle
    {
        private readonly HttpClient Client;
        public  readonly string     BaseURL;

        public ConnHandle(string addr)
        {
            BaseURL = $"http://{addr}".Trim();
            if(!BaseURL.EndsWith('/')) BaseURL += "/";
            Client = new()
            {
                BaseAddress = new Uri(BaseURL)
            };
            // this is required for some reason
        }

        public async Task<HttpResponseMessage> Get(string subaddr = "")
        {
            return await Client.GetAsync(subaddr, HttpCompletionOption.ResponseContentRead);
        }

        public async Task<HttpResponseMessage> Post(HttpContent data, string subaddr = "")
        {
            return await Client.PostAsync(subaddr, data);
        }

        public async Task<HttpResponseMessage> Delete(string subaddr = "")
        {
            return await Client.DeleteAsync(subaddr);
        }

        public async Task<HttpResponseMessage> Patch(HttpContent data, string subaddr = "")
        {
            return await Client.PatchAsync(subaddr, data).ConfigureAwait(false);
        }

        public async Task<HttpResponseMessage> PatchJson(HttpContent data, string subaddr = "")
        {
            return await Client.PatchAsJsonAsync(subaddr, data).ConfigureAwait(false);
        }

        public async Task<HttpResponseMessage> Put(Content cont, string v)
        {
            return await Client.PutAsync(v, cont);
        }

        public async Task<HttpResponseMessage> PutJson<T>(T cont, string v)
        {
            return await Client.PutAsJsonAsync(v, cont);
        }
    }

    public class Content : HttpContent
    {
        private readonly string _data;
        private byte[] bytedata;

        public Content(string data, string? ctype = null)
        {
            _data = data;
            bytedata = Encoding.UTF8.GetBytes(_data);
            Headers.ContentLength = data.Length;
            if (ctype != null)
                Headers.ContentType = new MediaTypeHeaderValue(ctype);
        }

        protected override bool TryComputeLength(out long length)
        {
            length = bytedata.Length;
            return length != 0;
        }

        protected override Task SerializeToStreamAsync(Stream stream, TransportContext? context)
            => stream.WriteAsync(bytedata).AsTask();

        protected override Task SerializeToStreamAsync(Stream stream, TransportContext? context, CancellationToken cancellationToken)
            => stream.WriteAsync(bytedata, cancellationToken).AsTask();

        protected override void SerializeToStream(Stream stream, TransportContext? context, CancellationToken cancellationToken)
            => stream.Write(bytedata);

        protected override Task<Stream> CreateContentReadStreamAsync()
            => Task.FromResult<Stream>(new MemoryStream(bytedata));

        protected override Task<Stream> CreateContentReadStreamAsync(CancellationToken cancellationToken)
            => Task.FromResult<Stream>(new MemoryStream(bytedata)).WaitAsync(cancellationToken);

        protected override Stream CreateContentReadStream(CancellationToken cancellationToken)
            => new MemoryStream(bytedata);
    }

    class Program{static void Main(){}} // necessary because im stupid
}