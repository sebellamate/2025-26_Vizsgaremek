DELETE FROM termek;
DELETE FROM kategoria;

INSERT INTO kategoria (kategoria_id, nev) VALUES
(1, 'Telefon'),
(2, 'Laptop'),
(3, 'TV'),
(4, 'Egér');

INSERT INTO termek (termek_id, nev, leiras, ar, kep_url, kategoria_id, akcio) VALUES
(1, 'Apple iPhone 14 Pro Max 256GB', '6.7 hüvelykes Super Retina XDR kijelző, A16 Bionic chip, 48 MP-es fő kamera.', 520000.00, 'iphone14.webp', 1, 0),
(2, 'Samsung Galaxy S24 Ultra 512GB', 'Titán keret, Snapdragon 8 Gen 3 processzor, beépített S Pen és 200 MP kamera.', 580000.00, 's24ultra.webp', 1, 10),
(3, 'Google Pixel 8 Pro 128GB', 'Tiszta Android élmény, Google Tensor G3 chip és kiemelkedő AI fotós funkciók.', 390000.00, 'google8pro.webp', 1, 5),
(4, 'Xiaomi 14 256GB', 'Kompakt csúcsmobil Leica lencsékkel, 120Hz AMOLED kijelzővel és 90W gyorstöltéssel.', 350000.00, 'xiaomi14.webp', 1, 0),

(5, 'Apple MacBook Pro 14" (M3 Pro)', 'M3 Pro chip 11 magos CPU-val, 14 magos GPU-val, 18GB RAM, 512GB SSD.', 950000.00, 'macbook.webp', 2, 0),
(6, 'Dell XPS 15 (9530)', '15.6" OLED érintőkijelző, Intel Core i7-13700H, 32GB RAM, NVIDIA RTX 4060.', 890000.00, 'dellxps.webp', 2, 0),
(7, 'Lenovo ThinkPad X1 Carbon Gen 11', 'Ultrakönnyű üzleti laptop, Intel Core i5, 16GB RAM, kiváló billentyűzet.', 720000.00, 'lenovothinkpad.webp', 2, 15),
(8, 'ASUS ROG Zephyrus G14', 'Kompakt gamer laptop, AMD Ryzen 9, 16GB RAM, NVIDIA RTX 4070, 165Hz kijelző.', 680000.00, 'asusrog.webp', 2, 8),

(9, 'LG OLED65C31LA 65" 4K Smart TV', 'Evo OLED technológia, tökéletes fekete, 120Hz képfrissítés és WebOS rendszer.', 550000.00, 'lgoled.webp', 3, 20),
(10, 'Samsung QE65QN90C 65" Neo QLED', 'Kivételes fényerő a Mini LED technológiának köszönhetően, 4K felbontás.', 480000.00, 'samsungqled.webp', 3, 0),
(11, 'Sony Bravia XR-55A95L 55" QD-OLED', 'A Sony csúcsmodellje QD-OLED panellel és Cognitive Processor XR vezérléssel.', 850000.00, 'sonybravia.webp', 3, 0),
(12, 'Philips 55OLED808 55" Ambilight', '4K OLED TV a lenyűgöző 3 oldalas Ambilight háttérvilágítással.', 450000.00, 'philipsambilight.webp', 3, 10),

(13, 'Logitech MX Master 3S', 'Prémium ergonomikus vezeték nélküli egér, halk kattintásokkal, MagSpeed görgővel.', 45000.00, 'logitechmouse.webp', 4, 0),
(14, 'Razer DeathAdder V3 Pro', 'Ultrakönnyű, vezeték nélküli e-sport gamer egér, Focus Pro 30K optikai szenzorral.', 60000.00, 'deathadderv3.webp', 4, 5),
(15, 'SteelSeries Rival 5', 'Sokoldalú, vezetékes gamer egér 9 programozható gombbal és PrismSync RGB-vel.', 22000.00, 'steelseries.webp', 4, 0),
(16, 'Apple Magic Mouse', 'Letisztult dizájn, Multi-Touch felület, újratölthető akkumulátor, fehér színben.', 35000.00, 'magicmouse.webp', 4, 0);