"use client"

import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
} from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useTermekekByKategoria } from "./hooks/useTermekekByKategoria"; 
import { Link } from "@tanstack/react-router";
import { ShoppingCart, Eye, Lock } from "lucide-react";
import { useTetelPost } from '../components/hooks/useTetelpost';
import { Footer } from "./Footer";

type HomepageTableProps = {
  userId: number | null;
  kategoriaId: number | null;
}

export function HomepageTable({ userId, kategoriaId }: HomepageTableProps) {
  const { data: termekek, isLoading } = useTermekekByKategoria(kategoriaId);
  const isLoggedIn = !!userId;
  
  const { createTetel, isPending } = useTetelPost();

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-700" />
        <p className="text-emerald-800 font-medium animate-pulse">Termékek válogatása...</p>
      </div>
    );
  }

  const termekLista = Array.isArray(termekek) ? termekek : termekek?.data || [];

  return (
    <div className="p-8 bg-slate-50/30 min-h-screen">
      <h1 className="text-4xl font-black mb-10 text-center text-emerald-900 tracking-tight">
        {kategoriaId ? "Kategória ajánlatai" : "Kiemelt termékek"}
      </h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {termekLista.map((t: any) => {
          const akcioErtek = Number(t.akcio) || 0;
          const alapAr = Number(t.ar) || 0;

          const vanAkcio = akcioErtek > 0;
          const akciosAr = vanAkcio 
            ? Math.round(alapAr * (1 - akcioErtek / 100)) 
            : alapAr;

          return (
            <Card key={t.termek_id} className="group hover:shadow-2xl hover:-translate-y-1.5 transition-all duration-500 border border-slate-200/80 shadow-md rounded-2xl overflow-hidden bg-white flex flex-col h-full relative">
              
              {vanAkcio && (
                <div className="absolute top-4 left-4 z-20">
                  <Badge className="bg-red-500 hover:bg-red-600 text-white font-bold shadow-lg border-none px-3 py-1.5 text-sm tracking-wide">
                    -{akcioErtek}%
                  </Badge>
                </div>
              )}

              <Link 
                to="/products/$id" 
                params={{ id: t.termek_id.toString() }}
                className="cursor-pointer flex flex-col flex-1 group"
              >
                <div className="relative overflow-hidden h-60 bg-white p-6 flex items-center justify-center border-b border-slate-50 shrink-0">
                  <img
                    src={`/kepek/${t.kep_url}`}
                    className="h-full w-full object-contain drop-shadow-md transform group-hover:scale-110 transition-transform duration-700 ease-in-out"
                    alt={t.nev}
                  />
                  <div className="absolute inset-0 bg-emerald-900/0 group-hover:bg-emerald-900/5 transition-colors duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100 z-10">
                     <div className="bg-white/95 p-3 rounded-full shadow-2xl transform scale-50 group-hover:scale-100 transition-transform duration-300">
                        <Eye className="w-6 h-6 text-emerald-700" />
                     </div>
                  </div>
                </div>

                <CardContent className="p-6 flex flex-col flex-1">
                  <h3 className="text-xl font-bold text-slate-800 mb-2 group-hover:text-emerald-700 transition-colors line-clamp-1" title={t.nev}>
                    {t.nev}
                  </h3>
                  <p className="text-sm text-slate-500 line-clamp-2 mb-4 h-10 leading-relaxed">
                    {t.leiras}
                  </p>
                  
                  <div className="mt-auto flex flex-col justify-end h-14">
                    {vanAkcio ? (
                      <div>
                        <span className="text-sm text-slate-400 line-through block font-medium">
                          {alapAr.toLocaleString("hu-HU")} Ft
                        </span>
                        <span className="font-black text-emerald-700 text-2xl tracking-tight">
                          {akciosAr.toLocaleString("hu-HU")} Ft
                        </span>
                      </div>
                    ) : (
                      <span className="font-black text-emerald-700 text-2xl tracking-tight">
                        {alapAr.toLocaleString("hu-HU")} Ft
                      </span>
                    )}
                  </div>
                </CardContent>
              </Link>

              <div className="p-6 pt-0 mt-auto">
                {isLoggedIn ? (
                  <Button
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl h-12 shadow-md shadow-emerald-200/50 transform active:scale-95 transition-all flex gap-2 items-center justify-center"
                    onClick={(e) => {
                      e.preventDefault(); 
                      createTetel({ termek_id: t.termek_id })
                    }}
                    disabled={isPending}
                  >
                    <ShoppingCart className="w-5 h-5" />
                    {isPending ? "Hozzáadás..." : "Kosárba teszem"}
                  </Button>
                ) : (
                  <div className="w-full h-12 flex items-center justify-center gap-2 border-2 border-dashed border-slate-300 bg-slate-50/80 rounded-xl text-slate-500 transition-colors hover:bg-slate-100">
                    <Lock className="w-4 h-4" />
                    <span className="text-sm font-bold">Jelentkezz be!</span>
                  </div>
                )}
              </div>
            </Card>
          );
        })}
      </div>

      {termekLista.length === 0 && (
        <div className="flex flex-col items-center justify-center py-20 text-slate-400 bg-white rounded-3xl border border-dashed border-slate-200 mt-8 shadow-sm">
           <ShoppingCart className="w-20 h-20 mb-6 opacity-20" />
           <p className="text-xl font-medium text-slate-500">Nincs megjeleníthető termék ebben a kategóriában.</p>
           <p className="text-sm mt-2">Próbálj meg egy másik kategóriát választani!</p>
        </div>
      )}
      <Footer />
    </div>
    
  );
}