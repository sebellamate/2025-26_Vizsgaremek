"use client"

import { Link } from "@tanstack/react-router"
import { RegistrationDialog } from "./Registrationdialog"
import { LoginDialog } from "./Logindialog"
import SearchEngine from "./searchengine"

export function Navbar() {
  const isLoggedIn = false; 

  return (
    <header className="border-b bg-background sticky top-0 z-50">
      <div className="container mx-auto flex h-16 items-center justify-between px-4 gap-6">
        
        <div className="flex items-center gap-6 flex-1">
          <Link to="/" className="text-2xl font-black tracking-tighter text-emerald-950 shrink-0">
            webshop
          </Link>

          <div className="w-full max-w-md hidden md:block">
            <SearchEngine />
          </div>
        </div>

        <div className="flex items-center gap-4">
          {!isLoggedIn ? (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-2xl bg-emerald-50/50 border border-emerald-100/50">
              
              <LoginDialog />
              <div className="h-6 w-[1px] bg-emerald-200 mx-1" /> 
              <RegistrationDialog />
            </div>
          ) : (
            <div className="flex items-center gap-4">
               <span className="text-sm font-medium">Szia, Felhasználó!</span>
            </div>
          )}
        </div>

      </div>

      <div className="md:hidden px-4 pb-3">
        <SearchEngine />
      </div>
    </header>
  )
}