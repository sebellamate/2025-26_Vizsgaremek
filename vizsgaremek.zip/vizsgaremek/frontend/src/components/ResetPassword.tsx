import { useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { useMutation } from "@tanstack/react-query";
import axios from "axios";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { KeyRound, Loader2, CheckCircle2 } from "lucide-react";

export default function ResetPasswordPage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const token = searchParams.get("token");

  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isSuccess, setIsSuccess] = useState(false);

  const resetMutation = useMutation({
    mutationFn: async (newPassword: string) => {
      return axios.post("http://localhost:5000/api/auth/reset-password", {
        token,
        newPassword,
      });
    },
    onSuccess: () => {
      setIsSuccess(true);
      toast.success("Jelszó sikeresen megváltoztatva!");
      setTimeout(() => navigate("/"), 3000);
    },
    onError: (error: any) => {
      toast.error(error.response?.data?.message || "Hiba történt a visszaállítás során.");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!token) {
      toast.error("Hiányzó vagy érvénytelen token!");
      return;
    }

    if (password.length < 8) {
      toast.error("A jelszónak legalább 8 karakternek kell lennie!");
      return;
    }

    if (password !== confirmPassword) {
      toast.error("A két jelszó nem egyezik meg!");
      return;
    }

    resetMutation.mutate(password);
  };

  if (isSuccess) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-emerald-50/30 p-4">
        <Card className="w-full max-w-md border-emerald-100 shadow-xl text-center p-8">
          <CheckCircle2 className="w-16 h-16 text-emerald-500 mx-auto mb-4" />
          <CardTitle className="text-2xl text-emerald-900 mb-2">Sikeres módosítás!</CardTitle>
          <CardDescription>
            A jelszavadat frissítettük. Pillanatokon belül átirányítunk a kezdőlapra...
          </CardDescription>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-emerald-50/30 p-4">
      <Card className="w-full max-w-md border-emerald-100 shadow-xl overflow-hidden">
        <CardHeader className="bg-emerald-600 text-white p-6">
          <CardTitle className="flex items-center gap-2 text-2xl">
            <KeyRound className="w-6 h-6" /> Új jelszó megadása
          </CardTitle>
          <CardDescription className="text-emerald-100">
            Kérjük, add meg az új jelszavadat az azonosításhoz.
          </CardDescription>
        </CardHeader>

        <form onSubmit={handleSubmit}>
          <CardContent className="p-6 space-y-4">
            {!token && (
              <div className="p-3 bg-red-50 text-red-600 rounded-md text-sm mb-4">
                Figyelem: Nem található érvényes azonosító token az URL-ben!
              </div>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="new-password">Új jelszó</Label>
              <Input
                id="new-password"
                type="password"
                placeholder="••••••••"
                className="border-emerald-100 focus-visible:ring-emerald-500"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirm-password">Új jelszó megerősítése</Label>
              <Input
                id="confirm-password"
                type="password"
                placeholder="••••••••"
                className="border-emerald-100 focus-visible:ring-emerald-500"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
              />
            </div>
          </CardContent>

          <CardFooter className="p-6 bg-emerald-50/50 border-t border-emerald-100">
            <Button 
              type="submit" 
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white h-11"
              disabled={resetMutation.isPending || !token}
            >
              {resetMutation.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
              ) : "Jelszó véglegesítése"}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
}