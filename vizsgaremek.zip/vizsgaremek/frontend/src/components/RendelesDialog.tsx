import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "./ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState, useMemo } from "react";
import { useCreateOrder } from "./hooks/useCreateOrder";
import { useUserCoupons } from "./hooks/useUserCoupons";
import { PackageCheck, Truck, Loader2, Ticket } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

type RendelesDialogProps = {
  userId: number;
  vegosszeg: number;
  kosartetelek: any[];
  termekek: any[];
  onSuccess: () => void;
};

export function RendelesDialog({ userId, vegosszeg, kosartetelek, termekek, onSuccess }: RendelesDialogProps) {
  const [open, setOpen] = useState(false);
  const [cim, setCim] = useState("");
  const [valasztottKuponId, setValasztottKuponId] = useState<string>("none");
  
  const { mutateAsync: createRendelesAsync, isPending } = useCreateOrder();
  const { data: coupons } = useUserCoupons(userId);

  const ervenyesKuponok = useMemo(() => {
    if (!coupons || !Array.isArray(coupons)) return [];
    return coupons.filter((k: any) => k && k.kupon_id != null && k.ervenyes !== false);
  }, [coupons]);

  const aktualisKupon = useMemo(() => {
    if (valasztottKuponId === "none") return null;
    return ervenyesKuponok.find((k: any) => k.kupon_id.toString() === valasztottKuponId);
  }, [valasztottKuponId, ervenyesKuponok]);

  const kedvezmenyesOsszeg = useMemo(() => {
    if (!aktualisKupon) return vegosszeg;
    const levonas = vegosszeg * (aktualisKupon.szazalek / 100);
    return Math.round(vegosszeg - levonas);
  }, [vegosszeg, aktualisKupon]);

  const handleRendelesLeadasa = async () => {
    if (!cim.trim()) return alert("Kérjük, adja meg a szállítási címet!");

    const tetelek = (kosartetelek || []).map((kt) => {
      const termekInfo = termekek?.find((t) => t.termek_id === kt.termek_id);
      const ar = termekInfo?.akcio > 0 
        ? Math.round(termekInfo.ar * (1 - termekInfo.akcio / 100)) 
        : (termekInfo?.ar || 0);

      return {
        termek_id: Number(kt.termek_id),
        mennyiseg: Number(kt.mennyiseg),
        egyseg_ar: Number(ar), 
      };
    });

    try {
      await createRendelesAsync({
        user_id: Number(userId),
        osszeg: Number(kedvezmenyesOsszeg), 
        cim: cim,
        tetelek: tetelek,
        kupon_id: valasztottKuponId === "none" ? null : Number(valasztottKuponId),
      });
      alert("Sikeres rendelés!");
      setOpen(false);
      onSuccess();
    } catch (error: any) {
      console.error("Rendelési hiba:", error.response?.data);
      alert("Hiba történt a rendelés során!");
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-6 px-8 rounded-xl flex gap-2 items-center">
          <PackageCheck className="w-5 h-5" /> Pénztár
        </Button>
      </DialogTrigger>

      <DialogContent className="sm:max-w-[450px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-emerald-900 font-bold">
            <Truck className="w-6 h-6 text-emerald-600" /> Rendelés véglegesítése
          </DialogTitle>
        </DialogHeader>

        <div className="grid gap-5 py-4">
          <div className="space-y-2">
            <Label className="font-semibold">Szállítási cím</Label>
            <Input 
              placeholder="Város, utca, házszám..." 
              value={cim} 
              onChange={(e) => setCim(e.target.value)} 
              disabled={isPending}
            />
          </div>

          <div className="space-y-2">
            <Label className="flex items-center gap-2 font-semibold">
              <Ticket className="w-4 h-4 text-emerald-600" /> Elérhető kuponok
            </Label>
            <Select onValueChange={setValasztottKuponId} value={valasztottKuponId} disabled={isPending}>
              <SelectTrigger className="border-emerald-100">
                <SelectValue placeholder="Válassz kupont" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Nem használok kupont</SelectItem>
                {ervenyesKuponok.map((kupon: any) => (
                  <SelectItem key={kupon.kupon_id.toString()} value={kupon.kupon_id.toString()}>
                    <span className="font-medium text-emerald-700">{kupon.szazalek}% kedvezmény</span>
                    <span className="ml-2 text-gray-400 text-xs">({kupon.kod})</span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-100 space-y-2">
            <div className="flex justify-between text-sm text-emerald-800">
              <span>Eredeti összeg:</span>
              <span>{vegosszeg.toLocaleString()} Ft</span>
            </div>
            {aktualisKupon && (
              <div className="flex justify-between text-sm text-emerald-600 font-bold">
                <span>Kupon kedvezmény ({aktualisKupon.szazalek}%):</span>
                <span>-{ (vegosszeg - kedvezmenyesOsszeg).toLocaleString() } Ft</span>
              </div>
            )}
            <div className="flex justify-between text-xl font-black text-emerald-900 border-t border-emerald-200 mt-2 pt-2">
              <span>Fizetendő:</span>
              <span>{kedvezmenyesOsszeg.toLocaleString()} Ft</span>
            </div>
          </div>
        </div>

        <DialogFooter className="flex gap-2">
          <Button variant="outline" onClick={() => setOpen(false)} disabled={isPending}>Mégse</Button>
          <Button 
            onClick={handleRendelesLeadasa} 
            disabled={isPending || !cim.trim()} 
            className="bg-emerald-700 hover:bg-emerald-800"
          >
            {isPending ? <Loader2 className="animate-spin" /> : "Rendelés leadása"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}