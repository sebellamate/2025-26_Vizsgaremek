import { useState, useEffect, useRef } from "react";
import { useNavigate } from "@tanstack/react-router";
import axios from "axios";

type SearchResult = {
  termek_id: number;
  nev: string;
  leiras: string;
  ar: string;
  kep_url: string;
  kategoria_id: number;
};

const SearchEngine = () => {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<SearchResult[]>([]);
  const [showDropdown, setShowDropdown] = useState(false);
  const navigate = useNavigate();
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fetchSuggestions = async () => {
      if (query.length < 2) {
        setResults([]);
        return;
      }
      try {
        const response = await axios.get<SearchResult[]>(
          `http://localhost:5000/api/termekek/kerestermek/${query}`
        );
        setResults(response.data);
      } catch (err) {
        console.error("Hiba a javaslatok betöltésekor", err);
      }
    };

    fetchSuggestions();
  }, [query]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSearchClick = () => {
    if (!query || results.length === 0) return;
    const ids = results.map((item) => item.termek_id).join(",");
    navigate({
      to: "/search/$id",
      params: { id: ids },
    });
    setShowDropdown(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSearchClick();
    }
  };

  return (
    <div className="relative w-full max-w-md" ref={dropdownRef}>
      <div className="flex items-center gap-2 p-1 bg-emerald-900/10 rounded-full border border-emerald-500/20 shadow-sm focus-within:ring-2 focus-within:ring-emerald-500 transition-all">
        <span className="pl-4 text-emerald-600">🔍</span>
        <input
          type="text"
          placeholder="Keresés..."
          className="flex-1 bg-transparent border-none outline-none px-2 py-2 text-emerald-900 placeholder-emerald-600/50"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setShowDropdown(true);
          }}
          onFocus={() => setShowDropdown(true)}
          onKeyDown={handleKeyDown} 
        />
      </div>

      {showDropdown && query.length >= 2 && (
        <div className="absolute top-full left-0 w-full mt-2 bg-white border border-emerald-100 rounded-xl shadow-xl z-50 overflow-hidden animate-in fade-in slide-in-from-top-2">
          {results.length > 0 ? (
            <ul className="max-h-60 overflow-y-auto">
              {results.slice(0, 5).map((item) => (
                <li
                  key={item.termek_id}
                  onClick={() => {
                    setQuery(item.nev);
                    setShowDropdown(false);
                    navigate({
                        to: "/search/$id",
                        params: { id: item.termek_id.toString() },
                    });
                  }}
                  className="px-4 py-3 hover:bg-emerald-50 cursor-pointer flex items-center justify-between group transition-colors border-b border-emerald-50 last:border-none"
                >
                  <span className="text-emerald-900 font-medium group-hover:text-emerald-700">{item.nev}</span>
                  <span className="text-xs text-emerald-500 font-bold">{item.ar} Ft</span>
                </li>
              ))}
            </ul>
          ) : (
            <div className="p-4 text-sm text-emerald-600 italic">Nincs találat...</div>
          )}
          
          {results.length > 0 && (
            <div
              onClick={handleSearchClick}
              className="bg-emerald-50 p-2 text-center text-xs font-bold text-emerald-700 cursor-pointer hover:bg-emerald-100 uppercase tracking-tighter"
            >
              Összes találat megtekintése ({results.length})
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SearchEngine;