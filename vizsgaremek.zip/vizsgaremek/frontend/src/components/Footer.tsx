"use client"

import { Mail, Phone, Globe } from "lucide-react"

export function Footer() {
  return (
    <footer className="border-t bg-white mt-auto">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          
          <div className="flex flex-col items-center md:items-start gap-1">
            <span className="text-xl font-black tracking-tighter text-emerald-950">
              webshop
            </span>
            <p className="text-xs text-slate-500 font-medium">
              © 2026 Minden jog fenntartva.
            </p>
          </div>

          <div className="flex flex-wrap justify-center gap-6">
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <Phone className="w-4 h-4 text-emerald-600" />
              <span>+36 30 000 0000</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <Mail className="w-4 h-4 text-emerald-600" />
              <span>info@webshop2026.hu</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <Globe className="w-4 h-4 text-emerald-600" />
              <span>Magyarország</span>
            </div>
          </div>


        </div>
      </div>
    </footer>
  )
}