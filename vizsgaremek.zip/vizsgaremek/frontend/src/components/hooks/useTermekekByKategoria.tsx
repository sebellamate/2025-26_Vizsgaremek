import { useQuery } from "@tanstack/react-query";
import axios from "axios";

export function useTermekekByKategoria(kategoriaId: number | null) {
  return useQuery({
    queryKey: ["termekek", "kategoria", kategoriaId],
    queryFn: async () => {
      const url = kategoriaId 
        ? `http://localhost:5000/api/termekek/kategoria/${kategoriaId}`
        : "http://localhost:5000/api/termekek";
        
      const response = await axios.get(url);
      return response.data;
    },
    enabled: true, 
  });
}