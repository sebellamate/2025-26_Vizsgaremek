import { useMutation, useQueryClient } from '@tanstack/react-query'
import axios from 'axios'

type OrderItem = {
  termek_id: number;
  mennyiseg: number;
  egyseg_ar: number;
}

type OrderData = {
  user_id: number;      
  osszeg: number;
  cim: string; 
  tetelek: OrderItem[];
  kupon_id: string | number | null; 
}

const postOrder = async (orderData: OrderData) => {
  const response = await axios.post('http://localhost:5000/api/rendeles', orderData, {
    withCredentials: true,
  })
  return response.data
}

export function useCreateOrder() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: postOrder,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['status'] })
      queryClient.invalidateQueries({ queryKey: ['kosar_tetelek'] })
    },
    onError: (error: any) => {
      console.error('Hiba a rendelés során:', error.response?.data || error.message)
    }
  })
}