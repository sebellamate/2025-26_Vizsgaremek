"use client"

import { useState } from 'react'
import { createFileRoute } from '@tanstack/react-router'
import { Navbar } from '@/components/Navbar'
import { NavbarLoggedIn } from '@/components/NavbarLoggedin'
import { HomepageTable } from '@/components/HomepageTable'
import { useAuthStatus } from '@/components/hooks/useAuthStatus'
import { CategoryBar } from '@/components/kategoriak'

export const Route = createFileRoute('/')({
  component: RouteComponent,
})

function RouteComponent() {
  const { data: user, isLoading: authLoading } = useAuthStatus()
  
  const [selectedKategoria, setSelectedKategoria] = useState<number | null>(null)
  
  if (authLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <p className="text-emerald-700 animate-pulse font-medium">Betöltés...</p>
      </div>
    )
  }
  
  const isLoggedIn = !!user

  return (
    <div className="min-h-screen bg-gray-50">
      {isLoggedIn ? <NavbarLoggedIn /> : <Navbar />}
      
      <CategoryBar 
        selectedId={selectedKategoria} 
        onSelect={setSelectedKategoria} 
      />

      <main className="container mx-auto py-8 px-4">
        <div className="mb-8 text-center">
          {isLoggedIn ? (
            <h2 className="text-xl font-medium text-emerald-900">
              Üdv újra, {user?.username}!
            </h2>
          ) : (
            <div className="bg-emerald-50 border border-emerald-100 p-4 rounded-xl inline-block">
              <p className="text-emerald-800 text-sm">
                Jelentkezz be, hogy termékeket tudj kosárba tenni!
              </p>
            </div>
          )}
        </div>
        
        <HomepageTable 
          userId={user?.userID || null}
          kategoriaId={selectedKategoria}
        />
      </main>

    </div>
  )
}