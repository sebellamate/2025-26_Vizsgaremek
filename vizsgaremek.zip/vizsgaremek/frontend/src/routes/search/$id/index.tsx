"use client"

import { createFileRoute, Link } from "@tanstack/react-router"
import {
  Card,
  CardContent,
} from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useTermekekBy_ids } from "@/components/hooks/useTermekekByid"
import { useAuthStatus } from "@/components/hooks/useAuthStatus"
import { Navbar } from "@/components/Navbar"
import { NavbarLoggedIn } from "@/components/NavbarLoggedin"
import { ShoppingBag, Eye, Lock, ShoppingCart } from "lucide-react"
import { Footer } from "@/components/Footer"
import { useTetelPost } from '@/components/hooks/useTetelpost'

type Termek = {
  termek_id: number
  nev: string
  leiras: string
  ar: number
  akcio: number
  kep_url: string
  kategoria_id: number
}

export const Route = createFileRoute("/search/$id/")({
  component: SearchResultsRoute,
})

function SearchResultsRoute() {
  const { id } = Route.useParams()
  const ids = id.split(",").map(Number)

  const { data: user, isLoading: authLoading } = useAuthStatus()
  
  const { createTetel, isPending } = useTetelPost()

  const {
    data: termekek,
    isLoading: termekekLoading,
    error,
  } = useTermekekBy_ids(ids)

  const isLoggedIn = !!user

  if (authLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-white">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-700" />
      </div>
    )
  }

  return (
    <div className="flex flex-col min-h-screen bg-slate-50/30">
      {isLoggedIn ? <NavbarLoggedIn /> : <Navbar />}

      <main className="flex-grow max-w-7xl mx-auto p-8 w-full">
        <div className="mb-10 text-center md:text-left">
          <h1 className="text-4xl font-black text-emerald-900 tracking-tight">Keresési találatok</h1>
          {!termekekLoading && termekek && termekek.length > 0 && (
            <p className="text-slate-500 mt-2 font-medium">
              Összesen <span className="text-emerald-700">{termekek.length}</span> terméket találtunk neked
            </p>
          )}
        </div>

        {termekekLoading ? (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-700" />
            <p className="text-emerald-800 font-medium text-lg">Találatok betöltése...</p>
          </div>
        ) : error || !termekek || termekek.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 text-center space-y-6 bg-white rounded-3xl border border-emerald-50 shadow-sm px-6">
            <div className="bg-slate-50 p-6 rounded-full">
              <ShoppingBag className="w-16 h-16 text-slate-300" />
            </div>
            <div className="max-w-sm">
              <h2 className="text-2xl font-bold text-slate-800 mb-2">Hoppá, nincs találat!</h2>
              <p className="text-slate-500">Próbálkozz más kifejezéssel a fenti keresőben, vagy böngéssz a kategóriák között.</p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {termekek.map((t: Termek) => {
              const vanAkcio = t.akcio > 0;
              const akciosAr = vanAkcio 
                ? Math.round(t.ar * (1 - t.akcio / 100)) 
                : t.ar;

              return (
                <Card key={t.termek_id} className="group hover:shadow-2xl transition-all duration-500 border-emerald-100/50 overflow-hidden bg-white flex flex-col h-full relative">
                  
                  {vanAkcio && (
                    <div className="absolute top-3 left-3 z-20">
                      <Badge className="bg-red-500 hover:bg-red-600 text-white font-bold shadow-lg border-none px-3 py-1.5 text-sm">
                        -{t.akcio}%
                      </Badge>
                    </div>
                  )}

                  <Link 
                    to="/products/$id" 
                    params={{ id: t.termek_id.toString() }}
                    className="cursor-pointer flex flex-col flex-1 group"
                  >
                    <div className="relative overflow-hidden h-56 bg-white p-6 flex items-center justify-center border-b border-slate-50 shrink-0">
                      <img
                        src={`/kepek/${t.kep_url}`}
                        className="h-full w-full object-contain drop-shadow-md transform group-hover:scale-110 transition-transform duration-700 ease-in-out"
                        alt={t.nev}
                      />
                      <div className="absolute inset-0 bg-emerald-900/0 group-hover:bg-emerald-900/5 transition-colors duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100 z-10">
                         <div className="bg-white/95 p-3 rounded-full shadow-2xl transform scale-50 group-hover:scale-100 transition-transform duration-300">
                            <Eye className="w-6 h-6 text-emerald-700" />
                         </div>
                      </div>
                    </div>

                    <CardContent className="p-5 flex flex-col flex-1">
                      <h3 className="text-lg font-bold text-emerald-950 mb-2 group-hover:text-emerald-700 transition-colors line-clamp-1" title={t.nev}>
                        {t.nev}
                      </h3>
                      <p className="text-sm text-slate-500 line-clamp-2 mb-4 h-10 leading-relaxed">
                        {t.leiras}
                      </p>
                      
                      <div className="mt-auto flex flex-col justify-end h-14">
                        {vanAkcio ? (
                          <div>
                            <span className="text-sm text-slate-400 line-through block font-medium">
                              {Number(t.ar).toLocaleString("hu-HU")} Ft
                            </span>
                            <span className="font-black text-emerald-700 text-2xl tracking-tight">
                              {akciosAr.toLocaleString("hu-HU")} Ft
                            </span>
                          </div>
                        ) : (
                          <span className="font-black text-emerald-700 text-2xl tracking-tight">
                            {Number(t.ar).toLocaleString("hu-HU")} Ft
                          </span>
                        )}
                      </div>
                    </CardContent>
                  </Link>

                  <div className="p-5 pt-0 mt-auto">
                    {isLoggedIn ? (
                      <Button
                        className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl h-12 transition-all active:scale-95 shadow-md shadow-emerald-200/50 flex gap-2 items-center justify-center"
                        disabled={isPending}
                        onClick={(e) => {
                          e.preventDefault();
                          createTetel({ termek_id: t.termek_id });
                        }}
                      >
                        <ShoppingCart className="w-4 h-4" />
                        {isPending ? "Hozzáadás..." : "Kosárba teszem"}
                      </Button>
                    ) : (
                      <div className="w-full h-12 flex items-center justify-center gap-2 border-2 border-dashed border-slate-300 bg-slate-50/50 rounded-xl text-slate-500">
                        <Lock className="w-4 h-4" />
                        <span className="text-sm font-bold">Jelentkezz be!</span>
                      </div>
                    )}
                  </div>
                </Card>
              )
            })}
          </div>
        )}
      </main>
      <Footer />
    </div>
  )
}