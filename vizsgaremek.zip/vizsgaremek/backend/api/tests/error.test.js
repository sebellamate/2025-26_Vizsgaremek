const request = require("supertest");
const app = require("../../app");
const db = require("../db");
const { 
    AppError, 
    NotFoundError, 
    BadRequestError, 
    UnauthorizedError, 
    ValidationError, 
    DbError 
} = require("../errors");

jest.mock("../db", () => ({
    Termek: {
        findAll: jest.fn(),
        findOne: jest.fn(),
        create: jest.fn(),
        destroy: jest.fn()
    },
    User: {
        create: jest.fn(),
        findAll: jest.fn(),
        findOne: jest.fn()
    },
    sequelize: {
        sync: jest.fn(),
        close: jest.fn()
    }
}));

describe("API Error Handling Tests", () => {
    
    beforeEach(() => {
        jest.clearAllMocks();
    });

    const adminCookie = "user_token=valid_mock_token_for_admin";

    describe("Direct Class Tests", () => {
        it("should verify ValidationError uses status 403", () => {
            const err = new ValidationError();
            expect(err.statusCode).toBe(403);
        });

        it("should verify DbError uses status 500 and is not operational", () => {
            const err = new DbError();
            expect(err.statusCode).toBe(500);
            expect(err.isOperational).toBe(false);
        });
    });

    describe("HTTP Error Responses", () => {
        it("401 Unauthorized - No token provided", async () => {
            const res = await request(app).get("/api/users");
            expect(res.statusCode).toBe(401);
        });

        it("403 or 400 Validation - Testing how the app handles bad input", async () => {
            const res = await request(app)
                .post("/api/users")
                .send({ email: "invalid", password: "1" });
            
            expect([400, 403]).toContain(res.statusCode);
        });

        it("404 Not Found - Handling non-existent resources", async () => {
            db.Termek.findOne.mockResolvedValue(null);
            const res = await request(app).get("/api/termekek/999999");
            expect(res.statusCode).toBe(404);
        });
    });

    describe("Database Failure Simulation", () => {
        it("should return 500 when database throws an error", async () => {
            db.Termek.findAll.mockRejectedValue(new Error("DB Connection Failed"));
            const res = await request(app).get("/api/termekek");
            expect(res.statusCode).toBe(500);
        });
    });

    describe("AppError environment isolation", () => {
        const originalEnv = process.env.NODE_ENV;

        afterEach(() => {
            process.env.NODE_ENV = originalEnv;
        });

        it("should not expose details in production", () => {
            process.env.NODE_ENV = "production";
            const err = new AppError("Error", { details: "sensitive" });
            expect(err.details).toBeUndefined();
        });
    });
});