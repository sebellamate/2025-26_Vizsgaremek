const request = require("supertest");
const app = require("../../app");
const db = require("../db");
const { userIsLoggedIn } = require("../middlewares/authMiddleware");

jest.mock("../db");
jest.mock("../models/User");

jest.mock("../utilities/authUtils", () => ({
  verifyToken: jest.fn((token) => {
    if (token === "valid_mock_token_for_admin" || token === "valid_admin_token") {
      return { id: 1, userID: 1, isAdmin: true, name: "AdminUser" };
    }
    if (token === "valid_user_token") {
      return { id: 2, userID: 2, isAdmin: false, name: "NormalUser" };
    }
    throw new Error("Invalid token");
  }),
  generateUserToken: jest.fn().mockReturnValue("valid_user_token"),
  setCookie: jest.fn(),
}));

describe("Express API CRUD Tests", () => {
  let createdTermekId;

  beforeAll(async () => {
    if (db.sequelize && db.sequelize.sync) {
      await db.sequelize.sync({ force: true });

      if (db.Kategoria) {
        await db.Kategoria.create({ id: 1, nev: "Teszt Kategória" });
      }

      if (db.User) {
        await db.User.create({
          ID: 1,
          name: "Admin",
          email: "admin@test.com",
          password: "AdminPassword123",
        });
      }
    }
  });

  afterAll(async () => {
    if (db.sequelize && db.sequelize.close) {
      await db.sequelize.close();
    }
  });

  beforeEach(() => {
    jest.clearAllMocks();
  });

  const mockAuthCookie = "user_token=valid_mock_token_for_admin";

  describe("Kategóriák API (/api/kategoriak)", () => {
    it("POST /api/kategoriak - should create a new kategoria", async () => {
      const res = await request(app)
        .post("/api/kategoriak")
        .set("Cookie", [mockAuthCookie])
        .send({ nev: "Új Teszt Kategória" });

      expect(res.statusCode).toBe(201);
      expect(res.body).toHaveProperty("nev", "Új Teszt Kategória");
    });

    it("GET /api/kategoriak - should fetch all kategoriak", async () => {
      const res = await request(app).get("/api/kategoriak");

      expect(res.statusCode).toBe(200);
      expect(Array.isArray(res.body)).toBeTruthy();
    });
  });

  describe("Termékek API (/api/termekek)", () => {
    it("POST /api/termekek - should create a new termek", async () => {
      const newTermek = {
        nev: "Teszt Termék",
        leiras: "Ez egy csodálatos teszt termék leírása.",
        ar: 2500,
        kep_url: "/kepek/teszt.jpg",
        kategoria_id: 1,
      };

      const res = await request(app)
        .post("/api/termekek")
        .set("Cookie", [mockAuthCookie])
        .send(newTermek);

      expect(res.statusCode).toBe(200);
      expect(res.body).toHaveProperty("nev", newTermek.nev);

      if (res.body.termek_id) createdTermekId = res.body.termek_id;
      else if (res.body.id) createdTermekId = res.body.id;
    });

    it("GET /api/termekek - should fetch all termekek", async () => {
      const res = await request(app).get("/api/termekek");

      expect(res.statusCode).toBe(200);
      expect(Array.isArray(res.body)).toBeTruthy();
    });

    it("GET /api/termekek/:termek_id - should fetch a single termek by ID", async () => {
      const res = await request(app).get(`/api/termekek/${createdTermekId}`);

      expect(res.statusCode).toBe(200);
      expect(res.body).toBeDefined();
    });

    it("PUT /api/termekek/:termek_id - should edit an existing termek", async () => {
      const updateData = { ar: 3000, leiras: "Frissített leírás" };
      const res = await request(app)
        .put(`/api/termekek/${createdTermekId}`)
        .set("Cookie", [mockAuthCookie])
        .send(updateData);

      expect(res.statusCode).toBe(200);
    });

    it("DELETE /api/termekek/:termek_id - should delete a termek", async () => {
      const res = await request(app)
        .delete(`/api/termekek/${createdTermekId}`)
        .set("Cookie", [mockAuthCookie]);

      expect(res.statusCode).toBe(200);
    });
  });

  describe("Users API (/api/users)", () => {
    let createdUserId = 1;

    it("POST /api/users - should create a new user", async () => {
      const newUser = {
        username: "TestElek",
        email: "teszt.elek@example.com",
        password: "securepassword123",
      };

      const res = await request(app).post("/api/users").send(newUser);

      expect(res.statusCode).toBe(201);
      expect(res.body).toHaveProperty("email", newUser.email);
      expect(res.body).toHaveProperty("name", newUser.username);

      if (res.body.id) createdUserId = res.body.id;
    });

    it("GET /api/users - should fetch all users", async () => {
      const res = await request(app)
        .get("/api/users")
        .set("Cookie", [mockAuthCookie]);

      expect(res.statusCode).toBe(200);
      expect(Array.isArray(res.body)).toBeTruthy();
    });

    it("GET /api/users/:userID - should fetch a user by ID", async () => {
      const res = await request(app)
        .get(`/api/users/${createdUserId}`)
        .set("Cookie", [mockAuthCookie]);

      expect(res.statusCode).toBe(200);
    });
  });

  describe("Kosártételek API (/api/kosartetelek)", () => {
    let tetelId = 1;
    let activeTermekId;

    beforeAll(async () => {
      if (db.Termek) {
        const ujTermek = await db.Termek.create({
          nev: "Kosár Teszt Termék",
          leiras: "Ez egy termék a kosár teszthez",
          ar: 1500,
          kep_url: "/kepek/teszt.jpg",
          kategoria_id: 1,
        });
        activeTermekId = ujTermek.termek_id || ujTermek.id;
      }
    });

    it("POST /api/kosartetelek - should add an item to the basket", async () => {
      const newTetel = {
        user_id: 1,
        termek_id: activeTermekId,
        mennyiseg: 1,
      };

      const res = await request(app)
        .post("/api/kosartetelek")
        .set("Cookie", [mockAuthCookie])
        .send(newTetel);

      expect(res.statusCode).toBe(200);
      if (res.body && res.body.id) tetelId = res.body.id;
    });

    it("GET /api/kosartetelek/osszes/:id - should fetch all items for a user", async () => {
      const res = await request(app)
        .get(`/api/kosartetelek/osszes/1`)
        .set("Cookie", [mockAuthCookie]);

      expect(res.statusCode).toBe(200);
      expect(Array.isArray(res.body)).toBeTruthy();
    });

    it("GET /api/kosartetelek/:id - should fetch a single item", async () => {
      const res = await request(app)
        .get(`/api/kosartetelek/${tetelId}`)
        .set("Cookie", [mockAuthCookie]);

      expect(res.statusCode).toBe(200);
    });

    it("PUT /api/kosartetelek/pluszegy/:id - should increment item quantity", async () => {
      const res = await request(app)
        .put(`/api/kosartetelek/pluszegy/${tetelId}`)
        .set("Cookie", [mockAuthCookie]);

      expect(res.statusCode).toBe(200);
    });

    it("PUT /api/kosartetelek/minuszegy/:id - should decrement item quantity", async () => {
      const res = await request(app)
        .put(`/api/kosartetelek/minuszegy/${tetelId}`)
        .set("Cookie", [mockAuthCookie]);

      expect(res.statusCode).toBe(200);
    });

    it("DELETE /api/kosartetelek/torles/:id - should delete the item from basket", async () => {
      const res = await request(app)
        .delete(`/api/kosartetelek/torles/${tetelId}`)
        .set("Cookie", [mockAuthCookie]);

      expect(res.statusCode).toBe(200);
    });
  });

  describe("Értékelések API (/api/ertekelesek)", () => {
    let ertekelesTermekId = 1;

    beforeAll(async () => {
      if (db.Termek) {
        const ujTermek = await db.Termek.create({
          nev: "Értékelés Teszt Termék",
          leiras: "Kiváló termék",
          ar: 5000,
          kategoria_id: 1,
        });
        ertekelesTermekId = ujTermek.termek_id || ujTermek.id;
      }
    });

    it("POST /api/ertekelesek - should add a review to a termek", async () => {
      const res = await request(app)
        .post("/api/ertekelesek")
        .set("Cookie", [mockAuthCookie])
        .send({
          termek_id: ertekelesTermekId,
          pontszam: 5,
          velemeny: "Nagyon jó termék!",
        });

      expect([200, 201]).toContain(res.statusCode);
    });

    it("GET /api/ertekelesek/termek/:termek_id - should get all reviews for a termek", async () => {
      const res = await request(app).get(`/api/ertekelesek/termek/${ertekelesTermekId}`);
      expect(res.statusCode).toBe(200);
      expect(Array.isArray(res.body)).toBeTruthy();
    });
  });

  describe("Rendelések API (/api/rendeles)", () => {
    let rendelesTermekId = 1;

    beforeAll(async () => {
      if (db.Termek) {
        const ujTermek = await db.Termek.create({
          nev: "Rendelés Teszt Termék",
          leiras: "Kiváló termék rendeléshez",
          ar: 2500,
          kategoria_id: 1,
        });
        rendelesTermekId = ujTermek.termek_id || ujTermek.id;
      }
    });

    it("POST /api/rendeles - should create a new rendeles", async () => {
      const res = await request(app)
        .post("/api/rendeles") 
        .set("Cookie", [mockAuthCookie])
        .send({
          user_id: 1,
          osszeg: 5000,
          cim: "1234 Budapest, Példa utca 1.",
          kupon_id: "none",
          tetelek: [
            { termek_id: rendelesTermekId, mennyiseg: 2, egyseg_ar: 2500 }
          ]
        });

      expect([200, 201]).toContain(res.statusCode);
    });

    it("GET /api/rendeles/user/:userId - should get user's orders", async () => {
      const res = await request(app)
        .get("/api/rendeles/user/1")
        .set("Cookie", [mockAuthCookie]);

      expect(res.statusCode).toBe(200);
      expect(Array.isArray(res.body)).toBeTruthy();
    });
})});