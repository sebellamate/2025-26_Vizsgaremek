const { DbError } = require("../errors");
const { Op } = require("sequelize");

class UserRepository {
    constructor(db) {
        this.User = db.User;
        this.Kupon = db.Kupon;
        this.Termek = db.Termek;
        this.sequelize = db.sequelize;
        this.Rendeles = db.Rendeles;
    }

    async patchDelivery(rendeles_id) {
    try {
        const rendeles = await this.Rendeles.findByPk(rendeles_id);

        if (!rendeles) {
            throw new Error("A rendelés nem található.");
        }

        if (rendeles.statusz === 'szallitva') {
            throw new Error("Ez a rendelés már ki van szállítva!");
        }

        if (rendeles.statusz === 'torolve') {
            throw new Error("Törölt rendelést nem lehet kiszállítani!");
        }

        rendeles.statusz = 'szallitva';
        await rendeles.save();

        return rendeles;
    } catch (error) {
        throw new DbError(error.message, { details: error.message });
    }
}

    async getUsers() {
        try {
            return await this.User.scope(["public"]).findAll();
        } catch (error) {
            throw new DbError("Failed to fetch users", { details: error.message });
        }
    }

    async getUser(userID) {
        try {
            if (!isNaN(userID) && Number.isInteger(Number(userID))) {
                return await this.User.findByPk(userID);
            }

            return await this.User.findOne({
                where: {
                    [Op.or]: [
                        { name: userID },
                        { email: userID }
                    ],
                }
            });
        } catch (error) {
            throw new DbError("Hiba a felhasználó lekérésekor", { details: error.message, data: userID });
        }
    }

    async getUserById(userID) {
        try {
            return await this.User.findByPk(userID);
        } catch (error) {
            throw new DbError("Failed to fetch user by ID", { details: error.message, data: userID });
        }
    }

    async getUserByEmail(email) {
        try {
            return await this.User.findOne({ where: { email } });
        } catch (error) {
            throw new DbError("Failed to fetch user by email", { details: error.message, data: email });
        }
    }

    async getUserByEmailOrName(email, name) {
        try {
            return await this.User.findOne({
                where: {
                    [Op.or]: [
                        { email: email || '' },
                        { name: name || '' }
                    ]
                }
            });
        } catch (error) {
            throw new DbError("Failed to fetch user by email or name", { details: error.message });
        }
    }

    async createUser(userData) {
        try {
            return await this.User.create(userData);
        } catch (error) {
            throw new DbError("Failed to create user object", { details: error.message, data: userData });
        }
    }


    async getUserCoupons(userID) {
        try {
            if (!this.Kupon) {
                throw new Error("A Kupon modell nincs regisztrálva!");
            }
            return await this.Kupon.findAll({
                where: { user_id: userID },
                order: [['kupon_id', 'DESC']] 
            });
        } catch (error) {
            console.error("SEQUELIZE HIBA RÉSZLETEI:", error); 
            throw new DbError("Hiba a felhasználó kuponjainak lekérésekor", { 
                details: error.message, 
                data: userID 
            });
        }
    }

    async createKupon(kuponData) {
        try {
            if (!this.Kupon) {
                throw new Error("A Kupon modell nincs regisztrálva!");
            }
            const finalData = { ervenyes: true, ...kuponData };
            return await this.Kupon.create(finalData);
        } catch (error) {
            throw new DbError("Hiba a kupon létrehozásakor", { 
                details: error.message, 
                data: kuponData 
            });
        }
    }

    async getKuponByKod(kod) {
        try {
            return await this.Kupon.findOne({
                where: { kod: kod }
            });
        } catch (error) {
            throw new DbError("Hiba a kupon lekérésekor kód alapján", { 
                details: error.message, 
                data: kod 
            });
        }
    }


    async updateUserResetToken(userID, token, expires) {
        try {
            return await this.User.update(
                { reset_token: token, reset_expires: expires },
                { where: { ID: userID } }
            );
        } catch (error) {
            throw new DbError("Failed to update reset token", { details: error.message });
        }
    }

    async getUserByResetToken(token) {
        try {
            return await this.User.findOne({
                where: {
                    reset_token: token,
                    reset_expires: { [Op.gt]: new Date() }
                }
            });
        } catch (error) {
            throw new DbError("Failed to fetch user by reset token", { details: error.message });
        }
    }

    async updateUserPassword(userID, newPassword) {
        try {
            const user = await this.User.findByPk(userID);
            if (!user) throw new Error("User not found");

            return await user.update({
                password: newPassword,
                reset_token: null,
                reset_expires: null
            });
        } catch (error) {
            throw new DbError("Failed to update user password", { details: error.message });
        }
    }


    async updateProductDiscount(termekID, akcio) {
        try {
            const [affectedRows] = await this.Termek.update(
                { akcio: akcio }, 
                { where: { termek_id: termekID } }
            );

            if (affectedRows === 0) {
                throw new Error("Nem található termék vagy nem történt módosítás.");
            }

            return await this.Termek.findOne({ where: { termek_id: termekID } });
        } catch (error) {
            throw new DbError("Hiba a termék akció frissítésekor", { 
                details: error.message, 
                data: { termekID, akcio } 
            });
        }
    }
}

module.exports = UserRepository;